local L = {
  size = 274,
  -- <TRANSLATE>
  [31] = {   32, "TARGET" },
  [4294967295] = {  274, "" },
  [63] = {   64, "1000k" },
  [77] = {   78, "400 " },
  [79] = {   80, "400" },
  -- <STRING>
  [0] = {    1, "MFDROOT" },
  [1] = {    2, "MFDSCREEN" },
  [2] = {    3, "BACKDROP" },
  [3] = {    4, "ZANDT_MAINPLATE" },
  [4] = {    5, "BATCHMFD" },
  [5] = {    6, "BATCHCONTROLS" },
  [6] = {    7, "BLACK_HUD" },
  [7] = {    8, "BATCHVDUSHIELD" },
  [8] = {    9, "VDU_SHIELD_0" },
  [9] = {   10, "BATCHVDU" },
  [10] = {   11, "PIRATE02" },
  [11] = {   12, "BATCHVDUDAMAGE" },
  [12] = {   13, "PIRATE02DAM" },
  [13] = {   14, "POWERGROUP" },
  [14] = {   15, "FUELGROUP" },
  [15] = {   16, "POWER_BAR" },
  [16] = {   17, "TOP" },
  [17] = {   18, "LEFT" },
  [18] = {   19, "BOTTOM" },
  [19] = {   20, "ZANDT_POWERBAR" },
  [20] = {   21, "JUMP_BAR" },
  [21] = {   22, "ZANDT_FUELBAR" },
  [22] = {   23, "MFD_AUTO" },
  [23] = {   24, "ZANDT_AUTO_" },
  [24] = {   25, "MFD_JUMP" },
  [25] = {   26, "ZANDT_JUMP_" },
  [26] = {   27, "MFDGROUP" },
  [27] = {   28, "MFDGROUP1" },
  [28] = {   29, "MFDTARGET" },
  [29] = {   30, "TARGETSTATUS" },
  [30] = {   31, "Imagine" },
  [32] = {   33, "TARGETNAME" },
  [33] = {   34, "TARGETDETAILS" },
  [34] = {   35, "TARGETDETAILSSMALL" },
  [35] = {   36, "TARGETRANGE" },
  [36] = {   37, "RIGHT" },
  [37] = {   38, "MFDTARGETINSET" },
  [38] = {   39, "MFDICON" },
  [39] = {   40, "SMALL_WAYPOINTMISSION" },
  [40] = {   41, "VDU" },
  [41] = {   42, "VDUDAMAGE" },
  [42] = {   43, "VDU_HULLDAMAGE_LEFT" },
  [43] = {   44, "VDU_HULLDAMAGE_RIGHT" },
  [44] = {   45, "VDU_HULLDAMAGE_REAR" },
  [45] = {   46, "VDU_HULLDAMAGE_FRONT" },
  [46] = {   47, "VDU_DAMAGE_FRONT" },
  [47] = {   48, "VDU_SHIELD_" },
  [48] = {   49, "VDU_DAMAGE_REAR" },
  [49] = {   50, "VDU_DAMAGE_LEFT" },
  [50] = {   51, "VDU_SHIELD_TOP_" },
  [51] = {   52, "VDU_DAMAGE_RIGHT" },
  [52] = {   53, "MFDWEAPONS" },
  [53] = {   54, "ZANDT_VDU" },
  [54] = {   55, "VDUHARDPOINT_8" },
  [55] = {   56, "VDUWEAPON_DFLAUNCHER" },
  [56] = {   57, "VDUHARDPOINT_0" },
  [57] = {   58, "VDUWEAPON_LASER" },
  [58] = {   59, "VDUHARDPOINT_1" },
  [59] = {   60, "VDUHARDPOINT_2" },
  [60] = {   61, "VDUHARDPOINT_3" },
  [61] = {   62, "MFD_WEAPONLINK" },
  [62] = {   63, "MFD_WEAPONS" },
  [64] = {   65, "MFD_MISSILES" },
  [65] = {   66, "MFDMESSAGE" },
  [66] = {   67, "MESSAGETITLE" },
  [67] = {   68, "MESSAGETEXT" },
  [68] = {   69, "VDUNOISE" },
  [69] = {   70, "NOISE_" },
  [70] = {   71, "MFDCOMM" },
  [71] = {   72, "COMM" },
  [72] = {   73, "COMMNAME" },
  [73] = {   74, "ZANDT_MFDOVERLAY" },
  [74] = {   75, "COMM_IMAGE" },
  [75] = {   76, "STATUSGROUP" },
  [76] = {   77, "SPEEDGROUP" },
  [78] = {   79, "SPEED_SET" },
  [80] = {   81, "SPEED_ACTUAL" },
  [81] = {   82, "ZANDT_STATUS" },
  [82] = {   83, "HARDPOINT_8" },
  [83] = {   84, "HARDPOINT_0" },
  [84] = {   85, "HARDPOINT_1" },
  [85] = {   86, "HARDPOINT_2" },
  [86] = {   87, "HARDPOINT_3" },
  [87] = {   88, "HULL_TOP" },
  [88] = {   89, "ZANDT_HULLTOP_" },
  [89] = {   90, "HULL_BOTTOM" },
  [90] = {   91, "ZANDT_HULLDOWN_" },
  [91] = {   92, "HULL_LEFT" },
  [92] = {   93, "ZANDT_HULLLEFT_" },
  [93] = {   94, "HULL_RIGHT" },
  [94] = {   95, "ZANDT_HULLRIGHT_" },
  [95] = {   96, "SHIELD_TOP" },
  [96] = {   97, "ZANDT_SHIELDTOP_" },
  [97] = {   98, "SHIELD_BOTTOM" },
  [98] = {   99, "ZANDT_SHIELDDOWN_" },
  [99] = {  100, "SHIELD_LEFT" },
  [100] = {  101, "ZANDT_SHIELDLEFT_" },
  [101] = {  102, "SHIELD_RIGHT" },
  [102] = {  103, "ZANDT_SHIELDRIGHT_" },
  [103] = {  104, "RADARPIPWAYPOINTRED" },
  [104] = {  105, "CENTER" },
  [105] = {  106, "SMALL_WAYPOINTPULSED" },
  [106] = {  107, "RADARPIPWAYPOINTREDSTORY" },
  [107] = {  108, "SMALL_WAYPOINTPULSED_IMPORTANT" },
  [108] = {  109, "RADARPIPWAYPOINTSECRET" },
  [109] = {  110, "SMALL_WAYPOINTSECRET" },
  [110] = {  111, "RADARPIPWAYPOINTSIGNAL" },
  [111] = {  112, "SMALL_WAYPOINTSIGNAL" },
  [112] = {  113, "RADARPIPWAYPOINTCARGO" },
  [113] = {  114, "SMALL_WAYPOINTSPECIAL" },
  [114] = {  115, "RADARPIPWAYPOINTRELIEF" },
  [115] = {  116, "RADARPIPWAYPOINTTREATY" },
  [116] = {  117, "RADARPIPWAYPOINTPIRATE" },
  [117] = {  118, "SMALL_WAYPOINTBOUNTY_SPECIAL" },
  [118] = {  119, "RADARPIPWAYPOINTINVADER" },
  [119] = {  120, "RADARPIPWAYPOINTSIEGE" },
  [120] = {  121, "RADARPIPWAYPOINTASSASSIN" },
  [121] = {  122, "RADARPIPWAYPOINTCONVOY" },
  [122] = {  123, "RADARPIPWAYPOINTPLAGUE" },
  [123] = {  124, "RADARPIPWAYPOINTTREASURE" },
  [124] = {  125, "RADARPIPWAYPOINTBOUNTY" },
  [125] = {  126, "RADARPIPWAYPOINTBLUE" },
  [126] = {  127, "RADARPIPWAYPOINTBLUESTORY" },
  [127] = {  128, "SMALL_WAYPOINTPULSED_PROTECT" },
  [128] = {  129, "RADARPIPSTATION" },
  [129] = {  130, "SMALL_WAYPOINTSTATION" },
  [130] = {  131, "RADARPIPJUMPGATE" },
  [131] = {  132, "SMALL_WAYPOINTJUMPGATE" },
  [132] = {  133, "RADARPIPJUMPGATERISKY" },
  [133] = {  134, "RADARPIPWAYPOINTPURPLE" },
  [134] = {  135, "RADARPIPWAYPOINTPURPLETRACKED" },
  [135] = {  136, "SMALL_WAYPOINTMISSION_TRACKED" },
  [136] = {  137, "RADARPIPWAYPOINTBUDDY" },
  [137] = {  138, "RADARPIPWAYPOINTBUDDYBROKEN" },
  [138] = {  139, "RADARPIPWAYPOINTBUDDYB" },
  [139] = {  140, "RADARPIPWAYPOINTBUDDYSTORY" },
  [140] = {  141, "SMALL_WAYPOINTMISSION_STORY" },
  [141] = {  142, "RADARPIPWAYPOINTBUDDYSTORYBROKEN" },
  [142] = {  143, "RADARPIPWAYPOINTBUDDYTRACKED" },
  [143] = {  144, "RADARPIPWAYPOINTBUDDYTRACKEDBROKEN" },
  [144] = {  145, "RADARPIPWAYPOINTBUDDYBTRACKED" },
  [145] = {  146, "RADARPIPWAYPOINTBUDDYTRACKEDSTORY" },
  [146] = {  147, "SMALL_WAYPOINTMISSION_STORY_TRACKED" },
  [147] = {  148, "RADARPIPWAYPOINTBUDDYTRACKEDSTORYBROKEN" },
  [148] = {  149, "RADARPIPWAYPOINTGOLD" },
  [149] = {  150, "RADARPIPWAYPOINTGOLDBROKEN" },
  [150] = {  151, "RADARPIPWAYPOINTGOLDB" },
  [151] = {  152, "RADARPIPWAYPOINTGOLDSTORY" },
  [152] = {  153, "RADARPIPWAYPOINTGOLDSTORYBROKEN" },
  [153] = {  154, "RADARPIPWAYPOINTGOLDTRACKED" },
  [154] = {  155, "RADARPIPWAYPOINTGOLDTRACKEDBROKEN" },
  [155] = {  156, "RADARPIPWAYPOINTGOLDBTRACKED" },
  [156] = {  157, "RADARPIPWAYPOINTGOLDTRACKEDSTORY" },
  [157] = {  158, "RADARPIPWAYPOINTGOLDTRACKEDSTORYBROKEN" },
  [158] = {  159, "RADARPIPWAYPOINTVISITED" },
  [159] = {  160, "RADARPIPWAYPOINTVISITEDB" },
  [160] = {  161, "RADARPIPWAYPOINTVISITEDSTORY" },
  [161] = {  162, "RADARPIPWAYPOINTVISITEDTRACKED" },
  [162] = {  163, "RADARPIPWAYPOINTVISITEDBTRACKED" },
  [163] = {  164, "RADARPIPWAYPOINTVISITEDTRACKEDSTORY" },
  [164] = {  165, "RADARPIPWAYPOINTGRAY" },
  [165] = {  166, "RADARPIPWAYPOINTGRAYSTORY" },
  [166] = {  167, "RADARPIPWAYPOINTGRAYSTORYPROTECT" },
  [167] = {  168, "RADARPIPWAYPOINTWHITE" },
  [168] = {  169, "SMALL_WAYPOINTCUSTOM" },
  [169] = {  170, "RADARPIPWAYPOINTMINEABLE" },
  [170] = {  171, "SMALL_WAYPOINTMINEABLE" },
  [171] = {  172, "RADARPIPMINE" },
  [172] = {  173, "MINEPIP" },
  [173] = {  174, "RADARPIPMINEFRIENDLY" },
  [174] = {  175, "MINEPIPORANGE" },
  [175] = {  176, "RADARPIPRED" },
  [176] = {  177, "REDPIP" },
  [177] = {  178, "RADARPIPREDHOVER" },
  [178] = {  179, "REDPIPBRIGHT" },
  [179] = {  180, "RADARPIPREDSELECTED" },
  [180] = {  181, "REDPIPSELECTED" },
  [181] = {  182, "TURRETRADARPIPRED" },
  [182] = {  183, "REDTURRETPIP" },
  [183] = {  184, "TURRETRADARPIPREDHOVER" },
  [184] = {  185, "REDTURRETPIPBRIGHT" },
  [185] = {  186, "TURRETRADARPIPREDSELECTED" },
  [186] = {  187, "REDTURRETPIPSELECTED" },
  [187] = {  188, "RADARPIPREDBIG" },
  [188] = {  189, "RADARPIPREDBIGSELECTED" },
  [189] = {  190, "RADARPIPREDBIGHOVER" },
  [190] = {  191, "RADARPIPCOMM" },
  [191] = {  192, "WHITEPIP" },
  [192] = {  193, "RADARPIPGOLD" },
  [193] = {  194, "GOLDPIP" },
  [194] = {  195, "RADARPIPGOLDHOVER" },
  [195] = {  196, "GOLDPIPBRIGHT" },
  [196] = {  197, "RADARPIPGOLDSELECTED" },
  [197] = {  198, "GOLDPIPSELECTED" },
  [198] = {  199, "RADARPIPGOLDBIG" },
  [199] = {  200, "RADARPIPGOLDBIGSELECTED" },
  [200] = {  201, "RADARPIPGOLDBIGHOVER" },
  [201] = {  202, "RADARPIPBLUE" },
  [202] = {  203, "BLUEPIP" },
  [203] = {  204, "RADARPIPBLUESELECTED" },
  [204] = {  205, "BLUEPIPSELECTED" },
  [205] = {  206, "RADARPIPBLUEHOVER" },
  [206] = {  207, "BLUEPIPBRIGHT" },
  [207] = {  208, "TURRETRADARPIPBLUE" },
  [208] = {  209, "BLUETURRETPIP" },
  [209] = {  210, "TURRETRADARPIPBLUESELECTED" },
  [210] = {  211, "BLUETURRETPIPSELECTED" },
  [211] = {  212, "TURRETRADARPIPBLUEHOVER" },
  [212] = {  213, "BLUETURRETPIPBRIGHT" },
  [213] = {  214, "RADARPIPCARGO" },
  [214] = {  215, "CARGOPIP" },
  [215] = {  216, "RADARPIPCARGOSELECTED" },
  [216] = {  217, "CARGOPIPSELECTED" },
  [217] = {  218, "RADARPIPCARGOHOVER" },
  [218] = {  219, "CARGOPIPBRIGHT" },
  [219] = {  220, "RADARPIPORD" },
  [220] = {  221, "CARGOPIPPURPLE" },
  [221] = {  222, "RADARPIPORDSELECTED" },
  [222] = {  223, "CARGOPIPPURPLESELECTED" },
  [223] = {  224, "RADARPIPORDHOVER" },
  [224] = {  225, "CARGOPIPPURPLEBRIGHT" },
  [225] = {  226, "RADARPIPCARGOBIG" },
  [226] = {  227, "RADARPIPCARGOSELECTEDBIG" },
  [227] = {  228, "RADARPIPCARGOHOVERBIG" },
  [228] = {  229, "RADARPIPCARGOGOLD" },
  [229] = {  230, "CARGOPIPGOLD" },
  [230] = {  231, "RADARPIPCARGOGOLDSELECTED" },
  [231] = {  232, "CARGOPIPGOLDSELECTED" },
  [232] = {  233, "RADARPIPCARGOGOLDHOVER" },
  [233] = {  234, "CARGOPIPGOLDBRIGHT" },
  [234] = {  235, "RADARPIPCARGORED" },
  [235] = {  236, "CARGOPIPRED" },
  [236] = {  237, "RADARPIPCARGOREDSELECTED" },
  [237] = {  238, "CARGOPIPREDSELECTED" },
  [238] = {  239, "RADARPIPCARGOREDHOVER" },
  [239] = {  240, "CARGOPIPREDBRIGHT" },
  [240] = {  241, "RADARPIPBLUEBIG" },
  [241] = {  242, "RADARPIPBLUEBIGSELECTED" },
  [242] = {  243, "RADARPIPBLUEBIGHOVER" },
  [243] = {  244, "RADARPIPGRAY" },
  [244] = {  245, "GRAYPIP" },
  [245] = {  246, "RADARPIPGRAYBIG" },
  [246] = {  247, "RADARPIPGRAYSELECTED" },
  [247] = {  248, "GRAYPIPSELECTED" },
  [248] = {  249, "RADARPIPGRAYHOVER" },
  [249] = {  250, "GRAYPIPBRIGHT" },
  [250] = {  251, "RADARPIPNEUTRAL" },
  [251] = {  252, "NEUTRALPIP" },
  [252] = {  253, "RADARPIPNEUTRALBIG" },
  [253] = {  254, "RADARPIPNEUTRALSELECTED" },
  [254] = {  255, "NEUTRALPIPSELECTED" },
  [255] = {  256, "RADARPIPNEUTRALBIGSELECTED" },
  [256] = {  257, "RADARPIPNEUTRALHOVER" },
  [257] = {  258, "NEUTRALPIPBRIGHT" },
  [258] = {  259, "RADARPIPNEUTRALBIGHOVER" },
  [259] = {  260, "RADARGROUP" },
  [260] = {  261, "COCKPITRADAR" },
  [261] = {  262, "COCKPITRADARPULSE" },
  [262] = {  263, "RADARPULSERING" },
  [263] = {  264, "RADARRING" },
  [264] = {  265, "RADARBLANK" },
  [265] = {  266, "RADARBATCH" },
  [266] = {  267, "WAYPOINTREDSMALL" },
  [267] = {  268, "HARDPOINT_4" },
  [268] = {  269, "HARDPOINT_5" },
  [269] = {  270, "HARDPOINT_9" },
  [270] = {  271, "VDUHARDPOINT_4" },
  [271] = {  272, "VDUHARDPOINT_5" },
  [272] = {  273, "VDUHARDPOINT_9" },
}
--------------------------------------------------------------------------------
-- n -> name, t -> type, v -> value
local content = {
  n="UI",
  vars = {
    { n="RESX", t="INTEGER", v=1024 },
    { n="RESY", t="INTEGER", v=1024 },
    { n="ZORDER", t="INTEGER", v=500 },
    { n="ALLOW_SCALE_RESIZE", t="BOOL", v=false },
    { n="ALLOW_POSITION_RESIZE", t="BOOL", v=false },
  },
  tags = {
    {    --UI[1]
      n="CONTAINER",
      vars = {
        { n="NAME", t="STRING", v=0 }, --> "MFDROOT"
        { n="WIDTH_PERCENT", t="FLOAT", v=1.0 },
        { n="HEIGHT_PERCENT", t="FLOAT", v=1.0 },
        { n="X", t="INTEGER", v=0 },
        { n="Y", t="INTEGER", v=0 },
      },
      tags = {
        {    --CONTAINER[1]
          n="CONTAINER",
          vars = {
            { n="NAME", t="STRING", v=1 }, --> "MFDSCREEN"
            { n="WIDTH_PERCENT", t="FLOAT", v=1.0 },
            { n="HEIGHT_PERCENT", t="FLOAT", v=1.0 },
            { n="X", t="INTEGER", v=0 },
            { n="Y", t="INTEGER", v=0 },
          },
          tags = {
            {    --CONTAINER[1]
              n="SPRITE",
              vars = {
                { n="NAME", t="STRING", v=2 }, --> "BACKDROP"
                { n="IMAGE", t="STRING", v=3 }, --> "ZANDT_MAINPLATE"
                { n="WIDTH", t="INTEGER", v=1024 },
                { n="HEIGHT", t="INTEGER", v=650 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
              },
              tags = {
                {    --SPRITE[1]
                  n="CONTAINER",
                  tags = {
                    {    --CONTAINER[1]
                      n="PANEL_GROUP",
                      vars = {
                        { n="NAME", t="STRING", v=4 }, --> "BATCHMFD"
                        { n="IMAGE", t="STRING", v=3 }, --> "ZANDT_MAINPLATE"
                        { n="BATCH", t="INTEGER", v=1 },
                      },
                      tags = {
                        {    --PANEL_GROUP[1]
                          n="PANEL_GROUP",
                          vars = {
                            { n="NAME", t="STRING", v=5 }, --> "BATCHCONTROLS"
                            { n="IMAGE", t="STRING", v=6 }, --> "BLACK_HUD"
                            { n="BATCH", t="INTEGER", v=3 },
                            { n="SORTOFFSET", t="INTEGER", v=5 },
                          }
                        }, { --PANEL_GROUP[2]
                          n="PANEL_GROUP",
                          vars = {
                            { n="NAME", t="STRING", v=7 }, --> "BATCHVDUSHIELD"
                            { n="IMAGE", t="STRING", v=8 }, --> "VDU_SHIELD_0"
                            { n="BATCH", t="INTEGER", v=4 },
                            { n="SORTOFFSET", t="INTEGER", v=3 },
                          }
                        }, { --PANEL_GROUP[3]
                          n="PANEL_GROUP",
                          vars = {
                            { n="NAME", t="STRING", v=9 }, --> "BATCHVDU"
                            { n="IMAGE", t="STRING", v=10 }, --> "PIRATE02"
                            { n="BATCH", t="INTEGER", v=6 },
                            { n="SORTOFFSET", t="INTEGER", v=3 },
                          }
                        }, { --PANEL_GROUP[4]
                          n="PANEL_GROUP",
                          vars = {
                            { n="NAME", t="STRING", v=11 }, --> "BATCHVDUDAMAGE"
                            { n="IMAGE", t="STRING", v=12 }, --> "PIRATE02DAM"
                            { n="BATCH", t="INTEGER", v=5 },
                            { n="SORTOFFSET", t="INTEGER", v=4 },
                          }
                        }
                      }
                    }, { --CONTAINER[2]
                      n="CONTAINER",
                      vars = {
                        { n="NAME", t="STRING", v=13 }, --> "POWERGROUP"
                        { n="WIDTH", t="INTEGER", v=42 },
                        { n="HEIGHT", t="INTEGER", v=536 },
                        { n="X", t="INTEGER", v=493 },
                        { n="Y", t="INTEGER", v=15 },
                      }
                    }, { --CONTAINER[3]
                      n="CONTAINER",
                      vars = {
                        { n="NAME", t="STRING", v=14 }, --> "FUELGROUP"
                        { n="WIDTH", t="INTEGER", v=48 },
                        { n="HEIGHT", t="INTEGER", v=202 },
                        { n="X", t="INTEGER", v=430 },
                        { n="Y", t="INTEGER", v=13 },
                      }
                    }, { --CONTAINER[4]
                      n="SPRITE",
                      vars = {
                        { n="NAME", t="STRING", v=15 }, --> "POWER_BAR"
                        { n="WIDTH", t="INTEGER", v=26 },
                        { n="HEIGHT", t="INTEGER", v=462 },
                        { n="X", t="INTEGER", v=503 },
                        { n="Y", t="INTEGER", v=480 },
                        { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                        { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                        { n="ORIGIN_VERT", t="STRING", v=18 }, --> "BOTTOM"
                        { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                        { n="IMAGE", t="STRING", v=19 }, --> "ZANDT_POWERBAR"
                        { n="BATCH", t="INTEGER", v=1 },
                      }
                    }, { --CONTAINER[5]
                      n="SPRITE",
                      vars = {
                        { n="NAME", t="STRING", v=20 }, --> "JUMP_BAR"
                        { n="WIDTH", t="INTEGER", v=44 },
                        { n="HEIGHT", t="INTEGER", v=196 },
                        { n="X", t="INTEGER", v=432 },
                        { n="Y", t="INTEGER", v=212 },
                        { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                        { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                        { n="ORIGIN_VERT", t="STRING", v=18 }, --> "BOTTOM"
                        { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                        { n="IMAGE", t="STRING", v=21 }, --> "ZANDT_FUELBAR"
                        { n="BATCH", t="INTEGER", v=1 },
                      }
                    }, { --CONTAINER[6]
                      n="SPRITEANIM",
                      vars = {
                        { n="NAME", t="STRING", v=22 }, --> "MFD_AUTO"
                        { n="WIDTH", t="INTEGER", v=43 },
                        { n="HEIGHT", t="INTEGER", v=89 },
                        { n="X", t="INTEGER", v=373 },
                        { n="Y", t="INTEGER", v=232 },
                        { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                        { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                        { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                        { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                        { n="IMAGE", t="STRING", v=23 }, --> "ZANDT_AUTO_"
                        { n="LOOP", t="BOOL", v=false },
                        { n="FRAMES", t="INTEGER", v=2 },
                        { n="SPEED", t="FLOAT", v=0.0 },
                        { n="BATCH", t="INTEGER", v=1 },
                      }
                    }, { --CONTAINER[7]
                      n="SPRITEANIM",
                      vars = {
                        { n="NAME", t="STRING", v=24 }, --> "MFD_JUMP"
                        { n="WIDTH", t="INTEGER", v=44 },
                        { n="HEIGHT", t="INTEGER", v=90 },
                        { n="X", t="INTEGER", v=430 },
                        { n="Y", t="INTEGER", v=232 },
                        { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                        { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                        { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                        { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                        { n="IMAGE", t="STRING", v=25 }, --> "ZANDT_JUMP_"
                        { n="LOOP", t="BOOL", v=false },
                        { n="FRAMES", t="INTEGER", v=2 },
                        { n="SPEED", t="FLOAT", v=0.0 },
                        { n="BATCH", t="INTEGER", v=1 },
                      }
                    }, { --CONTAINER[8]
                      n="CONTAINER",
                      vars = {
                        { n="NAME", t="STRING", v=26 }, --> "MFDGROUP"
                        { n="WIDTH", t="INTEGER", v=463 },
                        { n="HEIGHT", t="INTEGER", v=375 },
                        { n="X", t="INTEGER", v=551 },
                        { n="Y", t="INTEGER", v=11 },
                      }
                    }, { --CONTAINER[9]
                      n="SPRITE",
                      vars = {
                        { n="NAME", t="STRING", v=27 }, --> "MFDGROUP1"
                        { n="WIDTH", t="INTEGER", v=463 },
                        { n="HEIGHT", t="INTEGER", v=375 },
                        { n="X", t="INTEGER", v=551 },
                        { n="Y", t="INTEGER", v=11 },
                      },
                      tags = {
                        {    --SPRITE[1]
                          n="CONTAINER",
                          tags = {
                            {    --CONTAINER[1]
                              n="CONTAINER",
                              tags = {
                                {    --CONTAINER[1]
                                  n="CONTAINER",
                                  tags = {
                                    {    --CONTAINER[1]
                                      n="CONTAINER",
                                      vars = {
                                        { n="NAME", t="STRING", v=28 }, --> "MFDTARGET"
                                        { n="WIDTH", t="INTEGER", v=463 },
                                        { n="HEIGHT", t="INTEGER", v=375 },
                                      },
                                      tags = {
                                        {    --CONTAINER[1]
                                          n="TEXT",
                                          vars = {
                                            { n="NAME", t="STRING", v=29 }, --> "TARGETSTATUS"
                                            { n="FONT", t="STRING", v=30 }, --> "Imagine"
                                            { n="DROPSHADOW", t="BOOL", v=false },
                                            { n="SCALE", t="FLOAT", v=0.5 },
                                            { n="R", t="FLOAT", v=0.40000000596046 },
                                            { n="G", t="FLOAT", v=1.0 },
                                            { n="B", t="FLOAT", v=0.5 },
                                            { n="BOLD", t="BOOL", v=false },
                                            { n="TEXT", t="TRANSLATE", v=31 }, --> "TARGET"
                                            { n="WIDTH", t="INTEGER", v=310 },
                                            { n="HEIGHT", t="INTEGER", v=35 },
                                            { n="X", t="INTEGER", v=43 },
                                            { n="Y", t="INTEGER", v=4 },
                                            { n="TEXT_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                            { n="TEXT_VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                          }
                                        }, { --CONTAINER[2]
                                          n="TEXT",
                                          vars = {
                                            { n="NAME", t="STRING", v=32 }, --> "TARGETNAME"
                                            { n="FONT", t="STRING", v=30 }, --> "Imagine"
                                            { n="DROPSHADOW", t="BOOL", v=false },
                                            { n="SCALE", t="FLOAT", v=0.75 },
                                            { n="R", t="FLOAT", v=0.40000000596046 },
                                            { n="G", t="FLOAT", v=1.0 },
                                            { n="B", t="FLOAT", v=0.5 },
                                            { n="BOLD", t="BOOL", v=false },
                                            { n="TEXT", t="TRANSLATE", v=4294967295 }, --> ""
                                            { n="WIDTH", t="INTEGER", v=310 },
                                            { n="HEIGHT", t="INTEGER", v=35 },
                                            { n="X", t="INTEGER", v=43 },
                                            { n="Y", t="INTEGER", v=22 },
                                            { n="TEXT_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                            { n="TEXT_VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                          }
                                        }, { --CONTAINER[3]
                                          n="TEXT",
                                          vars = {
                                            { n="NAME", t="STRING", v=33 }, --> "TARGETDETAILS"
                                            { n="FONT", t="STRING", v=30 }, --> "Imagine"
                                            { n="DROPSHADOW", t="BOOL", v=false },
                                            { n="SCALE", t="FLOAT", v=0.75 },
                                            { n="R", t="FLOAT", v=0.40000000596046 },
                                            { n="G", t="FLOAT", v=1.0 },
                                            { n="B", t="FLOAT", v=0.5 },
                                            { n="BOLD", t="BOOL", v=false },
                                            { n="TEXT", t="TRANSLATE", v=4294967295 }, --> ""
                                            { n="WIDTH", t="INTEGER", v=378 },
                                            { n="HEIGHT", t="INTEGER", v=35 },
                                            { n="X", t="INTEGER", v=60 },
                                            { n="Y", t="INTEGER", v=73 },
                                            { n="TEXT_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                            { n="TEXT_VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                          }
                                        }, { --CONTAINER[4]
                                          n="TEXT",
                                          vars = {
                                            { n="NAME", t="STRING", v=34 }, --> "TARGETDETAILSSMALL"
                                            { n="FONT", t="STRING", v=30 }, --> "Imagine"
                                            { n="DROPSHADOW", t="BOOL", v=false },
                                            { n="SCALE", t="FLOAT", v=0.64999997615814 },
                                            { n="R", t="FLOAT", v=0.40000000596046 },
                                            { n="G", t="FLOAT", v=1.0 },
                                            { n="B", t="FLOAT", v=0.5 },
                                            { n="BOLD", t="BOOL", v=false },
                                            { n="TEXT", t="TRANSLATE", v=4294967295 }, --> ""
                                            { n="WIDTH", t="INTEGER", v=378 },
                                            { n="HEIGHT", t="INTEGER", v=35 },
                                            { n="X", t="INTEGER", v=60 },
                                            { n="Y", t="INTEGER", v=73 },
                                            { n="TEXT_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                            { n="TEXT_VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                          }
                                        }, { --CONTAINER[5]
                                          n="TEXT",
                                          vars = {
                                            { n="NAME", t="STRING", v=35 }, --> "TARGETRANGE"
                                            { n="FONT", t="STRING", v=30 }, --> "Imagine"
                                            { n="DROPSHADOW", t="BOOL", v=false },
                                            { n="SCALE", t="FLOAT", v=0.69999998807907 },
                                            { n="R_INT", t="INTEGER", v=8 },
                                            { n="G_INT", t="INTEGER", v=22 },
                                            { n="B_INT", t="INTEGER", v=10 },
                                            { n="BOLD", t="BOOL", v=false },
                                            { n="TEXT", t="TRANSLATE", v=4294967295 }, --> ""
                                            { n="WIDTH", t="INTEGER", v=111 },
                                            { n="HEIGHT", t="INTEGER", v=35 },
                                            { n="X", t="INTEGER", v=336 },
                                            { n="Y", t="INTEGER", v=338 },
                                            { n="TEXT_ALIGN", t="STRING", v=36 }, --> "RIGHT"
                                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                            { n="TEXT_VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                          }
                                        }, { --CONTAINER[6]
                                          n="CONTAINER",
                                          vars = {
                                            { n="NAME", t="STRING", v=37 }, --> "MFDTARGETINSET"
                                            { n="X", t="INTEGER", v=92 },
                                            { n="Y", t="INTEGER", v=78 },
                                          },
                                          tags = {
                                            {    --CONTAINER[1]
                                              n="SPRITE",
                                              vars = {
                                                { n="SCALE_SIZE", t="FLOAT", v=0.64999997615814 },
                                                { n="SCALE_POSITION", t="FLOAT", v=0.64999997615814 },
                                                { n="NAME", t="STRING", v=38 }, --> "MFDICON"
                                                { n="WIDTH", t="INTEGER", v=128 },
                                                { n="HEIGHT", t="INTEGER", v=128 },
                                                { n="X", t="INTEGER", v=174 },
                                                { n="Y", t="INTEGER", v=143 },
                                                { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                                { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                                { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                                                { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                                                { n="IMAGE", t="STRING", v=39 }, --> "SMALL_WAYPOINTMISSION"
                                              }
                                            }, { --CONTAINER[2]
                                              n="SPRITE",
                                              vars = {
                                                { n="SCALE_SIZE", t="FLOAT", v=0.64999997615814 },
                                                { n="SCALE_POSITION", t="FLOAT", v=0.64999997615814 },
                                                { n="NAME", t="STRING", v=40 }, --> "VDU"
                                                { n="WIDTH", t="INTEGER", v=256 },
                                                { n="HEIGHT", t="INTEGER", v=256 },
                                                { n="X", t="INTEGER", v=110 },
                                                { n="Y", t="INTEGER", v=79 },
                                                { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                                { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                                { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                                                { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                                                { n="IMAGE", t="STRING", v=10 }, --> "PIRATE02"
                                                { n="BATCH", t="INTEGER", v=6 },
                                              }
                                            }, { --CONTAINER[3]
                                              n="CONTAINER",
                                              vars = {
                                                { n="SCALE_SIZE", t="FLOAT", v=0.64999997615814 },
                                                { n="SCALE_POSITION", t="FLOAT", v=0.64999997615814 },
                                                { n="NAME", t="STRING", v=41 }, --> "VDUDAMAGE"
                                                { n="WIDTH", t="INTEGER", v=256 },
                                                { n="HEIGHT", t="INTEGER", v=256 },
                                                { n="X", t="INTEGER", v=110 },
                                                { n="Y", t="INTEGER", v=79 },
                                              },
                                              tags = {
                                                {    --CONTAINER[1]
                                                  n="SPRITE",
                                                  vars = {
                                                    { n="SCALE_SIZE", t="FLOAT", v=0.64999997615814 },
                                                    { n="SCALE_POSITION", t="FLOAT", v=0.64999997615814 },
                                                    { n="NAME", t="STRING", v=42 }, --> "VDU_HULLDAMAGE_LEFT"
                                                    { n="WIDTH", t="INTEGER", v=256 },
                                                    { n="HEIGHT", t="INTEGER", v=64 },
                                                    { n="VTILE", t="FLOAT", v=0.25 },
                                                    { n="X", t="INTEGER", v=0 },
                                                    { n="Y", t="INTEGER", v=0 },
                                                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                                    { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                                                    { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                                                    { n="IMAGE", t="STRING", v=12 }, --> "PIRATE02DAM"
                                                    { n="BATCH", t="INTEGER", v=5 },
                                                  }
                                                }, { --CONTAINER[2]
                                                  n="SPRITE",
                                                  vars = {
                                                    { n="SCALE_SIZE", t="FLOAT", v=0.64999997615814 },
                                                    { n="SCALE_POSITION", t="FLOAT", v=0.64999997615814 },
                                                    { n="NAME", t="STRING", v=43 }, --> "VDU_HULLDAMAGE_RIGHT"
                                                    { n="WIDTH", t="INTEGER", v=256 },
                                                    { n="HEIGHT", t="INTEGER", v=64 },
                                                    { n="VTILE", t="FLOAT", v=0.25 },
                                                    { n="VOFFSET", t="FLOAT", v=0.75 },
                                                    { n="X", t="INTEGER", v=0 },
                                                    { n="Y", t="INTEGER", v=192 },
                                                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                                    { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                                                    { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                                                    { n="IMAGE", t="STRING", v=12 }, --> "PIRATE02DAM"
                                                    { n="BATCH", t="INTEGER", v=5 },
                                                  }
                                                }, { --CONTAINER[3]
                                                  n="SPRITE",
                                                  vars = {
                                                    { n="SCALE_SIZE", t="FLOAT", v=0.64999997615814 },
                                                    { n="SCALE_POSITION", t="FLOAT", v=0.64999997615814 },
                                                    { n="NAME", t="STRING", v=44 }, --> "VDU_HULLDAMAGE_REAR"
                                                    { n="WIDTH", t="INTEGER", v=128 },
                                                    { n="HEIGHT", t="INTEGER", v=128 },
                                                    { n="UTILE", t="FLOAT", v=0.5 },
                                                    { n="VTILE", t="FLOAT", v=0.5 },
                                                    { n="VOFFSET", t="FLOAT", v=0.25 },
                                                    { n="X", t="INTEGER", v=0 },
                                                    { n="Y", t="INTEGER", v=64 },
                                                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                                    { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                                                    { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                                                    { n="IMAGE", t="STRING", v=12 }, --> "PIRATE02DAM"
                                                    { n="BATCH", t="INTEGER", v=5 },
                                                  }
                                                }, { --CONTAINER[4]
                                                  n="SPRITE",
                                                  vars = {
                                                    { n="SCALE_SIZE", t="FLOAT", v=0.64999997615814 },
                                                    { n="SCALE_POSITION", t="FLOAT", v=0.64999997615814 },
                                                    { n="NAME", t="STRING", v=45 }, --> "VDU_HULLDAMAGE_FRONT"
                                                    { n="WIDTH", t="INTEGER", v=128 },
                                                    { n="HEIGHT", t="INTEGER", v=128 },
                                                    { n="UTILE", t="FLOAT", v=0.5 },
                                                    { n="VTILE", t="FLOAT", v=0.5 },
                                                    { n="UOFFSET", t="FLOAT", v=0.5 },
                                                    { n="VOFFSET", t="FLOAT", v=0.25 },
                                                    { n="X", t="INTEGER", v=128 },
                                                    { n="Y", t="INTEGER", v=64 },
                                                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                                    { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                                                    { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                                                    { n="IMAGE", t="STRING", v=12 }, --> "PIRATE02DAM"
                                                    { n="BATCH", t="INTEGER", v=5 },
                                                  }
                                                }
                                              }
                                            }, { --CONTAINER[4]
                                              n="SPRITEANIM",
                                              vars = {
                                                { n="SCALE_SIZE", t="FLOAT", v=0.64999997615814 },
                                                { n="SCALE_POSITION", t="FLOAT", v=0.64999997615814 },
                                                { n="NAME", t="STRING", v=46 }, --> "VDU_DAMAGE_FRONT"
                                                { n="WIDTH", t="INTEGER", v=64 },
                                                { n="HEIGHT", t="INTEGER", v=256 },
                                                { n="X", t="INTEGER", v=366 },
                                                { n="Y", t="INTEGER", v=79 },
                                                { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                                { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                                { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                                                { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                                                { n="IMAGE", t="STRING", v=47 }, --> "VDU_SHIELD_"
                                                { n="LOOP", t="BOOL", v=false },
                                                { n="FRAMES", t="INTEGER", v=6 },
                                                { n="SPEED", t="FLOAT", v=0.0 },
                                                { n="BATCH", t="INTEGER", v=4 },
                                              }
                                            }, { --CONTAINER[5]
                                              n="SPRITEANIM",
                                              vars = {
                                                { n="SCALE_SIZE", t="FLOAT", v=0.64999997615814 },
                                                { n="SCALE_POSITION", t="FLOAT", v=0.64999997615814 },
                                                { n="NAME", t="STRING", v=48 }, --> "VDU_DAMAGE_REAR"
                                                { n="WIDTH", t="INTEGER", v=64 },
                                                { n="HEIGHT", t="INTEGER", v=256 },
                                                { n="X", t="INTEGER", v=46 },
                                                { n="Y", t="INTEGER", v=79 },
                                                { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                                { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                                { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                                                { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                                                { n="IMAGE", t="STRING", v=47 }, --> "VDU_SHIELD_"
                                                { n="LOOP", t="BOOL", v=false },
                                                { n="FRAMES", t="INTEGER", v=6 },
                                                { n="FLIP_X", t="BOOL", v=true },
                                                { n="SPEED", t="FLOAT", v=0.0 },
                                                { n="BATCH", t="INTEGER", v=4 },
                                              }
                                            }, { --CONTAINER[6]
                                              n="SPRITEANIM",
                                              vars = {
                                                { n="SCALE_SIZE", t="FLOAT", v=0.64999997615814 },
                                                { n="SCALE_POSITION", t="FLOAT", v=0.64999997615814 },
                                                { n="NAME", t="STRING", v=49 }, --> "VDU_DAMAGE_LEFT"
                                                { n="WIDTH", t="INTEGER", v=256 },
                                                { n="HEIGHT", t="INTEGER", v=64 },
                                                { n="X", t="INTEGER", v=110 },
                                                { n="Y", t="INTEGER", v=15 },
                                                { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                                { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                                { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                                                { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                                                { n="IMAGE", t="STRING", v=50 }, --> "VDU_SHIELD_TOP_"
                                                { n="LOOP", t="BOOL", v=false },
                                                { n="FRAMES", t="INTEGER", v=6 },
                                                { n="SPEED", t="FLOAT", v=0.0 },
                                                { n="BATCH", t="INTEGER", v=4 },
                                              }
                                            }, { --CONTAINER[7]
                                              n="SPRITEANIM",
                                              vars = {
                                                { n="SCALE_SIZE", t="FLOAT", v=0.64999997615814 },
                                                { n="SCALE_POSITION", t="FLOAT", v=0.64999997615814 },
                                                { n="NAME", t="STRING", v=51 }, --> "VDU_DAMAGE_RIGHT"
                                                { n="WIDTH", t="INTEGER", v=256 },
                                                { n="HEIGHT", t="INTEGER", v=64 },
                                                { n="X", t="INTEGER", v=110 },
                                                { n="Y", t="INTEGER", v=335 },
                                                { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                                { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                                { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                                                { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                                                { n="IMAGE", t="STRING", v=50 }, --> "VDU_SHIELD_TOP_"
                                                { n="FLIP_Y", t="BOOL", v=true },
                                                { n="LOOP", t="BOOL", v=false },
                                                { n="FRAMES", t="INTEGER", v=6 },
                                                { n="SPEED", t="FLOAT", v=0.0 },
                                                { n="BATCH", t="INTEGER", v=4 },
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }, { --CONTAINER[2]
                                      n="CONTAINER",
                                      vars = {
                                        { n="NAME", t="STRING", v=52 }, --> "MFDWEAPONS"
                                        { n="WIDTH", t="INTEGER", v=463 },
                                        { n="HEIGHT", t="INTEGER", v=375 },
                                      },
                                      tags = {
                                        {    --CONTAINER[1]
                                          n="SPRITE",
                                          vars = {
                                            { n="WIDTH", t="INTEGER", v=288 },
                                            { n="HEIGHT", t="INTEGER", v=245 },
                                            { n="X", t="INTEGER", v=105 },
                                            { n="Y", t="INTEGER", v=87 },
                                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                                            { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                                            { n="IMAGE", t="STRING", v=53 }, --> "ZANDT_VDU"
                                            { n="BATCH", t="INTEGER", v=1 },
                                          },
                                          tags = {
                                            {    --SPRITE[1]
                                              n="CONTAINER",
                                              vars = {
                                                { n="WIDTH", t="INTEGER", v=288 },
                                                { n="HEIGHT", t="INTEGER", v=245 },
                                              },
                                              tags = {
                                                {    -- MISSILE 1
                                                  n="SPRITE",
                                                  vars = {
                                                    { n="NAME", t="STRING", v=54 }, --> "VDUHARDPOINT_8"
                                                    { n="WIDTH", t="INTEGER", v=42 },
                                                    { n="HEIGHT", t="INTEGER", v=51 },
                                                    { n="X", t="INTEGER", v=80 },
                                                    { n="Y", t="INTEGER", v=110 },
                                                    { n="IMAGE", t="STRING", v=55 }, --> "VDUWEAPON_DFLAUNCHER"
                                                    { n="BATCH", t="INTEGER", v=3 },
                                                  }
                                                },
												{    -- MISSILE 2
                                                  n="SPRITE",
                                                  vars = {
                                                    { n="NAME", t="STRING", v=269 }, --> "VDUHARDPOINT_9"
                                                    { n="WIDTH", t="INTEGER", v=42 },
                                                    { n="HEIGHT", t="INTEGER", v=51 },
                                                    { n="X", t="INTEGER", v=170 },
                                                    { n="Y", t="INTEGER", v=110 },
                                                    { n="IMAGE", t="STRING", v=55 }, --> "VDUWEAPON_DFLAUNCHER"
                                                    { n="BATCH", t="INTEGER", v=3 },
                                                  }
                                                },
												{	-- WEAPON 1
                                                  n="SPRITE",
                                                  vars = {
                                                    { n="NAME", t="STRING", v=56 }, --> "VDUHARDPOINT_0"
                                                    { n="WIDTH", t="INTEGER", v=22 },
                                                    { n="HEIGHT", t="INTEGER", v=84 },
                                                    { n="X", t="INTEGER", v=120 },
                                                    { n="Y", t="INTEGER", v=0 },
                                                    { n="IMAGE", t="STRING", v=57 }, --> "VDUWEAPON_LASER"
                                                    { n="BATCH", t="INTEGER", v=3 },
                                                  }
                                                },
												{	-- WEAPON 2
                                                  n="SPRITE",
                                                  vars = {
                                                    { n="NAME", t="STRING", v=58 }, --> "VDUHARDPOINT_1"
                                                    { n="WIDTH", t="INTEGER", v=22 },
                                                    { n="HEIGHT", t="INTEGER", v=84 },
                                                    { n="X", t="INTEGER", v=150 },
                                                    { n="Y", t="INTEGER", v=0 },
                                                    { n="IMAGE", t="STRING", v=57 }, --> "VDUWEAPON_LASER"
                                                    { n="BATCH", t="INTEGER", v=3 },
                                                  }
                                                },
												{	-- WEAPON 3
                                                  n="SPRITE",
                                                  vars = {
                                                    { n="NAME", t="STRING", v=59 }, --> "VDUHARDPOINT_2"
                                                    { n="WIDTH", t="INTEGER", v=22 },
                                                    { n="HEIGHT", t="INTEGER", v=84 },
                                                    { n="X", t="INTEGER", v=90 },
                                                    { n="Y", t="INTEGER", v=15 },
                                                    { n="IMAGE", t="STRING", v=57 }, --> "VDUWEAPON_LASER"
                                                    { n="BATCH", t="INTEGER", v=3 },
                                                  }
                                                },
												{	-- WEAPON 4
                                                  n="SPRITE",
                                                  vars = {
                                                    { n="NAME", t="STRING", v=60 }, --> "VDUHARDPOINT_3"
                                                    { n="WIDTH", t="INTEGER", v=22 },
                                                    { n="HEIGHT", t="INTEGER", v=84 },
                                                    { n="X", t="INTEGER", v=180 },
                                                    { n="Y", t="INTEGER", v=15 },
                                                    { n="IMAGE", t="STRING", v=57 }, --> "VDUWEAPON_LASER"
                                                    { n="BATCH", t="INTEGER", v=3 },
                                                  }
                                                },
												{	-- WEAPON 5
                                                  n="SPRITE",
                                                  vars = {
                                                    { n="NAME", t="STRING", v=267 }, --> "VDUHARDPOINT_4"
                                                    { n="WIDTH", t="INTEGER", v=22 },
                                                    { n="HEIGHT", t="INTEGER", v=84 },
                                                    { n="X", t="INTEGER", v=60 },
                                                    { n="Y", t="INTEGER", v=50 },
                                                    { n="IMAGE", t="STRING", v=57 }, --> "VDUWEAPON_LASER"
                                                    { n="BATCH", t="INTEGER", v=3 },
                                                  }
                                                },
												{	-- WEAPON 6
                                                  n="SPRITE",
                                                  vars = {
                                                    { n="NAME", t="STRING", v=268 }, --> "VDUHARDPOINT_5"
                                                    { n="WIDTH", t="INTEGER", v=22 },
                                                    { n="HEIGHT", t="INTEGER", v=84 },
                                                    { n="X", t="INTEGER", v=210 },
                                                    { n="Y", t="INTEGER", v=50 },
                                                    { n="IMAGE", t="STRING", v=57 }, --> "VDUWEAPON_LASER"
                                                    { n="BATCH", t="INTEGER", v=3 },
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }, { --CONTAINER[2]
                                          n="TEXT",
                                          vars = {
                                            { n="NAME", t="STRING", v=61 }, --> "MFD_WEAPONLINK"
                                            { n="FONT", t="STRING", v=30 }, --> "Imagine"
                                            { n="DROPSHADOW", t="BOOL", v=false },
                                            { n="SCALE", t="FLOAT", v=0.80000001192093 },
                                            { n="R", t="FLOAT", v=0.40000000596046 },
                                            { n="G", t="FLOAT", v=1.0 },
                                            { n="B", t="FLOAT", v=0.5 },
                                            { n="BOLD", t="BOOL", v=false },
                                            { n="TEXT", t="TRANSLATE", v=4294967295 }, --> ""
                                            { n="WIDTH", t="INTEGER", v=111 },
                                            { n="HEIGHT", t="INTEGER", v=35 },
                                            { n="X", t="INTEGER", v=43 },
                                            { n="Y", t="INTEGER", v=22 },
                                            { n="TEXT_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                            { n="TEXT_VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                          }
                                        }, { --CONTAINER[3]
                                          n="TEXT",
                                          vars = {
                                            { n="NAME", t="STRING", v=62 }, --> "MFD_WEAPONS"
                                            { n="FONT", t="STRING", v=30 }, --> "Imagine"
                                            { n="SCALE", t="FLOAT", v=0.64999997615814 },
                                            { n="R", t="FLOAT", v=0.40000000596046 },
                                            { n="G", t="FLOAT", v=1.0 },
                                            { n="B", t="FLOAT", v=0.5 },
                                            { n="BOLD", t="BOOL", v=false },
                                            { n="TEXT", t="TRANSLATE", v=63 }, --> "1000k"
                                            { n="WIDTH", t="INTEGER", v=111 },
                                            { n="HEIGHT", t="INTEGER", v=35 },
                                            { n="X", t="INTEGER", v=61 },
                                            { n="Y", t="INTEGER", v=308 },
                                            { n="TEXT_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                            { n="TEXT_VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                          }
                                        }, { --CONTAINER[4]
                                          n="TEXT",
                                          vars = {
                                            { n="NAME", t="STRING", v=64 }, --> "MFD_MISSILES"
                                            { n="FONT", t="STRING", v=30 }, --> "Imagine"
                                            { n="SCALE", t="FLOAT", v=0.64999997615814 },
                                            { n="R", t="FLOAT", v=0.40000000596046 },
                                            { n="G", t="FLOAT", v=1.0 },
                                            { n="B", t="FLOAT", v=0.5 },
                                            { n="BOLD", t="BOOL", v=false },
                                            { n="TEXT", t="TRANSLATE", v=31 }, --> "TARGET"
                                            { n="WIDTH", t="INTEGER", v=111 },
                                            { n="HEIGHT", t="INTEGER", v=35 },
                                            { n="X", t="INTEGER", v=61 },
                                            { n="Y", t="INTEGER", v=330 },
                                            { n="TEXT_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                            { n="TEXT_VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                          }
                                        }
                                      }
                                    }, { --CONTAINER[3]
                                      n="CONTAINER",
                                      vars = {
                                        { n="NAME", t="STRING", v=65 }, --> "MFDMESSAGE"
                                        { n="WIDTH", t="INTEGER", v=463 },
                                        { n="HEIGHT", t="INTEGER", v=375 },
                                      },
                                      tags = {
                                        {    --CONTAINER[1]
                                          n="TEXT",
                                          vars = {
                                            { n="NAME", t="STRING", v=66 }, --> "MESSAGETITLE"
                                            { n="FONT", t="STRING", v=30 }, --> "Imagine"
                                            { n="DROPSHADOW", t="BOOL", v=false },
                                            { n="SCALE", t="FLOAT", v=0.80000001192093 },
                                            { n="R", t="FLOAT", v=0.40000000596046 },
                                            { n="G", t="FLOAT", v=1.0 },
                                            { n="B", t="FLOAT", v=0.5 },
                                            { n="BOLD", t="BOOL", v=false },
                                            { n="TEXT", t="TRANSLATE", v=4294967295 }, --> ""
                                            { n="WIDTH", t="INTEGER", v=111 },
                                            { n="HEIGHT", t="INTEGER", v=35 },
                                            { n="X", t="INTEGER", v=43 },
                                            { n="Y", t="INTEGER", v=22 },
                                            { n="TEXT_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                            { n="TEXT_VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                          }
                                        }, { --CONTAINER[2]
                                          n="TEXT",
                                          vars = {
                                            { n="NAME", t="STRING", v=67 }, --> "MESSAGETEXT"
                                            { n="FONT", t="STRING", v=30 }, --> "Imagine"
                                            { n="SCALE", t="FLOAT", v=0.60000002384186 },
                                            { n="R", t="FLOAT", v=0.40000000596046 },
                                            { n="G", t="FLOAT", v=1.0 },
                                            { n="B", t="FLOAT", v=0.5 },
                                            { n="BOLD", t="BOOL", v=false },
                                            { n="TEXT", t="TRANSLATE", v=4294967295 }, --> ""
                                            { n="WIDTH", t="INTEGER", v=378 },
                                            { n="HEIGHT", t="INTEGER", v=259 },
                                            { n="X", t="INTEGER", v=63 },
                                            { n="Y", t="INTEGER", v=72 },
                                            { n="TEXT_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                            { n="TEXT_VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                          }
                                        }
                                      }
                                    }, { --CONTAINER[4]
                                      n="CONTAINER",
                                      tags = {
                                        {    --CONTAINER[1]
                                          n="CONTAINER",
                                          tags = {
                                            {    --CONTAINER[1]
                                              n="SPRITEANIM",
                                              vars = {
                                                { n="NAME", t="STRING", v=68 }, --> "VDUNOISE"
                                                { n="WIDTH", t="INTEGER", v=463 },
                                                { n="HEIGHT", t="INTEGER", v=375 },
                                                { n="X", t="INTEGER", v=0 },
                                                { n="Y", t="INTEGER", v=0 },
                                                { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                                { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                                { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                                                { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                                                { n="SPEED", t="FLOAT", v=30.0 },
                                                { n="SPEEDVARIANCE", t="FLOAT", v=10.0 },
                                                { n="RANDOM", t="BOOL", v=false },
                                                { n="LOOP", t="BOOL", v=true },
                                                { n="START", t="BOOL", v=false },
                                                { n="FRAMES", t="INTEGER", v=32 },
                                                { n="IMAGE", t="STRING", v=69 }, --> "NOISE_"
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }, { --SPRITE[2]
                          n="CONTAINER",
                          vars = {
                            { n="NAME", t="STRING", v=70 }, --> "MFDCOMM"
                            { n="WIDTH", t="INTEGER", v=463 },
                            { n="HEIGHT", t="INTEGER", v=375 },
                          },
                          tags = {
                            {    --CONTAINER[1]
                              n="CONTAINER",
                              vars = {
                                { n="NAME", t="STRING", v=71 }, --> "COMM"
                              },
                              tags = {
                                {    --CONTAINER[1]
                                  n="CONTAINER",
                                  tags = {
                                    {    --CONTAINER[1]
                                      n="CONTAINER",
                                      tags = {
                                        {    --CONTAINER[1]
                                          n="CONTAINER",
                                          tags = {
                                            {    --CONTAINER[1]
                                              n="TEXT",
                                              vars = {
                                                { n="NAME", t="STRING", v=72 }, --> "COMMNAME"
                                                { n="FONT", t="STRING", v=30 }, --> "Imagine"
                                                { n="DROPSHADOW", t="BOOL", v=false },
                                                { n="SCALE", t="FLOAT", v=0.80000001192093 },
                                                { n="R", t="FLOAT", v=0.40000000596046 },
                                                { n="G", t="FLOAT", v=1.0 },
                                                { n="B", t="FLOAT", v=0.5 },
                                                { n="BOLD", t="BOOL", v=false },
                                                { n="TEXT", t="TRANSLATE", v=4294967295 }, --> ""
                                                { n="WIDTH", t="INTEGER", v=310 },
                                                { n="HEIGHT", t="INTEGER", v=35 },
                                                { n="X", t="INTEGER", v=42 },
                                                { n="Y", t="INTEGER", v=22 },
                                                { n="TEXT_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                                { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                                { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                                { n="TEXT_VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }, { --CONTAINER[2]
                                      n="SPRITE",
                                      vars = {
                                        { n="IMAGE", t="STRING", v=73 }, --> "ZANDT_MFDOVERLAY"
                                        { n="WIDTH", t="INTEGER", v=463 },
                                        { n="HEIGHT", t="INTEGER", v=375 },
                                      }
                                    }
                                  }
                                }, { --CONTAINER[2]
                                  n="SPRITEANIM",
                                  vars = {
                                    { n="NAME", t="STRING", v=74 }, --> "COMM_IMAGE"
                                    { n="WIDTH", t="INTEGER", v=296 },
                                    { n="HEIGHT", t="INTEGER", v=296 },
                                    { n="X", t="INTEGER", v=104 },
                                    { n="Y", t="INTEGER", v=69 },
                                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                                    { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                                    { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                                    { n="SPEED", t="FLOAT", v=5.0 },
                                    { n="SPEEDVARIANCE", t="FLOAT", v=5.0 },
                                    { n="RANDOM", t="BOOL", v=true },
                                    { n="LOOP", t="BOOL", v=true },
                                    { n="FRAMES", t="INTEGER", v=1 },
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }, { --SPRITE[2]
                  n="CONTAINER",
                  vars = {
                    { n="NAME", t="STRING", v=75 }, --> "STATUSGROUP"
                    { n="WIDTH", t="INTEGER", v=275 },
                    { n="HEIGHT", t="INTEGER", v=236 },
                    { n="X", t="INTEGER", v=740 },
                    { n="Y", t="INTEGER", v=413 },
                  }
                }, { --SPRITE[3]
                  n="CONTAINER",
                  vars = {
                    { n="NAME", t="STRING", v=76 }, --> "SPEEDGROUP"
                    { n="WIDTH", t="INTEGER", v=151 },
                    { n="HEIGHT", t="INTEGER", v=132 },
                    { n="X", t="INTEGER", v=320 },
                    { n="Y", t="INTEGER", v=341 },
                  }
                }, { --SPRITE[4]
                  n="TEXT",
                  vars = {
                    { n="FONT", t="STRING", v=30 }, --> "Imagine"
                    { n="TEXT", t="TRANSLATE", v=77 }, --> "400 "
                    { n="SCALE", t="FLOAT", v=1.2999999523163 },
                    { n="G", t="FLOAT", v=1.0 },
                    { n="B", t="FLOAT", v=0.5 },
                    { n="BOLD", t="BOOL", v=false },
                    { n="NAME", t="STRING", v=78 }, --> "SPEED_SET"
                    { n="WIDTH", t="INTEGER", v=69 },
                    { n="HEIGHT", t="INTEGER", v=21 },
                    { n="X", t="INTEGER", v=381 },
                    { n="Y", t="INTEGER", v=423 },
                    { n="TEXT_ALIGN", t="STRING", v=36 }, --> "RIGHT"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="TEXT_VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                  }
                }, { --SPRITE[5]
                  n="TEXT",
                  vars = {
                    { n="FONT", t="STRING", v=30 }, --> "Imagine"
                    { n="TEXT", t="TRANSLATE", v=79 }, --> "400"
                    { n="SCALE", t="FLOAT", v=1.2999999523163 },
                    { n="R", t="FLOAT", v=0.5 },
                    { n="G", t="FLOAT", v=1.0 },
                    { n="B", t="FLOAT", v=0.40000000596046 },
                    { n="BOLD", t="BOOL", v=false },
                    { n="NAME", t="STRING", v=80 }, --> "SPEED_ACTUAL"
                    { n="WIDTH", t="INTEGER", v=69 },
                    { n="HEIGHT", t="INTEGER", v=21 },
                    { n="X", t="INTEGER", v=381 },
                    { n="Y", t="INTEGER", v=352 },
                    { n="TEXT_ALIGN", t="STRING", v=36 }, --> "RIGHT"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="TEXT_VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                  }
                }, { --SPRITE[6]
                  n="SPRITE",
                  vars = {
                    { n="WIDTH", t="INTEGER", v=275 },
                    { n="HEIGHT", t="INTEGER", v=236 },
                    { n="X", t="INTEGER", v=740 },
                    { n="Y", t="INTEGER", v=413 },
                  },
                  tags = {
                    {    --SPRITE[1]
                      n="SPRITE",
                      vars = {
                        { n="WIDTH", t="INTEGER", v=275 },
                        { n="HEIGHT", t="INTEGER", v=236 },
                        { n="IMAGE", t="STRING", v=81 }, --> "ZANDT_STATUS"
                        { n="BATCH", t="INTEGER", v=1 },
                      },
                      tags = {
                        {    --SPRITE[1]
                          n="CONTAINER",
                          vars = {
                            { n="WIDTH", t="INTEGER", v=275 },
                            { n="HEIGHT", t="INTEGER", v=236 },
                          },
                          tags = {
                            {	-- Missile 1
                              n="SPRITE",
                              vars = {
                                { n="NAME", t="STRING", v=82 }, --> "HARDPOINT_8"
                                { n="WIDTH", t="INTEGER", v=26 },
                                { n="HEIGHT", t="INTEGER", v=34 },
                                { n="X", t="INTEGER", v=110 },
                                { n="Y", t="INTEGER", v=110 },
                                { n="IMAGE", t="STRING", v=55 }, --> "VDUWEAPON_DFLAUNCHER"
                                { n="BATCH", t="INTEGER", v=3 },
                              }
                            },
							{	-- Missile 2
                              n="SPRITE",
                              vars = {
                                { n="NAME", t="STRING", v=272 }, --> "HARDPOINT_9"
                                { n="WIDTH", t="INTEGER", v=26 },
                                { n="HEIGHT", t="INTEGER", v=34 },
                                { n="X", t="INTEGER", v=145 },
                                { n="Y", t="INTEGER", v=110 },
                                { n="IMAGE", t="STRING", v=55 }, --> "VDUWEAPON_DFLAUNCHER"
                                { n="BATCH", t="INTEGER", v=3 },
                              }
                            },
							{	-- Weapon 1
                              n="SPRITE",
                              vars = {
                                { n="NAME", t="STRING", v=83 }, --> "HARDPOINT_0"
                                { n="WIDTH", t="INTEGER", v=13 },
                                { n="HEIGHT", t="INTEGER", v=50 },
                                { n="X", t="INTEGER", v=126 },
                                { n="Y", t="INTEGER", v=48 },
                                { n="IMAGE", t="STRING", v=57 }, --> "VDUWEAPON_LASER"
                                { n="BATCH", t="INTEGER", v=3 },
                              }
                            },
							{	-- Weapon 2
                              n="SPRITE",
                              vars = {
                                { n="NAME", t="STRING", v=84 }, --> "HARDPOINT_1"
                                { n="WIDTH", t="INTEGER", v=13 },
                                { n="HEIGHT", t="INTEGER", v=50 },
                                { n="X", t="INTEGER", v=144 },
                                { n="Y", t="INTEGER", v=48 },
                                { n="IMAGE", t="STRING", v=57 }, --> "VDUWEAPON_LASER"
                                { n="BATCH", t="INTEGER", v=3 },
                              }
                            },
							{	-- Weapon 3
                              n="SPRITE",
                              vars = {
                                { n="NAME", t="STRING", v=85 }, --> "HARDPOINT_2"
                                { n="WIDTH", t="INTEGER", v=13 },
                                { n="HEIGHT", t="INTEGER", v=50 },
                                { n="X", t="INTEGER", v=110 },
                                { n="Y", t="INTEGER", v=55 },
                                { n="IMAGE", t="STRING", v=57 }, --> "VDUWEAPON_LASER"
                                { n="BATCH", t="INTEGER", v=3 },
                              }
                            },
							{	-- Weapon 4
                              n="SPRITE",
                              vars = {
                                { n="NAME", t="STRING", v=86 }, --> "HARDPOINT_3"
                                { n="WIDTH", t="INTEGER", v=13 },
                                { n="HEIGHT", t="INTEGER", v=50 },
                                { n="X", t="INTEGER", v=160 },
                                { n="Y", t="INTEGER", v=55 },
                                { n="IMAGE", t="STRING", v=57 }, --> "VDUWEAPON_LASER"
                                { n="BATCH", t="INTEGER", v=3 },
                              }
                            },
							{	-- Weapon 5
                              n="SPRITE",
                              vars = {
                                { n="NAME", t="STRING", v=270 }, --> "HARDPOINT_4"
                                { n="WIDTH", t="INTEGER", v=13 },
                                { n="HEIGHT", t="INTEGER", v=50 },
                                { n="X", t="INTEGER", v=95 },
                                { n="Y", t="INTEGER", v=75 },
                                { n="IMAGE", t="STRING", v=57 }, --> "VDUWEAPON_LASER"
                                { n="BATCH", t="INTEGER", v=3 },
                              }
                            },
							{	-- Weapon 6
                              n="SPRITE",
                              vars = {
                                { n="NAME", t="STRING", v=271 }, --> "HARDPOINT_5"
                                { n="WIDTH", t="INTEGER", v=13 },
                                { n="HEIGHT", t="INTEGER", v=50 },
                                { n="X", t="INTEGER", v=175 },
                                { n="Y", t="INTEGER", v=75 },
                                { n="IMAGE", t="STRING", v=57 }, --> "VDUWEAPON_LASER"
                                { n="BATCH", t="INTEGER", v=3 },
                              }
                            }
                          }
                        }, { --SPRITE[2]
                          n="SPRITEANIM",
                          vars = {
                            { n="NAME", t="STRING", v=87 }, --> "HULL_TOP"
                            { n="WIDTH", t="INTEGER", v=80 },
                            { n="HEIGHT", t="INTEGER", v=22 },
                            { n="X", t="INTEGER", v=98 },
                            { n="Y", t="INTEGER", v=34 },
                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                            { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                            { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                            { n="IMAGE", t="STRING", v=88 }, --> "ZANDT_HULLTOP_"
                            { n="LOOP", t="BOOL", v=false },
                            { n="FRAMES", t="INTEGER", v=8 },
                            { n="SPEED", t="FLOAT", v=0.0 },
                            { n="BATCH", t="INTEGER", v=1 },
                          }
                        }, { --SPRITE[3]
                          n="SPRITEANIM",
                          vars = {
                            { n="NAME", t="STRING", v=89 }, --> "HULL_BOTTOM"
                            { n="WIDTH", t="INTEGER", v=65 },
                            { n="HEIGHT", t="INTEGER", v=24 },
                            { n="X", t="INTEGER", v=106 },
                            { n="Y", t="INTEGER", v=175 },
                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                            { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                            { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                            { n="IMAGE", t="STRING", v=90 }, --> "ZANDT_HULLDOWN_"
                            { n="LOOP", t="BOOL", v=false },
                            { n="FRAMES", t="INTEGER", v=8 },
                            { n="SPEED", t="FLOAT", v=0.0 },
                            { n="BATCH", t="INTEGER", v=1 },
                          }
                        }, { --SPRITE[4]
                          n="SPRITEANIM",
                          vars = {
                            { n="NAME", t="STRING", v=91 }, --> "HULL_LEFT"
                            { n="WIDTH", t="INTEGER", v=58 },
                            { n="HEIGHT", t="INTEGER", v=108 },
                            { n="X", t="INTEGER", v=48 },
                            { n="Y", t="INTEGER", v=67 },
                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                            { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                            { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                            { n="IMAGE", t="STRING", v=92 }, --> "ZANDT_HULLLEFT_"
                            { n="LOOP", t="BOOL", v=false },
                            { n="FRAMES", t="INTEGER", v=8 },
                            { n="SPEED", t="FLOAT", v=0.0 },
                            { n="BATCH", t="INTEGER", v=1 },
                          }
                        }, { --SPRITE[5]
                          n="SPRITEANIM",
                          vars = {
                            { n="NAME", t="STRING", v=93 }, --> "HULL_RIGHT"
                            { n="WIDTH", t="INTEGER", v=58 },
                            { n="HEIGHT", t="INTEGER", v=108 },
                            { n="X", t="INTEGER", v=171 },
                            { n="Y", t="INTEGER", v=67 },
                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                            { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                            { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                            { n="IMAGE", t="STRING", v=94 }, --> "ZANDT_HULLRIGHT_"
                            { n="LOOP", t="BOOL", v=false },
                            { n="FRAMES", t="INTEGER", v=8 },
                            { n="SPEED", t="FLOAT", v=0.0 },
                            { n="BATCH", t="INTEGER", v=1 },
                          }
                        }, { --SPRITE[6]
                          n="SPRITEANIM",
                          vars = {
                            { n="NAME", t="STRING", v=95 }, --> "SHIELD_TOP"
                            { n="WIDTH", t="INTEGER", v=189 },
                            { n="HEIGHT", t="INTEGER", v=31 },
                            { n="X", t="INTEGER", v=43 },
                            { n="Y", t="INTEGER", v=12 },
                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                            { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                            { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                            { n="IMAGE", t="STRING", v=96 }, --> "ZANDT_SHIELDTOP_"
                            { n="LOOP", t="BOOL", v=false },
                            { n="FRAMES", t="INTEGER", v=8 },
                            { n="SPEED", t="FLOAT", v=0.0 },
                            { n="BATCH", t="INTEGER", v=1 },
                          }
                        }, { --SPRITE[7]
                          n="SPRITEANIM",
                          vars = {
                            { n="NAME", t="STRING", v=97 }, --> "SHIELD_BOTTOM"
                            { n="WIDTH", t="INTEGER", v=189 },
                            { n="HEIGHT", t="INTEGER", v=31 },
                            { n="X", t="INTEGER", v=43 },
                            { n="Y", t="INTEGER", v=191 },
                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                            { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                            { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                            { n="IMAGE", t="STRING", v=98 }, --> "ZANDT_SHIELDDOWN_"
                            { n="LOOP", t="BOOL", v=false },
                            { n="FRAMES", t="INTEGER", v=8 },
                            { n="SPEED", t="FLOAT", v=0.0 },
                            { n="BATCH", t="INTEGER", v=1 },
                          }
                        }, { --SPRITE[8]
                          n="SPRITEANIM",
                          vars = {
                            { n="NAME", t="STRING", v=99 }, --> "SHIELD_LEFT"
                            { n="WIDTH", t="INTEGER", v=37 },
                            { n="HEIGHT", t="INTEGER", v=151 },
                            { n="X", t="INTEGER", v=12 },
                            { n="Y", t="INTEGER", v=43 },
                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                            { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                            { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                            { n="IMAGE", t="STRING", v=100 }, --> "ZANDT_SHIELDLEFT_"
                            { n="LOOP", t="BOOL", v=false },
                            { n="FRAMES", t="INTEGER", v=8 },
                            { n="SPEED", t="FLOAT", v=0.0 },
                            { n="BATCH", t="INTEGER", v=1 },
                          }
                        }, { --SPRITE[9]
                          n="SPRITEANIM",
                          vars = {
                            { n="NAME", t="STRING", v=101 }, --> "SHIELD_RIGHT"
                            { n="WIDTH", t="INTEGER", v=37 },
                            { n="HEIGHT", t="INTEGER", v=151 },
                            { n="X", t="INTEGER", v=228 },
                            { n="Y", t="INTEGER", v=41 },
                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                            { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                            { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                            { n="IMAGE", t="STRING", v=102 }, --> "ZANDT_SHIELDRIGHT_"
                            { n="LOOP", t="BOOL", v=false },
                            { n="FRAMES", t="INTEGER", v=8 },
                            { n="SPEED", t="FLOAT", v=0.0 },
                            { n="BATCH", t="INTEGER", v=1 },
                          }
                        }
                      }
                    }
                  }
                }, { --SPRITE[7]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=103 }, --> "RADARPIPWAYPOINTRED"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=105 }, --> "SMALL_WAYPOINTPULSED"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=0 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[8]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=106 }, --> "RADARPIPWAYPOINTREDSTORY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=107 }, --> "SMALL_WAYPOINTPULSED_IMPORTANT"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=0 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[9]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=108 }, --> "RADARPIPWAYPOINTSECRET"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=109 }, --> "SMALL_WAYPOINTSECRET"
                    { n="R_INT", t="INTEGER", v=196 },
                    { n="G_INT", t="INTEGER", v=110 },
                    { n="B_INT", t="INTEGER", v=255 },
                  }
                }, { --SPRITE[10]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=110 }, --> "RADARPIPWAYPOINTSIGNAL"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=111 }, --> "SMALL_WAYPOINTSIGNAL"
                    { n="R_INT", t="INTEGER", v=196 },
                    { n="G_INT", t="INTEGER", v=110 },
                    { n="B_INT", t="INTEGER", v=255 },
                  }
                }, { --SPRITE[11]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=112 }, --> "RADARPIPWAYPOINTCARGO"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=113 }, --> "SMALL_WAYPOINTSPECIAL"
                    { n="R_INT", t="INTEGER", v=190 },
                    { n="G_INT", t="INTEGER", v=165 },
                    { n="B_INT", t="INTEGER", v=118 },
                  }
                }, { --SPRITE[12]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=114 }, --> "RADARPIPWAYPOINTRELIEF"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=113 }, --> "SMALL_WAYPOINTSPECIAL"
                    { n="R_INT", t="INTEGER", v=190 },
                    { n="G_INT", t="INTEGER", v=165 },
                    { n="B_INT", t="INTEGER", v=118 },
                  }
                }, { --SPRITE[13]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=115 }, --> "RADARPIPWAYPOINTTREATY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=113 }, --> "SMALL_WAYPOINTSPECIAL"
                    { n="R_INT", t="INTEGER", v=190 },
                    { n="G_INT", t="INTEGER", v=165 },
                    { n="B_INT", t="INTEGER", v=118 },
                  }
                }, { --SPRITE[14]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=116 }, --> "RADARPIPWAYPOINTPIRATE"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=117 }, --> "SMALL_WAYPOINTBOUNTY_SPECIAL"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=0 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[15]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=118 }, --> "RADARPIPWAYPOINTINVADER"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=113 }, --> "SMALL_WAYPOINTSPECIAL"
                    { n="R_INT", t="INTEGER", v=190 },
                    { n="G_INT", t="INTEGER", v=165 },
                    { n="B_INT", t="INTEGER", v=118 },
                  }
                }, { --SPRITE[16]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=119 }, --> "RADARPIPWAYPOINTSIEGE"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=113 }, --> "SMALL_WAYPOINTSPECIAL"
                    { n="R_INT", t="INTEGER", v=190 },
                    { n="G_INT", t="INTEGER", v=165 },
                    { n="B_INT", t="INTEGER", v=118 },
                  }
                }, { --SPRITE[17]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=120 }, --> "RADARPIPWAYPOINTASSASSIN"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=113 }, --> "SMALL_WAYPOINTSPECIAL"
                    { n="R_INT", t="INTEGER", v=190 },
                    { n="G_INT", t="INTEGER", v=165 },
                    { n="B_INT", t="INTEGER", v=118 },
                  }
                }, { --SPRITE[18]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=121 }, --> "RADARPIPWAYPOINTCONVOY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=113 }, --> "SMALL_WAYPOINTSPECIAL"
                    { n="R_INT", t="INTEGER", v=190 },
                    { n="G_INT", t="INTEGER", v=165 },
                    { n="B_INT", t="INTEGER", v=118 },
                  }
                }, { --SPRITE[19]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=122 }, --> "RADARPIPWAYPOINTPLAGUE"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=113 }, --> "SMALL_WAYPOINTSPECIAL"
                    { n="R_INT", t="INTEGER", v=190 },
                    { n="G_INT", t="INTEGER", v=165 },
                    { n="B_INT", t="INTEGER", v=118 },
                  }
                }, { --SPRITE[20]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=123 }, --> "RADARPIPWAYPOINTTREASURE"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=113 }, --> "SMALL_WAYPOINTSPECIAL"
                    { n="R_INT", t="INTEGER", v=190 },
                    { n="G_INT", t="INTEGER", v=165 },
                    { n="B_INT", t="INTEGER", v=118 },
                  }
                }, { --SPRITE[21]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=124 }, --> "RADARPIPWAYPOINTBOUNTY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=113 }, --> "SMALL_WAYPOINTSPECIAL"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=0 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[22]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=125 }, --> "RADARPIPWAYPOINTBLUE"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=105 }, --> "SMALL_WAYPOINTPULSED"
                    { n="R_INT", t="INTEGER", v=0 },
                    { n="G_INT", t="INTEGER", v=150 },
                    { n="B_INT", t="INTEGER", v=255 },
                  }
                }, { --SPRITE[23]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=126 }, --> "RADARPIPWAYPOINTBLUESTORY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=127 }, --> "SMALL_WAYPOINTPULSED_PROTECT"
                    { n="R_INT", t="INTEGER", v=0 },
                    { n="G_INT", t="INTEGER", v=150 },
                    { n="B_INT", t="INTEGER", v=255 },
                  }
                }, { --SPRITE[24]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=128 }, --> "RADARPIPSTATION"
                    { n="WIDTH", t="INTEGER", v=30 },
                    { n="HEIGHT", t="INTEGER", v=30 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=129 }, --> "SMALL_WAYPOINTSTATION"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=255 },
                    { n="B_INT", t="INTEGER", v=255 },
                  }
                }, { --SPRITE[25]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=130 }, --> "RADARPIPJUMPGATE"
                    { n="WIDTH", t="INTEGER", v=30 },
                    { n="HEIGHT", t="INTEGER", v=30 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=131 }, --> "SMALL_WAYPOINTJUMPGATE"
                    { n="R_INT", t="INTEGER", v=0 },
                    { n="G_INT", t="INTEGER", v=150 },
                    { n="B_INT", t="INTEGER", v=255 },
                  }
                }, { --SPRITE[26]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=132 }, --> "RADARPIPJUMPGATERISKY"
                    { n="WIDTH", t="INTEGER", v=30 },
                    { n="HEIGHT", t="INTEGER", v=30 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=131 }, --> "SMALL_WAYPOINTJUMPGATE"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=0 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[27]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=133 }, --> "RADARPIPWAYPOINTPURPLE"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=39 }, --> "SMALL_WAYPOINTMISSION"
                    { n="R_INT", t="INTEGER", v=196 },
                    { n="G_INT", t="INTEGER", v=110 },
                    { n="B_INT", t="INTEGER", v=255 },
                  }
                }, { --SPRITE[28]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=134 }, --> "RADARPIPWAYPOINTPURPLETRACKED"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=135 }, --> "SMALL_WAYPOINTMISSION_TRACKED"
                    { n="R_INT", t="INTEGER", v=196 },
                    { n="G_INT", t="INTEGER", v=110 },
                    { n="B_INT", t="INTEGER", v=255 },
                  }
                }, { --SPRITE[29]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=136 }, --> "RADARPIPWAYPOINTBUDDY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=39 }, --> "SMALL_WAYPOINTMISSION"
                    { n="R_INT", t="INTEGER", v=133 },
                    { n="G_INT", t="INTEGER", v=255 },
                    { n="B_INT", t="INTEGER", v=165 },
                  }
                }, { --SPRITE[30]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=137 }, --> "RADARPIPWAYPOINTBUDDYBROKEN"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=39 }, --> "SMALL_WAYPOINTMISSION"
                    { n="R_INT", t="INTEGER", v=133 },
                    { n="G_INT", t="INTEGER", v=255 },
                    { n="B_INT", t="INTEGER", v=165 },
                  }
                }, { --SPRITE[31]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=138 }, --> "RADARPIPWAYPOINTBUDDYB"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=109 }, --> "SMALL_WAYPOINTSECRET"
                    { n="R_INT", t="INTEGER", v=133 },
                    { n="G_INT", t="INTEGER", v=255 },
                    { n="B_INT", t="INTEGER", v=165 },
                  }
                }, { --SPRITE[32]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=139 }, --> "RADARPIPWAYPOINTBUDDYSTORY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=140 }, --> "SMALL_WAYPOINTMISSION_STORY"
                    { n="R_INT", t="INTEGER", v=133 },
                    { n="G_INT", t="INTEGER", v=255 },
                    { n="B_INT", t="INTEGER", v=165 },
                  }
                }, { --SPRITE[33]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=141 }, --> "RADARPIPWAYPOINTBUDDYSTORYBROKEN"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=140 }, --> "SMALL_WAYPOINTMISSION_STORY"
                    { n="R_INT", t="INTEGER", v=133 },
                    { n="G_INT", t="INTEGER", v=255 },
                    { n="B_INT", t="INTEGER", v=165 },
                  }
                }, { --SPRITE[34]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=142 }, --> "RADARPIPWAYPOINTBUDDYTRACKED"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=135 }, --> "SMALL_WAYPOINTMISSION_TRACKED"
                    { n="R_INT", t="INTEGER", v=133 },
                    { n="G_INT", t="INTEGER", v=255 },
                    { n="B_INT", t="INTEGER", v=165 },
                  }
                }, { --SPRITE[35]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=143 }, --> "RADARPIPWAYPOINTBUDDYTRACKEDBROKEN"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=135 }, --> "SMALL_WAYPOINTMISSION_TRACKED"
                    { n="R_INT", t="INTEGER", v=133 },
                    { n="G_INT", t="INTEGER", v=255 },
                    { n="B_INT", t="INTEGER", v=165 },
                  }
                }, { --SPRITE[36]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=144 }, --> "RADARPIPWAYPOINTBUDDYBTRACKED"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=109 }, --> "SMALL_WAYPOINTSECRET"
                    { n="R_INT", t="INTEGER", v=133 },
                    { n="G_INT", t="INTEGER", v=255 },
                    { n="B_INT", t="INTEGER", v=165 },
                  }
                }, { --SPRITE[37]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=145 }, --> "RADARPIPWAYPOINTBUDDYTRACKEDSTORY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=146 }, --> "SMALL_WAYPOINTMISSION_STORY_TRACKED"
                    { n="R_INT", t="INTEGER", v=133 },
                    { n="G_INT", t="INTEGER", v=255 },
                    { n="B_INT", t="INTEGER", v=165 },
                  }
                }, { --SPRITE[38]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=147 }, --> "RADARPIPWAYPOINTBUDDYTRACKEDSTORYBROKEN"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=146 }, --> "SMALL_WAYPOINTMISSION_STORY_TRACKED"
                    { n="R_INT", t="INTEGER", v=133 },
                    { n="G_INT", t="INTEGER", v=255 },
                    { n="B_INT", t="INTEGER", v=165 },
                  }
                }, { --SPRITE[39]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=148 }, --> "RADARPIPWAYPOINTGOLD"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=39 }, --> "SMALL_WAYPOINTMISSION"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=180 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[40]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=149 }, --> "RADARPIPWAYPOINTGOLDBROKEN"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=39 }, --> "SMALL_WAYPOINTMISSION"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=180 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[41]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=150 }, --> "RADARPIPWAYPOINTGOLDB"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=109 }, --> "SMALL_WAYPOINTSECRET"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=180 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[42]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=151 }, --> "RADARPIPWAYPOINTGOLDSTORY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=140 }, --> "SMALL_WAYPOINTMISSION_STORY"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=180 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[43]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=152 }, --> "RADARPIPWAYPOINTGOLDSTORYBROKEN"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=140 }, --> "SMALL_WAYPOINTMISSION_STORY"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=180 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[44]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=153 }, --> "RADARPIPWAYPOINTGOLDTRACKED"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=135 }, --> "SMALL_WAYPOINTMISSION_TRACKED"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=180 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[45]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=154 }, --> "RADARPIPWAYPOINTGOLDTRACKEDBROKEN"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=135 }, --> "SMALL_WAYPOINTMISSION_TRACKED"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=180 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[46]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=155 }, --> "RADARPIPWAYPOINTGOLDBTRACKED"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=109 }, --> "SMALL_WAYPOINTSECRET"
                  }
                }, { --SPRITE[47]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=156 }, --> "RADARPIPWAYPOINTGOLDTRACKEDSTORY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=146 }, --> "SMALL_WAYPOINTMISSION_STORY_TRACKED"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=180 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[48]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=157 }, --> "RADARPIPWAYPOINTGOLDTRACKEDSTORYBROKEN"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=146 }, --> "SMALL_WAYPOINTMISSION_STORY_TRACKED"
                    { n="R_INT", t="INTEGER", v=255 },
                    { n="G_INT", t="INTEGER", v=180 },
                    { n="B_INT", t="INTEGER", v=0 },
                  }
                }, { --SPRITE[49]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=158 }, --> "RADARPIPWAYPOINTVISITED"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=39 }, --> "SMALL_WAYPOINTMISSION"
                    { n="R_INT", t="INTEGER", v=131 },
                    { n="G_INT", t="INTEGER", v=147 },
                    { n="B_INT", t="INTEGER", v=178 },
                  }
                }, { --SPRITE[50]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=159 }, --> "RADARPIPWAYPOINTVISITEDB"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=109 }, --> "SMALL_WAYPOINTSECRET"
                    { n="R_INT", t="INTEGER", v=131 },
                    { n="G_INT", t="INTEGER", v=147 },
                    { n="B_INT", t="INTEGER", v=178 },
                  }
                }, { --SPRITE[51]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=160 }, --> "RADARPIPWAYPOINTVISITEDSTORY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=140 }, --> "SMALL_WAYPOINTMISSION_STORY"
                    { n="R_INT", t="INTEGER", v=131 },
                    { n="G_INT", t="INTEGER", v=147 },
                    { n="B_INT", t="INTEGER", v=178 },
                  }
                }, { --SPRITE[52]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=161 }, --> "RADARPIPWAYPOINTVISITEDTRACKED"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=135 }, --> "SMALL_WAYPOINTMISSION_TRACKED"
                    { n="R_INT", t="INTEGER", v=131 },
                    { n="G_INT", t="INTEGER", v=147 },
                    { n="B_INT", t="INTEGER", v=178 },
                  }
                }, { --SPRITE[53]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=162 }, --> "RADARPIPWAYPOINTVISITEDBTRACKED"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=109 }, --> "SMALL_WAYPOINTSECRET"
                    { n="R_INT", t="INTEGER", v=131 },
                    { n="G_INT", t="INTEGER", v=147 },
                    { n="B_INT", t="INTEGER", v=178 },
                  }
                }, { --SPRITE[54]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=163 }, --> "RADARPIPWAYPOINTVISITEDTRACKEDSTORY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=146 }, --> "SMALL_WAYPOINTMISSION_STORY_TRACKED"
                    { n="R_INT", t="INTEGER", v=131 },
                    { n="G_INT", t="INTEGER", v=147 },
                    { n="B_INT", t="INTEGER", v=178 },
                  }
                }, { --SPRITE[55]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=164 }, --> "RADARPIPWAYPOINTGRAY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=105 }, --> "SMALL_WAYPOINTPULSED"
                    { n="R_INT", t="INTEGER", v=131 },
                    { n="G_INT", t="INTEGER", v=147 },
                    { n="B_INT", t="INTEGER", v=178 },
                  }
                }, { --SPRITE[56]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=165 }, --> "RADARPIPWAYPOINTGRAYSTORY"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=107 }, --> "SMALL_WAYPOINTPULSED_IMPORTANT"
                    { n="R_INT", t="INTEGER", v=131 },
                    { n="G_INT", t="INTEGER", v=147 },
                    { n="B_INT", t="INTEGER", v=178 },
                  }
                }, { --SPRITE[57]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=166 }, --> "RADARPIPWAYPOINTGRAYSTORYPROTECT"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=127 }, --> "SMALL_WAYPOINTPULSED_PROTECT"
                    { n="R_INT", t="INTEGER", v=131 },
                    { n="G_INT", t="INTEGER", v=147 },
                    { n="B_INT", t="INTEGER", v=178 },
                  }
                }, { --SPRITE[58]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=167 }, --> "RADARPIPWAYPOINTWHITE"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=168 }, --> "SMALL_WAYPOINTCUSTOM"
                  }
                }, { --SPRITE[59]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=169 }, --> "RADARPIPWAYPOINTMINEABLE"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=170 }, --> "SMALL_WAYPOINTMINEABLE"
                    { n="R_INT", t="INTEGER", v=190 },
                    { n="G_INT", t="INTEGER", v=165 },
                    { n="B_INT", t="INTEGER", v=118 },
                  }
                }, { --SPRITE[60]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=171 }, --> "RADARPIPMINE"
                    { n="WIDTH", t="INTEGER", v=10 },
                    { n="HEIGHT", t="INTEGER", v=10 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=172 }, --> "MINEPIP"
                  }
                }, { --SPRITE[61]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=173 }, --> "RADARPIPMINEFRIENDLY"
                    { n="WIDTH", t="INTEGER", v=10 },
                    { n="HEIGHT", t="INTEGER", v=10 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=174 }, --> "MINEPIPORANGE"
                  }
                }, { --SPRITE[62]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=175 }, --> "RADARPIPRED"
                    { n="WIDTH", t="INTEGER", v=12 },
                    { n="HEIGHT", t="INTEGER", v=12 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=176 }, --> "REDPIP"
                  }
                }, { --SPRITE[63]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=177 }, --> "RADARPIPREDHOVER"
                    { n="WIDTH", t="INTEGER", v=16 },
                    { n="HEIGHT", t="INTEGER", v=16 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=178 }, --> "REDPIPBRIGHT"
                  }
                }, { --SPRITE[64]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=179 }, --> "RADARPIPREDSELECTED"
                    { n="WIDTH", t="INTEGER", v=24 },
                    { n="HEIGHT", t="INTEGER", v=24 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=180 }, --> "REDPIPSELECTED"
                  }
                }, { --SPRITE[65]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=181 }, --> "TURRETRADARPIPRED"
                    { n="WIDTH", t="INTEGER", v=14 },
                    { n="HEIGHT", t="INTEGER", v=14 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=182 }, --> "REDTURRETPIP"
                  }
                }, { --SPRITE[66]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=183 }, --> "TURRETRADARPIPREDHOVER"
                    { n="WIDTH", t="INTEGER", v=14 },
                    { n="HEIGHT", t="INTEGER", v=14 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=184 }, --> "REDTURRETPIPBRIGHT"
                  }
                }, { --SPRITE[67]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=185 }, --> "TURRETRADARPIPREDSELECTED"
                    { n="WIDTH", t="INTEGER", v=14 },
                    { n="HEIGHT", t="INTEGER", v=14 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=186 }, --> "REDTURRETPIPSELECTED"
                  }
                }, { --SPRITE[68]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=187 }, --> "RADARPIPREDBIG"
                    { n="WIDTH", t="INTEGER", v=18 },
                    { n="HEIGHT", t="INTEGER", v=18 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=176 }, --> "REDPIP"
                  }
                }, { --SPRITE[69]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=188 }, --> "RADARPIPREDBIGSELECTED"
                    { n="WIDTH", t="INTEGER", v=28 },
                    { n="HEIGHT", t="INTEGER", v=28 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=180 }, --> "REDPIPSELECTED"
                  }
                }, { --SPRITE[70]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=189 }, --> "RADARPIPREDBIGHOVER"
                    { n="WIDTH", t="INTEGER", v=20 },
                    { n="HEIGHT", t="INTEGER", v=20 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=178 }, --> "REDPIPBRIGHT"
                  }
                }, { --SPRITE[71]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=190 }, --> "RADARPIPCOMM"
                    { n="WIDTH", t="INTEGER", v=24 },
                    { n="HEIGHT", t="INTEGER", v=24 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=191 }, --> "WHITEPIP"
                  }
                }, { --SPRITE[72]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=192 }, --> "RADARPIPGOLD"
                    { n="WIDTH", t="INTEGER", v=12 },
                    { n="HEIGHT", t="INTEGER", v=12 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=193 }, --> "GOLDPIP"
                  }
                }, { --SPRITE[73]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=194 }, --> "RADARPIPGOLDHOVER"
                    { n="WIDTH", t="INTEGER", v=16 },
                    { n="HEIGHT", t="INTEGER", v=16 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=195 }, --> "GOLDPIPBRIGHT"
                  }
                }, { --SPRITE[74]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=196 }, --> "RADARPIPGOLDSELECTED"
                    { n="WIDTH", t="INTEGER", v=24 },
                    { n="HEIGHT", t="INTEGER", v=24 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=197 }, --> "GOLDPIPSELECTED"
                  }
                }, { --SPRITE[75]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=198 }, --> "RADARPIPGOLDBIG"
                    { n="WIDTH", t="INTEGER", v=18 },
                    { n="HEIGHT", t="INTEGER", v=18 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=193 }, --> "GOLDPIP"
                  }
                }, { --SPRITE[76]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=199 }, --> "RADARPIPGOLDBIGSELECTED"
                    { n="WIDTH", t="INTEGER", v=28 },
                    { n="HEIGHT", t="INTEGER", v=28 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=197 }, --> "GOLDPIPSELECTED"
                  }
                }, { --SPRITE[77]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=200 }, --> "RADARPIPGOLDBIGHOVER"
                    { n="WIDTH", t="INTEGER", v=20 },
                    { n="HEIGHT", t="INTEGER", v=20 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=195 }, --> "GOLDPIPBRIGHT"
                  }
                }, { --SPRITE[78]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=201 }, --> "RADARPIPBLUE"
                    { n="WIDTH", t="INTEGER", v=12 },
                    { n="HEIGHT", t="INTEGER", v=12 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=202 }, --> "BLUEPIP"
                  }
                }, { --SPRITE[79]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=203 }, --> "RADARPIPBLUESELECTED"
                    { n="WIDTH", t="INTEGER", v=24 },
                    { n="HEIGHT", t="INTEGER", v=24 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=204 }, --> "BLUEPIPSELECTED"
                  }
                }, { --SPRITE[80]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=205 }, --> "RADARPIPBLUEHOVER"
                    { n="WIDTH", t="INTEGER", v=16 },
                    { n="HEIGHT", t="INTEGER", v=16 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=206 }, --> "BLUEPIPBRIGHT"
                  }
                }, { --SPRITE[81]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=207 }, --> "TURRETRADARPIPBLUE"
                    { n="WIDTH", t="INTEGER", v=14 },
                    { n="HEIGHT", t="INTEGER", v=14 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=208 }, --> "BLUETURRETPIP"
                  }
                }, { --SPRITE[82]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=209 }, --> "TURRETRADARPIPBLUESELECTED"
                    { n="WIDTH", t="INTEGER", v=14 },
                    { n="HEIGHT", t="INTEGER", v=14 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=210 }, --> "BLUETURRETPIPSELECTED"
                  }
                }, { --SPRITE[83]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=211 }, --> "TURRETRADARPIPBLUEHOVER"
                    { n="WIDTH", t="INTEGER", v=14 },
                    { n="HEIGHT", t="INTEGER", v=14 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=212 }, --> "BLUETURRETPIPBRIGHT"
                  }
                }, { --SPRITE[84]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=213 }, --> "RADARPIPCARGO"
                    { n="WIDTH", t="INTEGER", v=8 },
                    { n="HEIGHT", t="INTEGER", v=8 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=214 }, --> "CARGOPIP"
                  }
                }, { --SPRITE[85]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=215 }, --> "RADARPIPCARGOSELECTED"
                    { n="WIDTH", t="INTEGER", v=8 },
                    { n="HEIGHT", t="INTEGER", v=8 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=216 }, --> "CARGOPIPSELECTED"
                  }
                }, { --SPRITE[86]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=217 }, --> "RADARPIPCARGOHOVER"
                    { n="WIDTH", t="INTEGER", v=8 },
                    { n="HEIGHT", t="INTEGER", v=8 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=218 }, --> "CARGOPIPBRIGHT"
                  }
                }, { --SPRITE[87]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=219 }, --> "RADARPIPORD"
                    { n="WIDTH", t="INTEGER", v=8 },
                    { n="HEIGHT", t="INTEGER", v=8 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=220 }, --> "CARGOPIPPURPLE"
                  }
                }, { --SPRITE[88]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=221 }, --> "RADARPIPORDSELECTED"
                    { n="WIDTH", t="INTEGER", v=8 },
                    { n="HEIGHT", t="INTEGER", v=8 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=222 }, --> "CARGOPIPPURPLESELECTED"
                  }
                }, { --SPRITE[89]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=223 }, --> "RADARPIPORDHOVER"
                    { n="WIDTH", t="INTEGER", v=8 },
                    { n="HEIGHT", t="INTEGER", v=8 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=224 }, --> "CARGOPIPPURPLEBRIGHT"
                  }
                }, { --SPRITE[90]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=225 }, --> "RADARPIPCARGOBIG"
                    { n="WIDTH", t="INTEGER", v=12 },
                    { n="HEIGHT", t="INTEGER", v=12 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=214 }, --> "CARGOPIP"
                  }
                }, { --SPRITE[91]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=226 }, --> "RADARPIPCARGOSELECTEDBIG"
                    { n="WIDTH", t="INTEGER", v=12 },
                    { n="HEIGHT", t="INTEGER", v=12 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=216 }, --> "CARGOPIPSELECTED"
                  }
                }, { --SPRITE[92]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=227 }, --> "RADARPIPCARGOHOVERBIG"
                    { n="WIDTH", t="INTEGER", v=12 },
                    { n="HEIGHT", t="INTEGER", v=12 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=218 }, --> "CARGOPIPBRIGHT"
                  }
                }, { --SPRITE[93]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=228 }, --> "RADARPIPCARGOGOLD"
                    { n="WIDTH", t="INTEGER", v=12 },
                    { n="HEIGHT", t="INTEGER", v=12 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=229 }, --> "CARGOPIPGOLD"
                  }
                }, { --SPRITE[94]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=230 }, --> "RADARPIPCARGOGOLDSELECTED"
                    { n="WIDTH", t="INTEGER", v=12 },
                    { n="HEIGHT", t="INTEGER", v=12 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=231 }, --> "CARGOPIPGOLDSELECTED"
                  }
                }, { --SPRITE[95]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=232 }, --> "RADARPIPCARGOGOLDHOVER"
                    { n="WIDTH", t="INTEGER", v=12 },
                    { n="HEIGHT", t="INTEGER", v=12 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=233 }, --> "CARGOPIPGOLDBRIGHT"
                  }
                }, { --SPRITE[96]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=234 }, --> "RADARPIPCARGORED"
                    { n="WIDTH", t="INTEGER", v=8 },
                    { n="HEIGHT", t="INTEGER", v=8 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=235 }, --> "CARGOPIPRED"
                  }
                }, { --SPRITE[97]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=236 }, --> "RADARPIPCARGOREDSELECTED"
                    { n="WIDTH", t="INTEGER", v=8 },
                    { n="HEIGHT", t="INTEGER", v=8 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=237 }, --> "CARGOPIPREDSELECTED"
                  }
                }, { --SPRITE[98]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=238 }, --> "RADARPIPCARGOREDHOVER"
                    { n="WIDTH", t="INTEGER", v=8 },
                    { n="HEIGHT", t="INTEGER", v=8 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=239 }, --> "CARGOPIPREDBRIGHT"
                  }
                }, { --SPRITE[99]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=240 }, --> "RADARPIPBLUEBIG"
                    { n="WIDTH", t="INTEGER", v=18 },
                    { n="HEIGHT", t="INTEGER", v=18 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=202 }, --> "BLUEPIP"
                  }
                }, { --SPRITE[100]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=241 }, --> "RADARPIPBLUEBIGSELECTED"
                    { n="WIDTH", t="INTEGER", v=28 },
                    { n="HEIGHT", t="INTEGER", v=28 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=204 }, --> "BLUEPIPSELECTED"
                  }
                }, { --SPRITE[101]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=242 }, --> "RADARPIPBLUEBIGHOVER"
                    { n="WIDTH", t="INTEGER", v=20 },
                    { n="HEIGHT", t="INTEGER", v=20 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=206 }, --> "BLUEPIPBRIGHT"
                  }
                }, { --SPRITE[102]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=243 }, --> "RADARPIPGRAY"
                    { n="WIDTH", t="INTEGER", v=8 },
                    { n="HEIGHT", t="INTEGER", v=8 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=244 }, --> "GRAYPIP"
                  }
                }, { --SPRITE[103]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=245 }, --> "RADARPIPGRAYBIG"
                    { n="WIDTH", t="INTEGER", v=16 },
                    { n="HEIGHT", t="INTEGER", v=16 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=244 }, --> "GRAYPIP"
                  }
                }, { --SPRITE[104]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=246 }, --> "RADARPIPGRAYSELECTED"
                    { n="WIDTH", t="INTEGER", v=24 },
                    { n="HEIGHT", t="INTEGER", v=24 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=247 }, --> "GRAYPIPSELECTED"
                  }
                }, { --SPRITE[105]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=248 }, --> "RADARPIPGRAYHOVER"
                    { n="WIDTH", t="INTEGER", v=16 },
                    { n="HEIGHT", t="INTEGER", v=16 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=249 }, --> "GRAYPIPBRIGHT"
                  }
                }, { --SPRITE[106]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=250 }, --> "RADARPIPNEUTRAL"
                    { n="WIDTH", t="INTEGER", v=12 },
                    { n="HEIGHT", t="INTEGER", v=12 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=251 }, --> "NEUTRALPIP"
                  }
                }, { --SPRITE[107]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=252 }, --> "RADARPIPNEUTRALBIG"
                    { n="WIDTH", t="INTEGER", v=16 },
                    { n="HEIGHT", t="INTEGER", v=16 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=251 }, --> "NEUTRALPIP"
                  }
                }, { --SPRITE[108]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=253 }, --> "RADARPIPNEUTRALSELECTED"
                    { n="WIDTH", t="INTEGER", v=24 },
                    { n="HEIGHT", t="INTEGER", v=24 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=254 }, --> "NEUTRALPIPSELECTED"
                  }
                }, { --SPRITE[109]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=255 }, --> "RADARPIPNEUTRALBIGSELECTED"
                    { n="WIDTH", t="INTEGER", v=28 },
                    { n="HEIGHT", t="INTEGER", v=28 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=254 }, --> "NEUTRALPIPSELECTED"
                  }
                }, { --SPRITE[110]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=256 }, --> "RADARPIPNEUTRALHOVER"
                    { n="WIDTH", t="INTEGER", v=16 },
                    { n="HEIGHT", t="INTEGER", v=16 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=257 }, --> "NEUTRALPIPBRIGHT"
                  }
                }, { --SPRITE[111]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=258 }, --> "RADARPIPNEUTRALBIGHOVER"
                    { n="WIDTH", t="INTEGER", v=20 },
                    { n="HEIGHT", t="INTEGER", v=20 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                    { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                    { n="IMAGE", t="STRING", v=257 }, --> "NEUTRALPIPBRIGHT"
                  }
                }, { --SPRITE[112]
                  n="CONTAINER",
                  vars = {
                    { n="NAME", t="STRING", v=259 }, --> "RADARGROUP"
                    { n="WIDTH", t="INTEGER", v=305 },
                    { n="HEIGHT", t="INTEGER", v=305 },
                    { n="X", t="INTEGER", v=14 },
                    { n="Y", t="INTEGER", v=1 },
                  },
                  tags = {
                    {    --CONTAINER[1]
                      n="SPRITE",
                      vars = {
                        { n="NAME", t="STRING", v=260 }, --> "COCKPITRADAR"
                        { n="WIDTH", t="INTEGER", v=300 },
                        { n="HEIGHT", t="INTEGER", v=300 },
                        { n="X", t="INTEGER", v=2 },
                        { n="Y", t="INTEGER", v=2 },
                        { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                        { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                        { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                        { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                      },
                      tags = {
                        {    --SPRITE[1]
                          n="SPRITE",
                          vars = {
                            { n="NAME", t="STRING", v=261 }, --> "COCKPITRADARPULSE"
                            { n="WIDTH", t="INTEGER", v=305 },
                            { n="HEIGHT", t="INTEGER", v=305 },
                            { n="X", t="INTEGER", v=0 },
                            { n="Y", t="INTEGER", v=0 },
                            { n="VERT_ALIGN", t="STRING", v=104 }, --> "CENTER"
                            { n="HORZ_ALIGN", t="STRING", v=104 }, --> "CENTER"
                            { n="ORIGIN_VERT", t="STRING", v=104 }, --> "CENTER"
                            { n="ORIGIN_HORZ", t="STRING", v=104 }, --> "CENTER"
                            { n="IMAGE", t="STRING", v=262 }, --> "RADARPULSERING"
                            { n="ALPHA", t="FLOAT", v=1.0 },
                          }
                        }
                      }
                    }, { --CONTAINER[2]
                      n="CONTAINER",
                      tags = {
                        {    --CONTAINER[1]
                          n="SPRITE",
                          vars = {
                            { n="NAME", t="STRING", v=263 }, --> "RADARRING"
                            { n="WIDTH", t="INTEGER", v=280 },
                            { n="HEIGHT", t="INTEGER", v=280 },
                            { n="X", t="INTEGER", v=13 },
                            { n="Y", t="INTEGER", v=12 },
                            { n="VERT_ALIGN", t="STRING", v=16 }, --> "TOP"
                            { n="HORZ_ALIGN", t="STRING", v=17 }, --> "LEFT"
                            { n="ORIGIN_VERT", t="STRING", v=16 }, --> "TOP"
                            { n="ORIGIN_HORZ", t="STRING", v=17 }, --> "LEFT"
                            { n="IMAGE", t="STRING", v=264 }, --> "RADARBLANK"
                            { n="R_INT", t="INTEGER", v=255 },
                            { n="G_INT", t="INTEGER", v=70 },
                            { n="B_INT", t="INTEGER", v=0 },
                          },
                          tags = {
                            {    --SPRITE[1]
                              n="PANEL_GROUP",
                              vars = {
                                { n="NAME", t="STRING", v=265 }, --> "RADARBATCH"
                                { n="IMAGE", t="STRING", v=266 }, --> "WAYPOINTREDSMALL"
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
return L, content
