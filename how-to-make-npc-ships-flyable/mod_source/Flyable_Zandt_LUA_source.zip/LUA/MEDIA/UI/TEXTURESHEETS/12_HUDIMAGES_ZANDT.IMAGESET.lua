local L = {
  size = 75,
  -- <TRANSLATE>
  -- <STRING>
  [0] = {    1, "media/ui/texturesheets/hudimages_zandt.dds" },
  [1] = {    2, "zandt_mainplate" },
  [2] = {    3, "zandt_mfdoverlay" },
  [3] = {    4, "zandt_vdu" },
  [4] = {    5, "zandt_status" },
  [5] = {    6, "zandt_shieldtop_7" },
  [6] = {    7, "zandt_shieldtop_6" },
  [7] = {    8, "zandt_shieldtop_5" },
  [8] = {    9, "zandt_shieldtop_4" },
  [9] = {   10, "zandt_shieldtop_3" },
  [10] = {   11, "zandt_shieldtop_2" },
  [11] = {   12, "zandt_shieldtop_1" },
  [12] = {   13, "zandt_shieldtop_0" },
  [13] = {   14, "zandt_shielddown_7" },
  [14] = {   15, "zandt_shielddown_6" },
  [15] = {   16, "zandt_shielddown_5" },
  [16] = {   17, "zandt_shielddown_4" },
  [17] = {   18, "zandt_shielddown_3" },
  [18] = {   19, "zandt_shielddown_2" },
  [19] = {   20, "zandt_shielddown_1" },
  [20] = {   21, "zandt_shielddown_0" },
  [21] = {   22, "zandt_hulltop_7" },
  [22] = {   23, "zandt_hulltop_6" },
  [23] = {   24, "zandt_hulltop_5" },
  [24] = {   25, "zandt_hulltop_4" },
  [25] = {   26, "zandt_hulltop_3" },
  [26] = {   27, "zandt_hulltop_2" },
  [27] = {   28, "zandt_hulltop_1" },
  [28] = {   29, "zandt_hulltop_0" },
  [29] = {   30, "zandt_hulldown_7" },
  [30] = {   31, "zandt_hulldown_6" },
  [31] = {   32, "zandt_hulldown_5" },
  [32] = {   33, "zandt_hulldown_4" },
  [33] = {   34, "zandt_hulldown_3" },
  [34] = {   35, "zandt_hulldown_2" },
  [35] = {   36, "zandt_hulldown_1" },
  [36] = {   37, "zandt_hulldown_0" },
  [37] = {   38, "zandt_hullright_7" },
  [38] = {   39, "zandt_hullright_6" },
  [39] = {   40, "zandt_hullright_5" },
  [40] = {   41, "zandt_hullright_4" },
  [41] = {   42, "zandt_hullright_3" },
  [42] = {   43, "zandt_hullright_2" },
  [43] = {   44, "zandt_hullright_1" },
  [44] = {   45, "zandt_hullright_0" },
  [45] = {   46, "zandt_hullleft_7" },
  [46] = {   47, "zandt_hullleft_6" },
  [47] = {   48, "zandt_hullleft_5" },
  [48] = {   49, "zandt_hullleft_4" },
  [49] = {   50, "zandt_hullleft_3" },
  [50] = {   51, "zandt_hullleft_2" },
  [51] = {   52, "zandt_hullleft_1" },
  [52] = {   53, "zandt_hullleft_0" },
  [53] = {   54, "zandt_jump_1" },
  [54] = {   55, "zandt_jump_0" },
  [55] = {   56, "zandt_fuelbar" },
  [56] = {   57, "zandt_auto_1" },
  [57] = {   58, "zandt_auto_0" },
  [58] = {   59, "zandt_shieldright_7" },
  [59] = {   60, "zandt_shieldright_6" },
  [60] = {   61, "zandt_shieldright_5" },
  [61] = {   62, "zandt_shieldright_4" },
  [62] = {   63, "zandt_shieldright_3" },
  [63] = {   64, "zandt_shieldright_2" },
  [64] = {   65, "zandt_shieldright_1" },
  [65] = {   66, "zandt_shieldright_0" },
  [66] = {   67, "zandt_shieldleft_7" },
  [67] = {   68, "zandt_shieldleft_6" },
  [68] = {   69, "zandt_shieldleft_5" },
  [69] = {   70, "zandt_shieldleft_4" },
  [70] = {   71, "zandt_shieldleft_3" },
  [71] = {   72, "zandt_shieldleft_2" },
  [72] = {   73, "zandt_shieldleft_1" },
  [73] = {   74, "zandt_shieldleft_0" },
  [74] = {   75, "zandt_powerbar" },
}
--------------------------------------------------------------------------------
-- n -> name, t -> type, v -> value
local content = {
  n="$990000002",
  vars = {
    { n="FILE", t="STRING", v=0 }, --> "media/ui/texturesheets/hudimages_zandt.dds"
    { n="COUNT", t="INTEGER", v=74 },
    { n="SIZE", t="INTEGER", v=2048 },
  },
  tags = {
    {    --IMAGESET_HUDIMAGES_zandt[1]
      n="IMAGE0",
      vars = {
        { n="NAME", t="STRING", v=1 }, --> "zandt_mainplate"
        { n="X", t="INTEGER", v=2 },
        { n="Y", t="INTEGER", v=2 },
        { n="WIDTH", t="INTEGER", v=1024 },
        { n="HEIGHT", t="INTEGER", v=650 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[2]
      n="IMAGE1",
      vars = {
        { n="NAME", t="STRING", v=2 }, --> "zandt_mfdoverlay"
        { n="X", t="INTEGER", v=1030 },
        { n="Y", t="INTEGER", v=2 },
        { n="WIDTH", t="INTEGER", v=464 },
        { n="HEIGHT", t="INTEGER", v=373 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[3]
      n="IMAGE2",
      vars = {
        { n="NAME", t="STRING", v=3 }, --> "zandt_vdu"
        { n="X", t="INTEGER", v=1498 },
        { n="Y", t="INTEGER", v=2 },
        { n="WIDTH", t="INTEGER", v=288 },
        { n="HEIGHT", t="INTEGER", v=245 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[4]
      n="IMAGE3",
      vars = {
        { n="NAME", t="STRING", v=4 }, --> "zandt_status"
        { n="X", t="INTEGER", v=1498 },
        { n="Y", t="INTEGER", v=251 },
        { n="WIDTH", t="INTEGER", v=275 },
        { n="HEIGHT", t="INTEGER", v=236 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[5]
      n="IMAGE4",
      vars = {
        { n="NAME", t="STRING", v=5 }, --> "zandt_shieldtop_7"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=2 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[6]
      n="IMAGE5",
      vars = {
        { n="NAME", t="STRING", v=6 }, --> "zandt_shieldtop_6"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=37 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[7]
      n="IMAGE6",
      vars = {
        { n="NAME", t="STRING", v=7 }, --> "zandt_shieldtop_5"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=72 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[8]
      n="IMAGE7",
      vars = {
        { n="NAME", t="STRING", v=8 }, --> "zandt_shieldtop_4"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=107 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[9]
      n="IMAGE8",
      vars = {
        { n="NAME", t="STRING", v=9 }, --> "zandt_shieldtop_3"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=142 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[10]
      n="IMAGE9",
      vars = {
        { n="NAME", t="STRING", v=10 }, --> "zandt_shieldtop_2"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=177 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[11]
      n="IMAGE10",
      vars = {
        { n="NAME", t="STRING", v=11 }, --> "zandt_shieldtop_1"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=212 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[12]
      n="IMAGE11",
      vars = {
        { n="NAME", t="STRING", v=12 }, --> "zandt_shieldtop_0"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=247 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[13]
      n="IMAGE12",
      vars = {
        { n="NAME", t="STRING", v=13 }, --> "zandt_shielddown_7"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=282 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[14]
      n="IMAGE13",
      vars = {
        { n="NAME", t="STRING", v=14 }, --> "zandt_shielddown_6"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=317 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[15]
      n="IMAGE14",
      vars = {
        { n="NAME", t="STRING", v=15 }, --> "zandt_shielddown_5"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=352 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[16]
      n="IMAGE15",
      vars = {
        { n="NAME", t="STRING", v=16 }, --> "zandt_shielddown_4"
        { n="X", t="INTEGER", v=1030 },
        { n="Y", t="INTEGER", v=379 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[17]
      n="IMAGE16",
      vars = {
        { n="NAME", t="STRING", v=17 }, --> "zandt_shielddown_3"
        { n="X", t="INTEGER", v=1223 },
        { n="Y", t="INTEGER", v=379 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[18]
      n="IMAGE17",
      vars = {
        { n="NAME", t="STRING", v=18 }, --> "zandt_shielddown_2"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=387 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[19]
      n="IMAGE18",
      vars = {
        { n="NAME", t="STRING", v=19 }, --> "zandt_shielddown_1"
        { n="X", t="INTEGER", v=1030 },
        { n="Y", t="INTEGER", v=414 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[20]
      n="IMAGE19",
      vars = {
        { n="NAME", t="STRING", v=20 }, --> "zandt_shielddown_0"
        { n="X", t="INTEGER", v=1223 },
        { n="Y", t="INTEGER", v=414 },
        { n="WIDTH", t="INTEGER", v=189 },
        { n="HEIGHT", t="INTEGER", v=31 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[21]
      n="IMAGE20",
      vars = {
        { n="NAME", t="STRING", v=21 }, --> "zandt_hulltop_7"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=422 },
        { n="WIDTH", t="INTEGER", v=80 },
        { n="HEIGHT", t="INTEGER", v=22 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[22]
      n="IMAGE21",
      vars = {
        { n="NAME", t="STRING", v=22 }, --> "zandt_hulltop_6"
        { n="X", t="INTEGER", v=1874 },
        { n="Y", t="INTEGER", v=422 },
        { n="WIDTH", t="INTEGER", v=80 },
        { n="HEIGHT", t="INTEGER", v=22 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[23]
      n="IMAGE22",
      vars = {
        { n="NAME", t="STRING", v=23 }, --> "zandt_hulltop_5"
        { n="X", t="INTEGER", v=1958 },
        { n="Y", t="INTEGER", v=422 },
        { n="WIDTH", t="INTEGER", v=80 },
        { n="HEIGHT", t="INTEGER", v=22 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[24]
      n="IMAGE23",
      vars = {
        { n="NAME", t="STRING", v=24 }, --> "zandt_hulltop_4"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=448 },
        { n="WIDTH", t="INTEGER", v=80 },
        { n="HEIGHT", t="INTEGER", v=22 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[25]
      n="IMAGE24",
      vars = {
        { n="NAME", t="STRING", v=25 }, --> "zandt_hulltop_3"
        { n="X", t="INTEGER", v=1874 },
        { n="Y", t="INTEGER", v=448 },
        { n="WIDTH", t="INTEGER", v=80 },
        { n="HEIGHT", t="INTEGER", v=22 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[26]
      n="IMAGE25",
      vars = {
        { n="NAME", t="STRING", v=26 }, --> "zandt_hulltop_2"
        { n="X", t="INTEGER", v=1958 },
        { n="Y", t="INTEGER", v=448 },
        { n="WIDTH", t="INTEGER", v=80 },
        { n="HEIGHT", t="INTEGER", v=22 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[27]
      n="IMAGE26",
      vars = {
        { n="NAME", t="STRING", v=27 }, --> "zandt_hulltop_1"
        { n="X", t="INTEGER", v=1030 },
        { n="Y", t="INTEGER", v=449 },
        { n="WIDTH", t="INTEGER", v=80 },
        { n="HEIGHT", t="INTEGER", v=22 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[28]
      n="IMAGE27",
      vars = {
        { n="NAME", t="STRING", v=28 }, --> "zandt_hulltop_0"
        { n="X", t="INTEGER", v=1114 },
        { n="Y", t="INTEGER", v=449 },
        { n="WIDTH", t="INTEGER", v=80 },
        { n="HEIGHT", t="INTEGER", v=22 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[29]
      n="IMAGE28",
      vars = {
        { n="NAME", t="STRING", v=29 }, --> "zandt_hulldown_7"
        { n="X", t="INTEGER", v=1416 },
        { n="Y", t="INTEGER", v=379 },
        { n="WIDTH", t="INTEGER", v=65 },
        { n="HEIGHT", t="INTEGER", v=24 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[30]
      n="IMAGE29",
      vars = {
        { n="NAME", t="STRING", v=30 }, --> "zandt_hulldown_6"
        { n="X", t="INTEGER", v=1416 },
        { n="Y", t="INTEGER", v=407 },
        { n="WIDTH", t="INTEGER", v=65 },
        { n="HEIGHT", t="INTEGER", v=24 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[31]
      n="IMAGE30",
      vars = {
        { n="NAME", t="STRING", v=31 }, --> "zandt_hulldown_5"
        { n="X", t="INTEGER", v=1416 },
        { n="Y", t="INTEGER", v=435 },
        { n="WIDTH", t="INTEGER", v=65 },
        { n="HEIGHT", t="INTEGER", v=24 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[32]
      n="IMAGE31",
      vars = {
        { n="NAME", t="STRING", v=32 }, --> "zandt_hulldown_4"
        { n="X", t="INTEGER", v=1198 },
        { n="Y", t="INTEGER", v=449 },
        { n="WIDTH", t="INTEGER", v=65 },
        { n="HEIGHT", t="INTEGER", v=24 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[33]
      n="IMAGE32",
      vars = {
        { n="NAME", t="STRING", v=33 }, --> "zandt_hulldown_3"
        { n="X", t="INTEGER", v=1267 },
        { n="Y", t="INTEGER", v=449 },
        { n="WIDTH", t="INTEGER", v=65 },
        { n="HEIGHT", t="INTEGER", v=24 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[34]
      n="IMAGE33",
      vars = {
        { n="NAME", t="STRING", v=34 }, --> "zandt_hulldown_2"
        { n="X", t="INTEGER", v=1336 },
        { n="Y", t="INTEGER", v=449 },
        { n="WIDTH", t="INTEGER", v=65 },
        { n="HEIGHT", t="INTEGER", v=24 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[35]
      n="IMAGE34",
      vars = {
        { n="NAME", t="STRING", v=35 }, --> "zandt_hulldown_1"
        { n="X", t="INTEGER", v=1416 },
        { n="Y", t="INTEGER", v=463 },
        { n="WIDTH", t="INTEGER", v=65 },
        { n="HEIGHT", t="INTEGER", v=24 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[36]
      n="IMAGE35",
      vars = {
        { n="NAME", t="STRING", v=36 }, --> "zandt_hulldown_0"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=474 },
        { n="WIDTH", t="INTEGER", v=65 },
        { n="HEIGHT", t="INTEGER", v=24 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[37]
      n="IMAGE36",
      vars = {
        { n="NAME", t="STRING", v=37 }, --> "zandt_hullright_7"
        { n="X", t="INTEGER", v=1983 },
        { n="Y", t="INTEGER", v=2 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[38]
      n="IMAGE37",
      vars = {
        { n="NAME", t="STRING", v=38 }, --> "zandt_hullright_6"
        { n="X", t="INTEGER", v=1983 },
        { n="Y", t="INTEGER", v=114 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[39]
      n="IMAGE38",
      vars = {
        { n="NAME", t="STRING", v=39 }, --> "zandt_hullright_5"
        { n="X", t="INTEGER", v=1983 },
        { n="Y", t="INTEGER", v=226 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[40]
      n="IMAGE39",
      vars = {
        { n="NAME", t="STRING", v=40 }, --> "zandt_hullright_4"
        { n="X", t="INTEGER", v=1859 },
        { n="Y", t="INTEGER", v=474 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[41]
      n="IMAGE40",
      vars = {
        { n="NAME", t="STRING", v=41 }, --> "zandt_hullright_3"
        { n="X", t="INTEGER", v=1921 },
        { n="Y", t="INTEGER", v=474 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[42]
      n="IMAGE41",
      vars = {
        { n="NAME", t="STRING", v=42 }, --> "zandt_hullright_2"
        { n="X", t="INTEGER", v=1983 },
        { n="Y", t="INTEGER", v=474 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[43]
      n="IMAGE42",
      vars = {
        { n="NAME", t="STRING", v=43 }, --> "zandt_hullright_1"
        { n="X", t="INTEGER", v=1030 },
        { n="Y", t="INTEGER", v=475 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[44]
      n="IMAGE43",
      vars = {
        { n="NAME", t="STRING", v=44 }, --> "zandt_hullright_0"
        { n="X", t="INTEGER", v=1092 },
        { n="Y", t="INTEGER", v=475 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[45]
      n="IMAGE44",
      vars = {
        { n="NAME", t="STRING", v=45 }, --> "zandt_hullleft_7"
        { n="X", t="INTEGER", v=1154 },
        { n="Y", t="INTEGER", v=475 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[46]
      n="IMAGE45",
      vars = {
        { n="NAME", t="STRING", v=46 }, --> "zandt_hullleft_6"
        { n="X", t="INTEGER", v=1216 },
        { n="Y", t="INTEGER", v=475 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[47]
      n="IMAGE46",
      vars = {
        { n="NAME", t="STRING", v=47 }, --> "zandt_hullleft_5"
        { n="X", t="INTEGER", v=1278 },
        { n="Y", t="INTEGER", v=475 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[48]
      n="IMAGE47",
      vars = {
        { n="NAME", t="STRING", v=48 }, --> "zandt_hullleft_4"
        { n="X", t="INTEGER", v=1340 },
        { n="Y", t="INTEGER", v=475 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[49]
      n="IMAGE48",
      vars = {
        { n="NAME", t="STRING", v=49 }, --> "zandt_hullleft_3"
        { n="X", t="INTEGER", v=1416 },
        { n="Y", t="INTEGER", v=491 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[50]
      n="IMAGE49",
      vars = {
        { n="NAME", t="STRING", v=50 }, --> "zandt_hullleft_2"
        { n="X", t="INTEGER", v=1478 },
        { n="Y", t="INTEGER", v=491 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[51]
      n="IMAGE50",
      vars = {
        { n="NAME", t="STRING", v=51 }, --> "zandt_hullleft_1"
        { n="X", t="INTEGER", v=1540 },
        { n="Y", t="INTEGER", v=491 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[52]
      n="IMAGE51",
      vars = {
        { n="NAME", t="STRING", v=52 }, --> "zandt_hullleft_0"
        { n="X", t="INTEGER", v=1602 },
        { n="Y", t="INTEGER", v=491 },
        { n="WIDTH", t="INTEGER", v=58 },
        { n="HEIGHT", t="INTEGER", v=108 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[53]
      n="IMAGE52",
      vars = {
        { n="NAME", t="STRING", v=53 }, --> "zandt_jump_1"
        { n="X", t="INTEGER", v=1664 },
        { n="Y", t="INTEGER", v=491 },
        { n="WIDTH", t="INTEGER", v=44 },
        { n="HEIGHT", t="INTEGER", v=90 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[54]
      n="IMAGE53",
      vars = {
        { n="NAME", t="STRING", v=54 }, --> "zandt_jump_0"
        { n="X", t="INTEGER", v=1712 },
        { n="Y", t="INTEGER", v=491 },
        { n="WIDTH", t="INTEGER", v=44 },
        { n="HEIGHT", t="INTEGER", v=90 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[55]
      n="IMAGE54",
      vars = {
        { n="NAME", t="STRING", v=55 }, --> "zandt_fuelbar"
        { n="X", t="INTEGER", v=1790 },
        { n="Y", t="INTEGER", v=502 },
        { n="WIDTH", t="INTEGER", v=44 },
        { n="HEIGHT", t="INTEGER", v=196 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[56]
      n="IMAGE55",
      vars = {
        { n="NAME", t="STRING", v=56 }, --> "zandt_auto_1"
        { n="X", t="INTEGER", v=1664 },
        { n="Y", t="INTEGER", v=585 },
        { n="WIDTH", t="INTEGER", v=43 },
        { n="HEIGHT", t="INTEGER", v=89 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[57]
      n="IMAGE56",
      vars = {
        { n="NAME", t="STRING", v=57 }, --> "zandt_auto_0"
        { n="X", t="INTEGER", v=1711 },
        { n="Y", t="INTEGER", v=585 },
        { n="WIDTH", t="INTEGER", v=43 },
        { n="HEIGHT", t="INTEGER", v=89 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[58]
      n="IMAGE57",
      vars = {
        { n="NAME", t="STRING", v=58 }, --> "zandt_shieldright_7"
        { n="X", t="INTEGER", v=1859 },
        { n="Y", t="INTEGER", v=586 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[59]
      n="IMAGE58",
      vars = {
        { n="NAME", t="STRING", v=59 }, --> "zandt_shieldright_6"
        { n="X", t="INTEGER", v=1900 },
        { n="Y", t="INTEGER", v=586 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[60]
      n="IMAGE59",
      vars = {
        { n="NAME", t="STRING", v=60 }, --> "zandt_shieldright_5"
        { n="X", t="INTEGER", v=1941 },
        { n="Y", t="INTEGER", v=586 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[61]
      n="IMAGE60",
      vars = {
        { n="NAME", t="STRING", v=61 }, --> "zandt_shieldright_4"
        { n="X", t="INTEGER", v=1982 },
        { n="Y", t="INTEGER", v=586 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[62]
      n="IMAGE61",
      vars = {
        { n="NAME", t="STRING", v=62 }, --> "zandt_shieldright_3"
        { n="X", t="INTEGER", v=1030 },
        { n="Y", t="INTEGER", v=587 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[63]
      n="IMAGE62",
      vars = {
        { n="NAME", t="STRING", v=63 }, --> "zandt_shieldright_2"
        { n="X", t="INTEGER", v=1071 },
        { n="Y", t="INTEGER", v=587 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[64]
      n="IMAGE63",
      vars = {
        { n="NAME", t="STRING", v=64 }, --> "zandt_shieldright_1"
        { n="X", t="INTEGER", v=1112 },
        { n="Y", t="INTEGER", v=587 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[65]
      n="IMAGE64",
      vars = {
        { n="NAME", t="STRING", v=65 }, --> "zandt_shieldright_0"
        { n="X", t="INTEGER", v=1153 },
        { n="Y", t="INTEGER", v=587 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[66]
      n="IMAGE65",
      vars = {
        { n="NAME", t="STRING", v=66 }, --> "zandt_shieldleft_7"
        { n="X", t="INTEGER", v=1194 },
        { n="Y", t="INTEGER", v=587 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[67]
      n="IMAGE66",
      vars = {
        { n="NAME", t="STRING", v=67 }, --> "zandt_shieldleft_6"
        { n="X", t="INTEGER", v=1235 },
        { n="Y", t="INTEGER", v=587 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[68]
      n="IMAGE67",
      vars = {
        { n="NAME", t="STRING", v=68 }, --> "zandt_shieldleft_5"
        { n="X", t="INTEGER", v=1276 },
        { n="Y", t="INTEGER", v=587 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[69]
      n="IMAGE68",
      vars = {
        { n="NAME", t="STRING", v=69 }, --> "zandt_shieldleft_4"
        { n="X", t="INTEGER", v=1317 },
        { n="Y", t="INTEGER", v=587 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[70]
      n="IMAGE69",
      vars = {
        { n="NAME", t="STRING", v=70 }, --> "zandt_shieldleft_3"
        { n="X", t="INTEGER", v=1358 },
        { n="Y", t="INTEGER", v=587 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[71]
      n="IMAGE70",
      vars = {
        { n="NAME", t="STRING", v=71 }, --> "zandt_shieldleft_2"
        { n="X", t="INTEGER", v=1416 },
        { n="Y", t="INTEGER", v=603 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[72]
      n="IMAGE71",
      vars = {
        { n="NAME", t="STRING", v=72 }, --> "zandt_shieldleft_1"
        { n="X", t="INTEGER", v=1457 },
        { n="Y", t="INTEGER", v=603 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[73]
      n="IMAGE72",
      vars = {
        { n="NAME", t="STRING", v=73 }, --> "zandt_shieldleft_0"
        { n="X", t="INTEGER", v=1498 },
        { n="Y", t="INTEGER", v=603 },
        { n="WIDTH", t="INTEGER", v=37 },
        { n="HEIGHT", t="INTEGER", v=151 },
      }
    }, { --IMAGESET_HUDIMAGES_zandt[74]
      n="IMAGE73",
      vars = {
        { n="NAME", t="STRING", v=74 }, --> "zandt_powerbar"
        { n="X", t="INTEGER", v=1760 },
        { n="Y", t="INTEGER", v=491 },
        { n="WIDTH", t="INTEGER", v=26 },
        { n="HEIGHT", t="INTEGER", v=462 },
      }
    }
  }
}
return L, content
