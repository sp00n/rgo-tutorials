local L = {
  size = 64,
  -- <TRANSLATE>
  -- <STRING>
  [0] = {    1, "RETICLEROOT" },
  [1] = {    2, "BATCHCONTROLS" },
  [2] = {    3, "VDUHARDPOINT_ACTIVE" },
  [3] = {    4, "RETICLES" },
  [4] = {    5, "RETICLE" },
  [5] = {    6, "TOP" },
  [6] = {    7, "LEFT" },
  [7] = {    8, "CENTER" },
  [8] = {    9, "MEDIUMFIGHTERB_RETICLE_" },
  [9] = {   10, "ECMHARDPOINT" },
  [10] = {   11, "VDUECM_" },
  [11] = {   12, "HARDPOINT_0" },
  [12] = {   13, "VDUHARDPOINT_" },
  [13] = {   14, "HARDPOINTACTIVE_0" },
  [14] = {   15, "HARDPOINT_1" },
  [15] = {   16, "HARDPOINTACTIVE_1" },
  [16] = {   17, "HARDPOINT_2" },
  [17] = {   18, "HARDPOINTACTIVE_2" },
  [18] = {   19, "HARDPOINT_3" },
  [19] = {   20, "HARDPOINTACTIVE_3" },
  [20] = {   21, "HARDPOINT_8" },
  [21] = {   22, "VDUMHARDPOINT_" },
  [22] = {   23, "HARDPOINTACTIVE_8" },
  [23] = {   24, "VDUMHARDPOINT_ACTIVE" },
  [24] = {   25, "HARDPOINTRELOAD_8" },
  [25] = {   26, "VDUMCONTAINER_" },
  [26] = {   27, "HARDPOINT_9" },
  [27] = {   28, "HARDPOINTACTIVE_9" },
  [28] = {   29, "HARDPOINTRELOAD_9" },
  [29] = {   30, "RETICLEMID" },
  [30] = {   31, "ITTS_PIPMIDPOINT" },
  [31] = {   32, "RETICLELEAD_0" },
  [32] = {   33, "ITTS_PIP1" },
  [33] = {   34, "RETICLELEAD_1" },
  [34] = {   35, "RETICLELEAD_2" },
  [35] = {   36, "RETICLELEAD_3" },
  [36] = {   37, "RETICLELEAD_4" },
  [37] = {   38, "RETICLELEAD_5" },
  [38] = {   39, "RETICLELEAD_6" },
  [39] = {   40, "RETICLELEAD_7" },
  [40] = {   41, "RETICLELEAD_8" },
  [41] = {   42, "OFFSCREENINDICATOR" },
  [42] = {   43, "OFFSCREENINDICATOR_" },
  [43] = {   44, "MOUSEINDICATOR" },
  [44] = {   45, "MOUSEDEADZONE" },
  [45] = {   46, "MOUSERING" },
  [46] = {   47, "MOUSEPIP" },
  [47] = {   48, "HUDROOT" },
  [48] = {   49, "HUDSCREEN" },
  [49] = {   50, "MFDGROUP" },
  [50] = {   51, "BOTTOM" },
  [51] = {   52, "RIGHT" },
  [52] = {   53, "MAINMFD" },
  [53] = {   54, "RADARBLANK" },
  [54] = {   55, "RADARGROUP" },
  [55] = {   56, "POWERMFD" },
  [56] = {   57, "FUELMFD" },
  [57] = {   58, "SPEEDMFD" },
  [58] = {   59, "STATUSMFD" },
  [59] = {   60, "RADARMFD" },
  [60] = {   61, "HARDPOINT_4" },
  [61] = {   62, "HARDPOINTACTIVE_4" },
  [62] = {   63, "HARDPOINT_5" },
  [63] = {   64, "HARDPOINTACTIVE_5" },
}
--------------------------------------------------------------------------------
-- n -> name, t -> type, v -> value
local content = {
  n="UI",
  vars = {
    { n="RESX", t="INTEGER", v=1920 },
    { n="RESY", t="INTEGER", v=1080 },
    { n="ZORDER", t="INTEGER", v=500 },
  },
  tags = {
    {    --UI[1]
      n="CONTAINER",
      vars = {
        { n="NAME", t="STRING", v=0 }, --> "RETICLEROOT"
        { n="WIDTH_PERCENT", t="FLOAT", v=1.0 },
        { n="HEIGHT_PERCENT", t="FLOAT", v=1.0 },
        { n="X", t="INTEGER", v=0 },
        { n="Y", t="INTEGER", v=0 },
      },
      tags = {
        {    --CONTAINER[1]
          n="PANEL_GROUP",
          vars = {
            { n="NAME", t="STRING", v=1 }, --> "BATCHCONTROLS"
            { n="IMAGE", t="STRING", v=2 }, --> "VDUHARDPOINT_ACTIVE"
            { n="BATCH", t="INTEGER", v=3 },
            { n="SORTOFFSET", t="INTEGER", v=2 },
          }
        }, { --CONTAINER[2]
          n="CONTAINER",
          vars = {
            { n="NAME", t="STRING", v=3 }, --> "RETICLES"
            { n="WIDTH_PERCENT", t="FLOAT", v=1.0 },
            { n="HEIGHT_PERCENT", t="FLOAT", v=1.0 },
            { n="X", t="INTEGER", v=0 },
            { n="Y", t="INTEGER", v=0 },
          },
          tags = {
            {    --CONTAINER[1]
              n="SPRITEANIM",
              vars = {
                { n="NAME", t="STRING", v=4 }, --> "RETICLE"
                { n="WIDTH", t="INTEGER", v=192 },
                { n="HEIGHT", t="INTEGER", v=192 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=8 }, --> "MEDIUMFIGHTERB_RETICLE_"
                { n="LOOP", t="BOOL", v=false },
                { n="FRAMES", t="INTEGER", v=2 },
                { n="SPEED", t="FLOAT", v=0.0 },
                { n="BATCH", t="INTEGER", v=3 },
              },
              tags = {
                {    --SPRITEANIM[1]
                  n="SPRITEANIM",
                  vars = {
                    { n="NAME", t="STRING", v=9 }, --> "ECMHARDPOINT"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=80 },
                    { n="Y", t="INTEGER", v=100 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=10 }, --> "VDUECM_"
                    { n="LOOP", t="BOOL", v=false },
                    { n="FRAMES", t="INTEGER", v=3 },
                    { n="SPEED", t="FLOAT", v=0.0 },
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Weapon 1 Inactive
                  n="SPRITEANIM",
                  vars = {
                    { n="NAME", t="STRING", v=11 }, --> "HARDPOINT_0"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=55 },
                    { n="Y", t="INTEGER", v=125 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=12 }, --> "VDUHARDPOINT_"
                    { n="LOOP", t="BOOL", v=false },
                    { n="FRAMES", t="INTEGER", v=32 },
                    { n="SPEED", t="FLOAT", v=0.0 },
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Weapon 1 Active
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=13 }, --> "HARDPOINTACTIVE_0"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=55 },
                    { n="Y", t="INTEGER", v=125 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=2 }, --> "VDUHARDPOINT_ACTIVE"
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Weapon 2 Inactive
                  n="SPRITEANIM",
                  vars = {
                    { n="NAME", t="STRING", v=14 }, --> "HARDPOINT_1"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=105 },
                    { n="Y", t="INTEGER", v=125 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=12 }, --> "VDUHARDPOINT_"
                    { n="LOOP", t="BOOL", v=false },
                    { n="FRAMES", t="INTEGER", v=32 },
                    { n="SPEED", t="FLOAT", v=0.0 },
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Weapon 2 Active
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=15 }, --> "HARDPOINTACTIVE_1"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=105 },
                    { n="Y", t="INTEGER", v=125 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=2 }, --> "VDUHARDPOINT_ACTIVE"
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Weapon 3 Inactive
                  n="SPRITEANIM",
                  vars = {
                    { n="NAME", t="STRING", v=16 }, --> "HARDPOINT_2"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=40 },
                    { n="Y", t="INTEGER", v=113 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=12 }, --> "VDUHARDPOINT_"
                    { n="LOOP", t="BOOL", v=false },
                    { n="FRAMES", t="INTEGER", v=32 },
                    { n="SPEED", t="FLOAT", v=0.0 },
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Weapon 3 Active
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=17 }, --> "HARDPOINTACTIVE_2"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=40 },
                    { n="Y", t="INTEGER", v=113 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=2 }, --> "VDUHARDPOINT_ACTIVE"
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Weapon 4 Inactive
                  n="SPRITEANIM",
                  vars = {
                    { n="NAME", t="STRING", v=18 }, --> "HARDPOINT_3"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=120 },
                    { n="Y", t="INTEGER", v=113 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=12 }, --> "VDUHARDPOINT_"
                    { n="LOOP", t="BOOL", v=false },
                    { n="FRAMES", t="INTEGER", v=32 },
                    { n="SPEED", t="FLOAT", v=0.0 },
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Weapon 4 Active
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=19 }, --> "HARDPOINTACTIVE_3"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=120 },
                    { n="Y", t="INTEGER", v=113 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=2 }, --> "VDUHARDPOINT_ACTIVE"
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Weapon 5 Inactive
                  n="SPRITEANIM",
                  vars = {
                    { n="NAME", t="STRING", v=60 }, --> "HARDPOINT_4"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=31 },
                    { n="Y", t="INTEGER", v=96 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=12 }, --> "VDUHARDPOINT_"
                    { n="LOOP", t="BOOL", v=false },
                    { n="FRAMES", t="INTEGER", v=32 },
                    { n="SPEED", t="FLOAT", v=0.0 },
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Weapon 5 Active
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=61 }, --> "HARDPOINTACTIVE_4"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=31 },
                    { n="Y", t="INTEGER", v=96 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=2 }, --> "VDUHARDPOINT_ACTIVE"
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Weapon 6 Inactive
                  n="SPRITEANIM",
                  vars = {
                    { n="NAME", t="STRING", v=62 }, --> "HARDPOINT_5"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=129 },
                    { n="Y", t="INTEGER", v=96 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=12 }, --> "VDUHARDPOINT_"
                    { n="LOOP", t="BOOL", v=false },
                    { n="FRAMES", t="INTEGER", v=32 },
                    { n="SPEED", t="FLOAT", v=0.0 },
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Weapon 6 Active
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=63 }, --> "HARDPOINTACTIVE_5"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=129 },
                    { n="Y", t="INTEGER", v=96 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=2 }, --> "VDUHARDPOINT_ACTIVE"
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Missile 1 Inactive
                  n="SPRITEANIM",
                  vars = {
                    { n="NAME", t="STRING", v=20 }, --> "HARDPOINT_8"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=60 },
                    { n="Y", t="INTEGER", v=46 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=21 }, --> "VDUMHARDPOINT_"
                    { n="LOOP", t="BOOL", v=false },
                    { n="FRAMES", t="INTEGER", v=29 },
                    { n="SPEED", t="FLOAT", v=0.0 },
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Missile 1 Active
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=22 }, --> "HARDPOINTACTIVE_8"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=60 },
                    { n="Y", t="INTEGER", v=46 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=23 }, --> "VDUMHARDPOINT_ACTIVE"
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Missile 1 Reloading
                  n="SPRITEANIM",
                  vars = {
                    { n="NAME", t="STRING", v=24 }, --> "HARDPOINTRELOAD_8"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=60 },
                    { n="Y", t="INTEGER", v=46 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=25 }, --> "VDUMCONTAINER_"
                    { n="FRAMES", t="INTEGER", v=4 },
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Missile 1 Inactive
                  n="SPRITEANIM",
                  vars = {
                    { n="NAME", t="STRING", v=26 }, --> "HARDPOINT_9"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=100 },
                    { n="Y", t="INTEGER", v=46 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=21 }, --> "VDUMHARDPOINT_"
                    { n="LOOP", t="BOOL", v=false },
                    { n="FRAMES", t="INTEGER", v=29 },
                    { n="SPEED", t="FLOAT", v=0.0 },
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Missile 1 Active
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=27 }, --> "HARDPOINTACTIVE_9"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=100 },
                    { n="Y", t="INTEGER", v=46 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=23 }, --> "VDUMHARDPOINT_ACTIVE"
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                },
				{	-- Missile 1 Reloading
                  n="SPRITEANIM",
                  vars = {
                    { n="NAME", t="STRING", v=28 }, --> "HARDPOINTRELOAD_9"
                    { n="WIDTH", t="INTEGER", v=32 },
                    { n="HEIGHT", t="INTEGER", v=32 },
                    { n="X", t="INTEGER", v=100 },
                    { n="Y", t="INTEGER", v=46 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=25 }, --> "VDUMCONTAINER_"
                    { n="FRAMES", t="INTEGER", v=4 },
                    { n="BATCH", t="INTEGER", v=3 },
                  }
                }
              }
            }, { --CONTAINER[2]
              n="SPRITE",
              vars = {
                { n="NAME", t="STRING", v=29 }, --> "RETICLEMID"
                { n="WIDTH", t="INTEGER", v=14 },
                { n="HEIGHT", t="INTEGER", v=14 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=30 }, --> "ITTS_PIPMIDPOINT"
                { n="BATCH", t="INTEGER", v=3 },
              }
            }, { --CONTAINER[3]
              n="SPRITE",
              vars = {
                { n="NAME", t="STRING", v=31 }, --> "RETICLELEAD_0"
                { n="WIDTH", t="INTEGER", v=48 },
                { n="HEIGHT", t="INTEGER", v=48 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=32 }, --> "ITTS_PIP1"
                { n="BATCH", t="INTEGER", v=3 },
              }
            }, { --CONTAINER[4]
              n="SPRITE",
              vars = {
                { n="NAME", t="STRING", v=33 }, --> "RETICLELEAD_1"
                { n="WIDTH", t="INTEGER", v=48 },
                { n="HEIGHT", t="INTEGER", v=48 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=32 }, --> "ITTS_PIP1"
                { n="BATCH", t="INTEGER", v=3 },
              }
            }, { --CONTAINER[5]
              n="SPRITE",
              vars = {
                { n="NAME", t="STRING", v=34 }, --> "RETICLELEAD_2"
                { n="WIDTH", t="INTEGER", v=48 },
                { n="HEIGHT", t="INTEGER", v=48 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=32 }, --> "ITTS_PIP1"
                { n="BATCH", t="INTEGER", v=3 },
              }
            }, { --CONTAINER[6]
              n="SPRITE",
              vars = {
                { n="NAME", t="STRING", v=35 }, --> "RETICLELEAD_3"
                { n="WIDTH", t="INTEGER", v=48 },
                { n="HEIGHT", t="INTEGER", v=48 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=32 }, --> "ITTS_PIP1"
                { n="BATCH", t="INTEGER", v=3 },
              }
            }, { --CONTAINER[7]
              n="SPRITE",
              vars = {
                { n="NAME", t="STRING", v=36 }, --> "RETICLELEAD_4"
                { n="WIDTH", t="INTEGER", v=48 },
                { n="HEIGHT", t="INTEGER", v=48 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=32 }, --> "ITTS_PIP1"
                { n="BATCH", t="INTEGER", v=3 },
              }
            }, { --CONTAINER[8]
              n="SPRITE",
              vars = {
                { n="NAME", t="STRING", v=37 }, --> "RETICLELEAD_5"
                { n="WIDTH", t="INTEGER", v=48 },
                { n="HEIGHT", t="INTEGER", v=48 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=32 }, --> "ITTS_PIP1"
                { n="BATCH", t="INTEGER", v=3 },
              }
            }, { --CONTAINER[9]
              n="SPRITE",
              vars = {
                { n="NAME", t="STRING", v=38 }, --> "RETICLELEAD_6"
                { n="WIDTH", t="INTEGER", v=48 },
                { n="HEIGHT", t="INTEGER", v=48 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=32 }, --> "ITTS_PIP1"
                { n="BATCH", t="INTEGER", v=3 },
              }
            }, { --CONTAINER[10]
              n="SPRITE",
              vars = {
                { n="NAME", t="STRING", v=39 }, --> "RETICLELEAD_7"
                { n="WIDTH", t="INTEGER", v=48 },
                { n="HEIGHT", t="INTEGER", v=48 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=32 }, --> "ITTS_PIP1"
                { n="BATCH", t="INTEGER", v=3 },
              }
            }, { --CONTAINER[11]
              n="SPRITE",
              vars = {
                { n="NAME", t="STRING", v=40 }, --> "RETICLELEAD_8"
                { n="WIDTH", t="INTEGER", v=48 },
                { n="HEIGHT", t="INTEGER", v=48 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=32 }, --> "ITTS_PIP1"
                { n="BATCH", t="INTEGER", v=3 },
              }
            }, { --CONTAINER[12]
              n="SPRITEANIM",
              vars = {
                { n="NAME", t="STRING", v=41 }, --> "OFFSCREENINDICATOR"
                { n="WIDTH", t="INTEGER", v=40 },
                { n="HEIGHT", t="INTEGER", v=80 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=42 }, --> "OFFSCREENINDICATOR_"
                { n="LOOP", t="BOOL", v=false },
                { n="FRAMES", t="INTEGER", v=4 },
                { n="SPEED", t="FLOAT", v=0.0 },
                { n="BATCH", t="INTEGER", v=3 },
              }
            }, { --CONTAINER[13]
              n="SPRITEANIM",
              vars = {
                { n="NAME", t="STRING", v=43 }, --> "MOUSEINDICATOR"
                { n="WIDTH", t="INTEGER", v=40 },
                { n="HEIGHT", t="INTEGER", v=80 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=42 }, --> "OFFSCREENINDICATOR_"
                { n="LOOP", t="BOOL", v=false },
                { n="R_INT", t="INTEGER", v=255 },
                { n="G_INT", t="INTEGER", v=202 },
                { n="B_INT", t="INTEGER", v=87 },
                { n="ALPHA", t="FLOAT", v=0.5 },
                { n="FRAMES", t="INTEGER", v=4 },
                { n="SPEED", t="FLOAT", v=0.0 },
                { n="BATCH", t="INTEGER", v=3 },
              }
            }, { --CONTAINER[14]
              n="SPRITE",
              vars = {
                { n="NAME", t="STRING", v=44 }, --> "MOUSEDEADZONE"
                { n="WIDTH", t="INTEGER", v=512 },
                { n="HEIGHT", t="INTEGER", v=512 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=45 }, --> "MOUSERING"
                { n="BATCH", t="INTEGER", v=3 },
                { n="ALPHA", t="FLOAT", v=0.125 },
              }
            }, { --CONTAINER[15]
              n="SPRITE",
              vars = {
                { n="NAME", t="STRING", v=46 }, --> "MOUSEPIP"
                { n="WIDTH", t="INTEGER", v=32 },
                { n="HEIGHT", t="INTEGER", v=32 },
                { n="X", t="INTEGER", v=0 },
                { n="Y", t="INTEGER", v=0 },
                { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                { n="ORIGIN_VERT", t="STRING", v=7 }, --> "CENTER"
                { n="ORIGIN_HORZ", t="STRING", v=7 }, --> "CENTER"
                { n="IMAGE", t="STRING", v=46 }, --> "MOUSEPIP"
                { n="BATCH", t="INTEGER", v=3 },
                { n="ALPHA", t="FLOAT", v=0.20000000298023 },
              }
            }
          }
        }
      }
    }, { --UI[2]
      n="CONTAINER",
      vars = {
        { n="NAME", t="STRING", v=47 }, --> "HUDROOT"
        { n="WIDTH_PERCENT", t="FLOAT", v=1.0 },
        { n="HEIGHT_PERCENT", t="FLOAT", v=1.0 },
        { n="X", t="INTEGER", v=0 },
        { n="Y", t="INTEGER", v=0 },
      },
      tags = {
        {    --CONTAINER[1]
          n="CONTAINER",
          vars = {
            { n="NAME", t="STRING", v=48 }, --> "HUDSCREEN"
            { n="WIDTH_PERCENT", t="FLOAT", v=1.0 },
            { n="HEIGHT_PERCENT", t="FLOAT", v=1.0 },
            { n="X", t="INTEGER", v=0 },
            { n="Y", t="INTEGER", v=0 },
          },
          tags = {
            {    --CONTAINER[1]
              n="CONTAINER",
              vars = {
                { n="NAME", t="STRING", v=49 }, --> "MFDGROUP"
                { n="WIDTH", t="INTEGER", v=370 },
                { n="HEIGHT", t="INTEGER", v=300 },
                { n="X", t="INTEGER", v=-390 },
                { n="Y", t="INTEGER", v=-320 },
                { n="X_SAFE_OFFSET", t="INTEGER", v=-85 },
                { n="Y_SAFE_OFFSET", t="INTEGER", v=-34 },
                { n="VERT_ALIGN", t="STRING", v=50 }, --> "BOTTOM"
                { n="HORZ_ALIGN", t="STRING", v=51 }, --> "RIGHT"
              },
              tags = {
                {    --CONTAINER[1]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=52 }, --> "MAINMFD"
                    { n="WIDTH", t="INTEGER", v=370 },
                    { n="HEIGHT", t="INTEGER", v=300 },
                    { n="X", t="INTEGER", v=0 },
                    { n="Y", t="INTEGER", v=0 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=5 }, --> "TOP"
                    { n="ORIGIN_HORZ", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=53 }, --> "RADARBLANK"
                  }
                }
              }
            }, { --CONTAINER[2]
              n="CONTAINER",
              vars = {
                { n="NAME", t="STRING", v=54 }, --> "RADARGROUP"
                { n="WIDTH", t="INTEGER", v=340 },
                { n="HEIGHT", t="INTEGER", v=340 },
                { n="X", t="INTEGER", v=32 },
                { n="Y", t="INTEGER", v=-360 },
                { n="X_SAFE_OFFSET", t="INTEGER", v=85 },
                { n="Y_SAFE_OFFSET", t="INTEGER", v=-34 },
                { n="VERT_ALIGN", t="STRING", v=50 }, --> "BOTTOM"
              },
              tags = {
                {    --CONTAINER[1]
                  n="CONTAINER",
                  tags = {
                    {    --CONTAINER[1]
                      n="CONTAINER",
                      tags = {
                        {    --CONTAINER[1]
                          n="SPRITE",
                          vars = {
                            { n="NAME", t="STRING", v=55 }, --> "POWERMFD"
                            { n="WIDTH", t="INTEGER", v=42 },
                            { n="HEIGHT", t="INTEGER", v=536 },
                            { n="X", t="INTEGER", v=0 },
                            { n="Y", t="INTEGER", v=-197 },
                            { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                            { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                            { n="IMAGE", t="STRING", v=53 }, --> "RADARBLANK"
                          }
                        }, { --CONTAINER[2]
                          n="SPRITE",
                          vars = {
                            { n="NAME", t="STRING", v=56 }, --> "FUELMFD"
                            { n="WIDTH", t="INTEGER", v=48 },
                            { n="HEIGHT", t="INTEGER", v=202 },
                            { n="X", t="INTEGER", v=47 },
                            { n="Y", t="INTEGER", v=-102 },
                            { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                            { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                            { n="IMAGE", t="STRING", v=53 }, --> "RADARBLANK"
                          }
                        }, { --CONTAINER[3]
                          n="SPRITE",
                          vars = {
                            { n="NAME", t="STRING", v=57 }, --> "SPEEDMFD"
                            { n="WIDTH", t="INTEGER", v=75 },
                            { n="HEIGHT", t="INTEGER", v=66 },
                            { n="X", t="INTEGER", v=97 },
                            { n="Y", t="INTEGER", v=34 },
                            { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                            { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                            { n="ORIGIN_VERT", t="STRING", v=5 }, --> "TOP"
                            { n="ORIGIN_HORZ", t="STRING", v=6 }, --> "LEFT"
                            { n="IMAGE", t="STRING", v=53 }, --> "RADARBLANK"
                          }
                        }
                      }
                    }
                  }
                }, { --CONTAINER[2]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=58 }, --> "STATUSMFD"
                    { n="WIDTH", t="INTEGER", v=275 },
                    { n="HEIGHT", t="INTEGER", v=236 },
                    { n="X", t="INTEGER", v=47 },
                    { n="Y", t="INTEGER", v=106 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=5 }, --> "TOP"
                    { n="ORIGIN_HORZ", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=53 }, --> "RADARBLANK"
                  }
                }, { --CONTAINER[3]
                  n="SPRITE",
                  vars = {
                    { n="NAME", t="STRING", v=59 }, --> "RADARMFD"
                    { n="WIDTH", t="INTEGER", v=200 },
                    { n="HEIGHT", t="INTEGER", v=200 },
                    { n="X", t="INTEGER", v=335 },
                    { n="Y", t="INTEGER", v=140 },
                    { n="VERT_ALIGN", t="STRING", v=5 }, --> "TOP"
                    { n="HORZ_ALIGN", t="STRING", v=6 }, --> "LEFT"
                    { n="ORIGIN_VERT", t="STRING", v=5 }, --> "TOP"
                    { n="ORIGIN_HORZ", t="STRING", v=6 }, --> "LEFT"
                    { n="IMAGE", t="STRING", v=53 }, --> "RADARBLANK"
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
return L, content
