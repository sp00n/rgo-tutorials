local L = {
  size = 11,
  -- <TRANSLATE>
  [0] = {    1, "Zandt" },
  [1] = {    2, "Steel Rats" },
  [2] = {    3, "With six guns, three turrets and 2 missile launchers this Gunship is an excellent dogfight-vessel, while also not being too sluggish to be a sitting duck in combat." },
  [4] = {    5, "GUNSHIP" },
  -- <STRING>
  [3] = {    4, "MEDIA/SHIPS/PLAYERSHIPS/ZANDT_PLAYER.DAT" },
  [10] = {   11, "SHIP_ZANDT" },
  [5] = {    6, "NEUTRAL" },
  [6] = {    7, "HUMAN NEUTRAL" },
  [7] = {    8, "PLAYER" },
  [8] = {    9, "SMUGGLERS" },
  [9] = {   10, "RED DEVIL" },
}
--------------------------------------------------------------------------------
-- n -> name, t -> type, v -> value
local content = {
  n="COMPONENTS",
  tags = {
    {    --COMPONENTS[1]
      n="SHIP",
      vars = {
        { n="ID", t="INTEGER", v=990000001 },
        { n="NAME", t="TRANSLATE", v=0 }, --> "Zandt"
        { n="MANUFACTURER", t="TRANSLATE", v=1 }, --> "Steel Rats"
        { n="DESCRIPTION", t="TRANSLATE", v=2 }, --> "..."
        { n="UNIT", t="STRING", v=3 }, --> "MEDIA/SHIPS/PLAYERSHIPS/ZANDT_PLAYER.DAT"
        { n="PRICE", t="INTEGER", v=1000000 },
		-- { n="PRICE_SELL", t="INTEGER", v=750000 },	-- optional entry, for a reduced sell price
        { n="CLASS", t="TRANSLATE", v=4 }, --> "GUNSHIP"
        { n="TECHLEVEL", t="FLOAT", v=0.0 },
        { n="STARTING", t="BOOL", v=false },
        { n="CONVERSATION", t="STRING", v=10 }, --> "SHIP_ZANDT"
      },
      tags = {
        { --SHIP[3]
          n="AVAILABILITY",
          vars = {
            { n="FACTION", t="STRING", v=7 }, --> "PLAYER"
          }
        }, { --SHIP[4]
          n="AVAILABILITY",
          vars = {
            { n="FACTION", t="STRING", v=8 }, --> "SMUGGLERS"
          }
        }, { --SHIP[5]
          n="AVAILABILITY",
          vars = {
            { n="FACTION", t="STRING", v=9 }, --> "RED DEVIL"
          }
        }
      }
    }
  }
}
return L, content
