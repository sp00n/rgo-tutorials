local L = {
  size = 41,
  -- <TRANSLATE>
  [2] = {    3, "SHIPDEALER" },
  [3] = {    4, "Welcome! See anything that catches your eye?" },
  [6] = {    7, "JUNO" },
  [7] = {    8, "I'm in the market for some new wings. I don't know though, this might be out of my price range..." },
  [12] = {   13, "Ooh. So you like the touch of steel on your skin? The look of fear in your enemies eyes when they see you coming after them? The sound of the explosions when their puny ships just fade away under your weapon's fire? Then this is the perfect choice for you, the Zandt will give you all that and more!" },
  [15] = {   16, "Yeah, let's make a deal. [BUY FOR %CREDITS CREDITS]" },
  [17] = {   18, "Decline" },
  [19] = {   20, "Yeah, why not?" },
  [25] = {   26, "What have I got to lose?" },
  [29] = {   30, "Fantastic! Let me just get you the keys and complete the paperwork, and we'll get you settled in. I guarantee, you won't regret this decision!" },
  [31] = {   32, "You know... I'll think about it. Thanks." },
  [35] = {   36, "Honestly, I'm just not interested right now. Maybe some other time?" },
  [39] = {   40, "That's a shame! I sure hope she'll still be here when you change your mind..." },
  -- <STRING>
  [0] = {    1, "SHIP_ZANDT" },
  [1] = {    2, "INTRO" },
  [4] = {    5, "GESTURE_NEUTRAL_WELCOME" },
  [5] = {    6, "MEDIA/SOUNDS/VO/SHIPDEALER/intro01.ogg" },
  [8] = {    9, "MEDIA/SOUNDS/VO/JUNO/buyship1.ogg" },
  [9] = {   10, "EXTRA_NEUTRAL_CONVO_ENTER" },
  [10] = {   11, "MEDIA/SOUNDS/VO/JUNO/buyship2.ogg" },
  [11] = {   12, "MEDIA/SOUNDS/VO/JUNO/buyship3.ogg" },
  [13] = {   14, "GESTURE_NEUTRAL_TOWARDSHIPRIGHT" },
  [14] = {   15, "MEDIA/SOUNDS/VO/SHIPDEALER/bloodeagle01.ogg" },
  [16] = {   17, "BUY" },
  [18] = {   19, "ENDCONVERSATION" },
  [20] = {   21, "MEDIA/SOUNDS/VO/JUNO/yeahwhynot1.ogg" },
  [21] = {   22, "EXPRESSION_FACETALK_AFFIRMATIVE" },
  [22] = {   23, "MEDIA/SOUNDS/VO/JUNO/yeahwhynot2.ogg" },
  [23] = {   24, "MEDIA/SOUNDS/VO/JUNO/yeahwhynot3.ogg" },
  [24] = {   25, "MEDIA/SOUNDS/VO/JUNO/yeahwhynot4.ogg" },
  [26] = {   27, "MEDIA/SOUNDS/VO/JUNO/whathaveigottolose1.ogg" },
  [27] = {   28, "MEDIA/SOUNDS/VO/JUNO/whathaveigottolose2.ogg" },
  [28] = {   29, "MEDIA/SOUNDS/VO/JUNO/whathaveigottolose3.ogg" },
  [30] = {   31, "MEDIA/SOUNDS/VO/SHIPDEALER/accept01.ogg" },
  [32] = {   33, "MEDIA/SOUNDS/VO/JUNO/illthinkaboutit1.ogg" },
  [33] = {   34, "MEDIA/SOUNDS/VO/JUNO/illthinkaboutit2.ogg" },
  [34] = {   35, "MEDIA/SOUNDS/VO/JUNO/illthinkaboutit3.ogg" },
  [36] = {   37, "MEDIA/SOUNDS/VO/JUNO/honestlyjustnotinterested1.ogg" },
  [37] = {   38, "MEDIA/SOUNDS/VO/JUNO/honestlyjustnotinterested2.ogg" },
  [38] = {   39, "MEDIA/SOUNDS/VO/JUNO/honestlyjustnotinterested3.ogg" },
  [40] = {   41, "MEDIA/SOUNDS/VO/SHIPDEALER/decline01.ogg" },
}
--------------------------------------------------------------------------------
-- n -> name, t -> type, v -> value
local content = {
  n="CONVERSATIONS",
  tags = {
    {    --CONVERSATIONS[1]
      n="CONVERSATION",
      vars = {
        { n="NAME", t="STRING", v=0 }, --> "SHIP_BLOODEAGLE"
        { n="$3198516220", t="FLOAT", v=0.0 },
      },
      tags = {
        {    --CONVERSATION[1]
          n="INTRO",
          vars = {
            { n="NAME", t="STRING", v=1 }, --> "INTRO"
            { n="PRIORITY", t="INTEGER", v=100 },
          },
          tags = {
            {    --INTRO[1]
              n="DIALOG",
              vars = {
                { n="$3586654738", t="TRANSLATE", v=2 }, --> "SHIPDEALER"
                { n="$1685169374", t="INTEGER", v=2 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=3 }, --> "Welcome! See anything that catches your eye?"
                { n="ANIMATION", t="STRING", v=4 }, --> "GESTURE_NEUTRAL_WELCOME"
                { n="$1790983977", t="FLOAT", v=0.0 },
                { n="$3198553880", t="FLOAT", v=0.75 },
                { n="SOUND", t="STRING", v=5 }, --> "MEDIA/SOUNDS/VO/SHIPDEALER/intro01.ogg"
              }
            }, { --INTRO[2]
              n="DIALOG",
              vars = {
                { n="$3586654738", t="TRANSLATE", v=6 }, --> "JUNO"
                { n="$4240980462", t="INTEGER", v=11 },
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=1 },
                { n="DIALOG", t="TRANSLATE", v=7 }, --> "I'm in the market for some new wings. I don't know though, this might be out of my price range..."
                { n="SOUND", t="STRING", v=8 }, --> "MEDIA/SOUNDS/VO/JUNO/buyship1.ogg"
                { n="ANIMATION", t="STRING", v=9 }, --> "EXTRA_NEUTRAL_CONVO_ENTER"
                { n="$1790983977", t="FLOAT", v=0.0 },
                { n="$3198553880", t="FLOAT", v=0.5 },
              }
            }, { --INTRO[3]
              n="DIALOG",
              vars = {
                { n="$4240980462", t="INTEGER", v=11 },
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=1 },
                { n="DIALOG", t="TRANSLATE", v=7 }, --> "I'm in the market for some new wings. I don't know though, this might be out of my price range..."
                { n="SOUND", t="STRING", v=10 }, --> "MEDIA/SOUNDS/VO/JUNO/buyship2.ogg"
                { n="ANIMATION", t="STRING", v=9 }, --> "EXTRA_NEUTRAL_CONVO_ENTER"
                { n="$1790983977", t="FLOAT", v=0.0 },
                { n="$3198553880", t="FLOAT", v=0.5 },
              }
            }, { --INTRO[4]
              n="DIALOG",
              vars = {
                { n="$4240980462", t="INTEGER", v=11 },
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=1 },
                { n="DIALOG", t="TRANSLATE", v=7 }, --> "I'm in the market for some new wings. I don't know though, this might be out of my price range..."
                { n="SOUND", t="STRING", v=11 }, --> "MEDIA/SOUNDS/VO/JUNO/buyship3.ogg"
                { n="ANIMATION", t="STRING", v=9 }, --> "EXTRA_NEUTRAL_CONVO_ENTER"
                { n="$1790983977", t="FLOAT", v=0.0 },
                { n="$3198553880", t="FLOAT", v=0.5 },
              }
            }, { --INTRO[5]
              n="DIALOG",
              vars = {
                { n="$3586654738", t="TRANSLATE", v=2 }, --> "SHIPDEALER"
                { n="$1685169374", t="INTEGER", v=2 },
                { n="$3883121324", t="INTEGER", v=2 },
                { n="DIALOG", t="TRANSLATE", v=12 }, --> "..."
                { n="$4240980462", t="INTEGER", v=10 },
                { n="ANIMATION", t="STRING", v=13 }, --> "GESTURE_NEUTRAL_TOWARDSHIPRIGHT"
                { n="$1790983977", t="FLOAT", v=0.0 },
                -- { n="SOUND", t="STRING", v=14 }, --> "MEDIA/SOUNDS/VO/SHIPDEALER/bloodeagle01.ogg"
              }
            }, { --INTRO[6]
              n="CHOICE",
              vars = {
                { n="ID_OF_SHIP_TO_BUY", t="INTEGER", v=990000001 },
                { n="DIALOG", t="TRANSLATE", v=15 }, --> "Yeah, let's make a deal. [BUY FOR %CREDITS CREDITS]"
                { n="GOTO", t="STRING", v=16 }, --> "BUY"
              }
            }, { --INTRO[7]
              n="CHOICE",
              vars = {
                { n="DIALOG", t="TRANSLATE", v=17 }, --> "Decline"
                { n="GOTO", t="STRING", v=18 }, --> "ENDCONVERSATION"
                { n="$1110838960", t="BOOL", v=true },
              }
            }
          }
        }, { --CONVERSATION[2]
          n="RESPONSE",
          vars = {
            { n="NAME", t="STRING", v=16 }, --> "BUY"
            { n="BUY", t="BOOL", v=true },
            { n="ENDCONVERSATION", t="BOOL", v=true },
          },
          tags = {
            {    --RESPONSE[1]
              n="DIALOG",
              vars = {
                { n="$3586654738", t="TRANSLATE", v=6 }, --> "JUNO"
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=19 }, --> "Yeah, why not?"
                { n="SOUND", t="STRING", v=20 }, --> "MEDIA/SOUNDS/VO/JUNO/yeahwhynot1.ogg"
                { n="$4003761604", t="STRING", v=21 }, --> "EXPRESSION_FACETALK_AFFIRMATIVE"
              }
            }, { --RESPONSE[2]
              n="DIALOG",
              vars = {
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=19 }, --> "Yeah, why not?"
                { n="SOUND", t="STRING", v=22 }, --> "MEDIA/SOUNDS/VO/JUNO/yeahwhynot2.ogg"
                { n="$4003761604", t="STRING", v=21 }, --> "EXPRESSION_FACETALK_AFFIRMATIVE"
              }
            }, { --RESPONSE[3]
              n="DIALOG",
              vars = {
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=19 }, --> "Yeah, why not?"
                { n="SOUND", t="STRING", v=23 }, --> "MEDIA/SOUNDS/VO/JUNO/yeahwhynot3.ogg"
                { n="$4003761604", t="STRING", v=21 }, --> "EXPRESSION_FACETALK_AFFIRMATIVE"
              }
            }, { --RESPONSE[4]
              n="DIALOG",
              vars = {
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=19 }, --> "Yeah, why not?"
                { n="SOUND", t="STRING", v=24 }, --> "MEDIA/SOUNDS/VO/JUNO/yeahwhynot4.ogg"
                { n="$4003761604", t="STRING", v=21 }, --> "EXPRESSION_FACETALK_AFFIRMATIVE"
              }
            }, { --RESPONSE[5]
              n="DIALOG",
              vars = {
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=25 }, --> "What have I got to lose?"
                { n="SOUND", t="STRING", v=26 }, --> "MEDIA/SOUNDS/VO/JUNO/whathaveigottolose1.ogg"
              }
            }, { --RESPONSE[6]
              n="DIALOG",
              vars = {
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=25 }, --> "What have I got to lose?"
                { n="SOUND", t="STRING", v=27 }, --> "MEDIA/SOUNDS/VO/JUNO/whathaveigottolose2.ogg"
              }
            }, { --RESPONSE[7]
              n="DIALOG",
              vars = {
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=25 }, --> "What have I got to lose?"
                { n="SOUND", t="STRING", v=28 }, --> "MEDIA/SOUNDS/VO/JUNO/whathaveigottolose3.ogg"
              }
            }, { --RESPONSE[8]
              n="DIALOG",
              vars = {
                { n="$3586654738", t="TRANSLATE", v=2 }, --> "SHIPDEALER"
                { n="$1685169374", t="INTEGER", v=2 },
                { n="$3883121324", t="INTEGER", v=1 },
                { n="DIALOG", t="TRANSLATE", v=29 }, --> "Fantastic! Let me just get you the keys and complete the paperwork, and we'll get you settled in. I guarantee, you won't regret this decision!"
                { n="SOUND", t="STRING", v=30 }, --> "MEDIA/SOUNDS/VO/SHIPDEALER/accept01.ogg"
              }
            }
          }
        }, { --CONVERSATION[3]
          n="RESPONSE",
          vars = {
            { n="NAME", t="STRING", v=18 }, --> "ENDCONVERSATION"
            { n="ENDCONVERSATION", t="BOOL", v=true },
          },
          tags = {
            {    --RESPONSE[1]
              n="DIALOG",
              vars = {
                { n="$3586654738", t="TRANSLATE", v=6 }, --> "JUNO"
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=31 }, --> "You know... I'll think about it. Thanks."
                { n="SOUND", t="STRING", v=32 }, --> "MEDIA/SOUNDS/VO/JUNO/illthinkaboutit1.ogg"
              }
            }, { --RESPONSE[2]
              n="DIALOG",
              vars = {
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=31 }, --> "You know... I'll think about it. Thanks."
                { n="SOUND", t="STRING", v=33 }, --> "MEDIA/SOUNDS/VO/JUNO/illthinkaboutit2.ogg"
              }
            }, { --RESPONSE[3]
              n="DIALOG",
              vars = {
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=31 }, --> "You know... I'll think about it. Thanks."
                { n="SOUND", t="STRING", v=34 }, --> "MEDIA/SOUNDS/VO/JUNO/illthinkaboutit3.ogg"
              }
            }, { --RESPONSE[4]
              n="DIALOG",
              vars = {
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=35 }, --> "Honestly, I'm just not interested right now. Maybe some other time?"
                { n="SOUND", t="STRING", v=36 }, --> "MEDIA/SOUNDS/VO/JUNO/honestlyjustnotinterested1.ogg"
              }
            }, { --RESPONSE[5]
              n="DIALOG",
              vars = {
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=35 }, --> "Honestly, I'm just not interested right now. Maybe some other time?"
                { n="SOUND", t="STRING", v=37 }, --> "MEDIA/SOUNDS/VO/JUNO/honestlyjustnotinterested2.ogg"
              }
            }, { --RESPONSE[6]
              n="DIALOG",
              vars = {
                { n="$1685169374", t="INTEGER", v=1 },
                { n="$3883121324", t="INTEGER", v=0 },
                { n="DIALOG", t="TRANSLATE", v=35 }, --> "Honestly, I'm just not interested right now. Maybe some other time?"
                { n="SOUND", t="STRING", v=38 }, --> "MEDIA/SOUNDS/VO/JUNO/honestlyjustnotinterested3.ogg"
              }
            }, { --RESPONSE[7]
              n="DIALOG",
              vars = {
                { n="$3586654738", t="TRANSLATE", v=2 }, --> "SHIPDEALER"
                { n="$1685169374", t="INTEGER", v=2 },
                { n="$3883121324", t="INTEGER", v=1 },
                { n="DIALOG", t="TRANSLATE", v=39 }, --> "That's a shame! I sure hope she'll still be here when you change your mind..."
                { n="SOUND", t="STRING", v=40 }, --> "MEDIA/SOUNDS/VO/SHIPDEALER/decline01.ogg"
              }
            }
          }
        }
      }
    }
  }
}
return L, content
