local L = {
  size = 82,
  -- <TRANSLATE>
  [0] = {    1, "Zandt" },
  [1] = {    2, "Gunship" },
  -- <STRING>
  [2] = {    3, "GUNSHIP" },
  [3] = {    4, "MEDIA/SHIPS/SHIP_SET_1/ZANDT_LOADOUT_PLAYER.LAYOUT" },
  [4] = {    5, "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01A_LOD0.mdl" },
  [5] = {    6, "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01A_ultra.mdl" },
  [6] = {    7, "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01A_LOD0.mdl" },
  [7] = {    8, "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01A_ultra.mdl" },
  [8] = {    9, "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01_hull.mdl" },
  [9] = {   10, "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01_hull.mdl" },
  [10] = {   11, "MEDIA/SHIPS/COCKPIT_SET_1/COCKPIT_ZANDT_LOW.LAYOUT" },
  [11] = {   12, "MEDIA/SHIPS/COCKPIT_SET_1/COCKPIT_ZANDT.LAYOUT" },
  [12] = {   13, "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01A_ultra.mdl" },
  [13] = {   14, "MEDIA/SHIPS/SHIP_SET_1/PIRATE3_GUNSHIP01A_PAINT.DDS" },
  [14] = {   15, "PIRATE3_GUNSHIP01A_PAINT.DDS" },
  [15] = {   16, "MEDIA/SHIPS/SHIP_SET_1/PIRATE3_GUNSHIP01A_PAINT.DDS" },
  [16] = {   17, "MEDIA/SHIPS/SHIP_SET_1/BIGCARGO_WEATHERING.DDS" },
  [17] = {   18, "MEDIA/MASKS/DURSTONMASK_01.PNG" },
  [18] = {   19, "MEDIA/UI/MFD_ZANDT.DAT" },
  [19] = {   20, "MEDIA/UI/HUD_ZANDT.DAT" },
  [20] = {   21, "HUD_COYOTE" },
  [21] = {   22, "JUNO" },
  [22] = {   23, "PLATYPUS" },
  [23] = {   24, "PLATYPUSDAM" },
  [24] = {   25, "PLAYER" },
  [25] = {   26, "FIGHTER_FLYBY" },
  [26] = {   27, "AFTERBURNER" },
  [27] = {   28, "ENGINE_BOOSTERENGAGE" },
  [28] = {   29, "ENGINE_BOOSTEREND" },
  [29] = {   30, "BIGCOLLISION" },
  [30] = {   31, "SMALLCOLLISION" },
  [31] = {   32, "ENGINESMALLPLAYER" },
  [32] = {   33, "FIGHTERMANEUVER" },
  [33] = {   34, "SHIELDHIT" },
  [34] = {   35, "HULLHITSMALL" },
  [35] = {   36, "EXPLOSION" },
  [36] = {   37, "EXPLOSION_FIGHTERDEATH" },
  [37] = {   38, "EXPLOSION_DEBRIS" },
  [38] = {   39, "ENGINEBRAKE" },
  [39] = {   40, "BRAKEON" },
  [40] = {   41, "BRAKEOFF" },
  [41] = {   42, "SPARKS" },
  [42] = {   43, "SCAN_FX" },
  [43] = {   44, "WASH" },
  [44] = {   45, "COCKPITDAMAGE" },
  [45] = {   46, "COCKPITDAMAGE_GLASS" },
  [46] = {   47, "RELOADSTART" },
  [47] = {   48, "RELOADEND" },
  [48] = {   49, "RELOADLOOP" },
  [49] = {   50, "BREAKWARP" },
  [50] = {   51, "WARPSTARTSMALL" },
  [51] = {   52, "greasyexplosiontrail" },
  [52] = {   53, "greasyexplosionbig" },
  [53] = {   54, "debris1" },
  [54] = {   55, "lightspeedengage" },
  [55] = {   56, "debris2" },
  [56] = {   57, "debrisbig1" },
  [57] = {   58, "jumpengage" },
  [58] = {   59, "jumptrail" },
  [59] = {   60, "cockpitsparks1" },
  [60] = {   61, "cockpitsparks2" },
  [61] = {   62, "repairsparks" },
  [62] = {   63, "cockpitglass" },
  [63] = {   64, "boostertrail_civilian" },
  [64] = {   65, "smallsputter" },
  [65] = {   66, "warpnose" },
  [66] = {   67, "warpbegin" },
  [67] = {   68, "warpend" },
  [68] = {   69, "HULL" },
  [69] = {   70, "SHIELD" },
  [70] = {   71, "RADAR" },
  [71] = {   72, "MANEUVERING" },
  [72] = {   73, "THRUSTER" },
  [73] = {   74, "REACTOR" },
  [74] = {   75, "MEDIA/TEXTURES/DAMAGE/shipdamage1_d.dds" },
  [75] = {   76, "MEDIA/TEXTURES/DAMAGE/shipdamage1_n.dds" },
  [76] = {   77, "MEDIA/TEXTURES/DAMAGE/shipdamage1_i.dds" },
  [77] = {   78, "MEDIA/TEXTURES/DAMAGE/shipdamage2_d.dds" },
  [78] = {   79, "MEDIA/TEXTURES/DAMAGE/shipdamage2_n.dds" },
  [79] = {   80, "MEDIA/TEXTURES/DAMAGE/shipdamage2_i.dds" },
  [80] = {   81, "MEDIA/TEXTURES/DAMAGE/bulletdamage1_d.dds" },
  [81] = {   82, "MEDIA/TEXTURES/DAMAGE/bulletdamage1_n.dds" },
}
--------------------------------------------------------------------------------
-- n -> name, t -> type, v -> value
local content = {
  n="SHIP",
  vars = {
    { n="NAME", t="TRANSLATE", v=0 }, --> "Zandt"
    { n="CLASS", t="TRANSLATE", v=1 }, --> "Gunship"
    { n="TYPE", t="STRING", v=2 }, --> "GUNSHIP"
    { n="LAYOUT", t="STRING", v=3 }, --> "MEDIA/SHIPS/SHIP_SET_1/ZANDT_LOADOUT_PLAYER.LAYOUT"
    { n="MESH", t="STRING", v=4 }, --> "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01A_LOD0.mdl"
    { n="MESH_ULTRA", t="STRING", v=5 }, --> "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01A_ultra.mdl"
    { n="MESH_ANIMATED", t="STRING", v=6 }, --> "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01A_LOD0.mdl"
    { n="MESH_ANIMATED_ULTRA", t="STRING", v=7 }, --> "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01A_ultra.mdl"
    { n="COLLISION_MESH", t="STRING", v=8 }, --> "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01_hull.mdl"
    { n="COLLISION_MESH_CONVEX", t="STRING", v=9 }, --> "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01_hull.mdl"
    { n="COCKPIT_LAYOUT", t="STRING", v=10 }, --> "MEDIA/SHIPS/COCKPIT_SET_1/COCKPIT_ZANDT_LOW.LAYOUT"
    { n="COCKPIT_LAYOUT_ULTRA", t="STRING", v=11 }, --> "MEDIA/SHIPS/COCKPIT_SET_1/COCKPIT_ZANDT.LAYOUT"
    { n="PAINT_MESH", t="STRING", v=12 }, --> "MEDIA/SHIPS/SHIP_SET_1/pirate3_gunship01A_ultra.mdl"
    { n="PAINT_OVERLAY_PATH", t="STRING", v=13 }, --> "MEDIA/SHIPS/SHIP_SET_1/PIRATE3_GUNSHIP01A_PAINT.DDS"
    { n="PAINT_OVERLAY_FILE", t="STRING", v=14 }, --> "PIRATE3_GUNSHIP01A_PAINT.DDS"
    { n="DETAILS_OVERLAY", t="STRING", v=15 }, --> "MEDIA/SHIPS/SHIP_SET_1/PIRATE3_GUNSHIP01A_PAINT.DDS"
    -- { n="DAMAGED_OVERLAY", t="STRING", v=16 }, --> "MEDIA/SHIPS/SHIP_SET_1/BIGCARGO_WEATHERING.DDS"
    { n="MASK_FILE", t="STRING", v=17 }, --> "MEDIA/MASKS/DURSTONMASK_01.PNG"
    { n="MFD", t="STRING", v=18 }, --> "MEDIA/UI/MFD_ZANDT.DAT"
    { n="HUD", t="STRING", v=19 }, --> "MEDIA/UI/HUD_ZANDT.DAT"
    { n="$246127538", t="INTEGER", v=0 },
    { n="$246127527", t="INTEGER", v=108 },
    { n="$246127522", t="INTEGER", v=209 },
    { n="$975523302", t="INTEGER", v=1 },
    { n="$975523302", t="INTEGER", v=4 },
    { n="$975523302", t="INTEGER", v=16 },
    { n="$1571785301", t="INTEGER", v=1 },
    { n="$1571785301", t="INTEGER", v=4 },
    { n="SUGGESTED_SHIELD_RADIUS", t="FLOAT", v=24.0 },
    { n="CHASE_CAM_VERTICAL_MULT", t="FLOAT", v=1.7 },
    { n="SHIP_ABOVE_STATION_FLOOR", t="FLOAT", v=8.5 },
    { n="HUD_STRING", t="STRING", v=20 }, --> "HUD_COYOTE"
    { n="SCALE", t="FLOAT", v=1.5 },
    { n="COMM", t="STRING", v=21 }, --> "JUNO"
    { n="VDU", t="STRING", v=22 }, --> "PLATYPUS"
    { n="VDU_DAMAGED", t="STRING", v=23 }, --> "PLATYPUSDAM"
    { n="HOLD", t="INTEGER", v=12 },
    { n="DOLLY_MULT", t="FLOAT", v=0.75 },
    { n="CARGOCOUNTMIN", t="INTEGER", v=1 },
    { n="CARGOCOUNTMAX", t="INTEGER", v=1 },
    { n="FACTION", t="STRING", v=24 }, --> "PLAYER"
    { n="CAN_USE_AFTERBURNER", t="BOOL", v=true },
    { n="$2970562126", t="BOOL", v=true },
    { n="MAX_ENGINE_RANK", t="INTEGER", v=4 },
    { n="MAX_SHIELD_RANK", t="INTEGER", v=4 },
    { n="MAX_CARGO_RANK", t="INTEGER", v=1 },
    { n="$1326435861", t="FLOAT", v=120.0 },
    { n="$406838784", t="FLOAT", v=28.0 },
    { n="CRUISE_SPEED_PERCENTAGE", t="FLOAT", v=0.0 },
    { n="TOP_SPEED", t="FLOAT", v=320.0 },
    { n="ACCELERATION", t="FLOAT", v=120.0 },
    { n="THROTTLE_SPEED", t="FLOAT", v=1.0 },
    { n="DEFLECTOR_ENERGY", t="FLOAT", v=0.0 },
    { n="DEFLECTOR_RECHARGE", t="FLOAT", v=0.0 },
    { n="DEFLECTOR_DRAIN", t="FLOAT", v=1.0 },
    { n="PITCH_ACCELERATION", t="FLOAT", v=110.0 },
    { n="YAW_ACCELERATION", t="FLOAT", v=110.0 },
    { n="ROLL_ACCELERATION", t="FLOAT", v=130.0 },
    { n="MAX_PITCH_RATE", t="FLOAT", v=70.0 },
    { n="MAX_YAW_RATE", t="FLOAT", v=90.0 },
    { n="MAX_ROLL_RATE", t="FLOAT", v=80.0 },
    { n="PITCH_DECAY", t="FLOAT", v=0.019999999552965 },
    { n="YAW_DECAY", t="FLOAT", v=0.019999999552965 },
    { n="ROLL_DECAY", t="FLOAT", v=0.019999999552965 },
    { n="INERTIAL_DAMP", t="FLOAT", v=0.0099999997764826 },
    { n="SHIELD_MAX", t="FLOAT", v=0.0 },
    { n="HULL_MAX", t="FLOAT", v=0.0 },
    { n="HULL_MULT", t="FLOAT", v=1.5 },
    { n="SHIELD_MULT", t="FLOAT", v=1.5 },
    { n="CORE_HEALTH", t="FLOAT", v=550.0 },
    { n="SHIELD_RECHARGE", t="FLOAT", v=0.0 },
    { n="SHIELD_RECHARGE_DELAY", t="FLOAT", v=0.5 },
    { n="WARP_MULT", t="FLOAT", v=800.0 },
    { n="$1632421509", t="FLOAT", v=2.5 },
    { n="MASS", t="FLOAT", v=80.0 },
    { n="SOUND_FLYBY", t="STRING", v=25 }, --> "FIGHTER_FLYBY"
    { n="SOUND_AFTERBURNER", t="STRING", v=26 }, --> "AFTERBURNER"
    { n="SOUND_AFTERBURNERON", t="STRING", v=27 }, --> "ENGINE_BOOSTERENGAGE"
    { n="SOUND_AFTERBURNEROFF", t="STRING", v=28 }, --> "ENGINE_BOOSTEREND"
    { n="SOUND_COLLISION", t="STRING", v=29 }, --> "BIGCOLLISION"
    { n="SOUND_COLLISION_SMALL", t="STRING", v=30 }, --> "SMALLCOLLISION"
    { n="SOUND_ENGINE", t="STRING", v=31 }, --> "ENGINESMALLPLAYER"
    { n="FIGHTER_MANEUVER", t="STRING", v=32 }, --> "FIGHTERMANEUVER"
    { n="SOUND_SHIELDHIT", t="STRING", v=33 }, --> "SHIELDHIT"
    { n="SOUND_HULLHIT", t="STRING", v=34 }, --> "HULLHITSMALL"
    { n="SOUND_DEATH", t="STRING", v=35 }, --> "EXPLOSION"
    { n="SOUND_EXPLODE", t="STRING", v=36 }, --> "EXPLOSION_FIGHTERDEATH"
    { n="EXPLOSION_DEBRIS", t="STRING", v=37 }, --> "EXPLOSION_DEBRIS"
    { n="SOUND_BRAKE", t="STRING", v=38 }, --> "ENGINEBRAKE"
    { n="SOUND_BRAKEON", t="STRING", v=39 }, --> "BRAKEON"
    { n="SOUND_BRAKEOFF", t="STRING", v=40 }, --> "BRAKEOFF"
    { n="SPARKS", t="STRING", v=41 }, --> "SPARKS"
    { n="SOUND_SCAN", t="STRING", v=42 }, --> "SCAN_FX"
    { n="SOUND_WASH", t="STRING", v=43 }, --> "WASH"
    { n="COCKPIT_DAMAGE", t="STRING", v=44 }, --> "COCKPITDAMAGE"
    { n="COCKPIT_DAMAGE_GLASS", t="STRING", v=45 }, --> "COCKPITDAMAGE_GLASS"
    { n="RELOAD_START", t="STRING", v=46 }, --> "RELOADSTART"
    { n="RELOAD_END", t="STRING", v=47 }, --> "RELOADEND"
    { n="RELOAD_LOOP", t="STRING", v=48 }, --> "RELOADLOOP"
    { n="SOUND_WARPEND", t="STRING", v=49 }, --> "BREAKWARP"
    { n="WARP_START", t="STRING", v=50 }, --> "WARPSTARTSMALL"
    { n="PARTICLE_DEATH", t="STRING", v=51 }, --> "greasyexplosiontrail"
    { n="PARTICLE_EXPLODE_CORE", t="STRING", v=52 }, --> "greasyexplosionbig"
    { n="PARTICLE_EXPLODE", t="STRING", v=51 }, --> "greasyexplosiontrail"
    { n="PARTICLE_DEBRIS", t="STRING", v=53 }, --> "debris1"
    { n="PARTICLE_WARPENGAGE", t="STRING", v=54 }, --> "lightspeedengage"
    { n="LIGHTSPEED_ENGAGE", t="STRING", v=54 }, --> "lightspeedengage"
    { n="PARTICLE_EXPLODEDEBRIS", t="STRING", v=55 }, --> "debris2"
    { n="PARTICLE_EXPLODEDEBRIS", t="STRING", v=55 }, --> "debris2"
    { n="PARTICLE_EXPLODEDEBRIS", t="STRING", v=55 }, --> "debris2"
    { n="PARTICLE_EXPLODEDEBRIS", t="STRING", v=56 }, --> "debrisbig1"
    { n="JUMP_ENGAGE", t="STRING", v=57 }, --> "jumpengage"
    { n="JUMP_TRAIL", t="STRING", v=58 }, --> "jumptrail"
    { n="COCKPIT_SPARKS", t="STRING", v=59 }, --> "cockpitsparks1"
    { n="COCKPIT_SPARKS", t="STRING", v=60 }, --> "cockpitsparks2"
    { n="REPAIR_SPARKS", t="STRING", v=61 }, --> "repairsparks"
    { n="COCKPIT_GLASS", t="STRING", v=62 }, --> "cockpitglass"
    { n="BOOSTER_TRAIL", t="STRING", v=63 }, --> "boostertrail_civilian"
    { n="PARTICLE_SPUTTER", t="STRING", v=64 }, --> "smallsputter"
    { n="PARTICLE_WARP", t="STRING", v=65 }, --> "warpnose"
    { n="WARP_BEGIN", t="STRING", v=66 }, --> "warpbegin"
    { n="WARP_END", t="STRING", v=67 }, --> "warpend"
    { n="LINKED_QUADRANTS", t="BOOL", v=false },
    { n="TRAIL_TYPE", t="INTEGER", v=0 },
    { n="TRAIL_SIZE", t="FLOAT", v=6.0 },
  },
  tags = {
    {    --SHIP[1]
      n="WEAPON_BANK",
      vars = {
        { n="BANK", t="INTEGER", v=0 },
      }
    }, { --SHIP[2]
      n="WEAPON_BANK",
      vars = {
        { n="BANK", t="INTEGER", v=1 },
      }
    }, { --SHIP[3]
      n="MISSILE_BANK",
      vars = {
        { n="BANK", t="INTEGER", v=8 },
      }
    }, { --SHIP[4]
      n="MISSILE_BANK",
      vars = {
        { n="BANK", t="INTEGER", v=9 },
      }
    }, { --SHIP[5]
      n="COMPONENT",
      vars = {
        { n="TYPE", t="STRING", v=68 }, --> "HULL"
        { n="ID", t="INTEGER", v=415061501 },
        { n="INSTALLED_BANK", t="INTEGER", v=0 },
      }
    }, { --SHIP[8]
      n="COMPONENT",
      vars = {
        { n="TYPE", t="STRING", v=69 }, --> "SHIELD"
        { n="ID", t="INTEGER", v=415061801 },
        { n="INSTALLED_BANK", t="INTEGER", v=0 },
      }
    }, { --SHIP[9]
      n="COMPONENT",
      vars = {
        { n="TYPE", t="STRING", v=70 }, --> "RADAR"
        { n="ID", t="INTEGER", v=7825409 },
        { n="INSTALLED_BANK", t="INTEGER", v=0 },
      }
    }, { --SHIP[10]
      n="COMPONENT",
      vars = {
        { n="TYPE", t="STRING", v=71 }, --> "MANEUVERING"
        { n="ID", t="INTEGER", v=8267411 },
        { n="INSTALLED_BANK", t="INTEGER", v=0 },
      }
    }, { --SHIP[11]
      n="COMPONENT",
      vars = {
        { n="TYPE", t="STRING", v=72 }, --> "THRUSTER"
        { n="ID", t="INTEGER", v=2267411 },
        { n="INSTALLED_BANK", t="INTEGER", v=0 },
      }
    }, { --SHIP[12]
      n="COMPONENT",
      vars = {
        { n="TYPE", t="STRING", v=73 }, --> "REACTOR"
        { n="ID", t="INTEGER", v=3267411 },
        { n="INSTALLED_BANK", t="INTEGER", v=0 },
      }
    }, { --SHIP[13]
      n="WOUND",
      vars = {
        { n="TEXTURE", t="STRING", v=74 }, --> "MEDIA/TEXTURES/DAMAGE/shipdamage1_d.dds"
        { n="NORMAL", t="STRING", v=75 }, --> "MEDIA/TEXTURES/DAMAGE/shipdamage1_n.dds"
        { n="ILLUMINATION", t="STRING", v=76 }, --> "MEDIA/TEXTURES/DAMAGE/shipdamage1_i.dds"
        { n="DEPTH", t="FLOAT", v=0.050000000745058 },
        { n="SCALEMIN", t="FLOAT", v=2.0 },
        { n="SCALEMAX", t="FLOAT", v=8.0 },
        { n="FRUSTUMLENGTH", t="FLOAT", v=3.0 },
      }
    }, { --SHIP[14]
      n="WOUND",
      vars = {
        { n="TEXTURE", t="STRING", v=77 }, --> "MEDIA/TEXTURES/DAMAGE/shipdamage2_d.dds"
        { n="NORMAL", t="STRING", v=78 }, --> "MEDIA/TEXTURES/DAMAGE/shipdamage2_n.dds"
        { n="ILLUMINATION", t="STRING", v=79 }, --> "MEDIA/TEXTURES/DAMAGE/shipdamage2_i.dds"
        { n="DEPTH", t="FLOAT", v=0.050000000745058 },
        { n="SCALEMIN", t="FLOAT", v=3.0 },
        { n="SCALEMAX", t="FLOAT", v=8.0 },
        { n="FRUSTUMLENGTH", t="FLOAT", v=3.0 },
      }
    }, { --SHIP[15]
      n="WOUND",
      vars = {
        { n="TEXTURE", t="STRING", v=80 }, --> "MEDIA/TEXTURES/DAMAGE/bulletdamage1_d.dds"
        { n="NORMAL", t="STRING", v=81 }, --> "MEDIA/TEXTURES/DAMAGE/bulletdamage1_n.dds"
        { n="DEPTH", t="FLOAT", v=0.019999999552965 },
        { n="SCALEMIN", t="FLOAT", v=4.0 },
        { n="SCALEMAX", t="FLOAT", v=12.0 },
        { n="FRUSTUMLENGTH", t="FLOAT", v=3.0 },
      }
    }
  }
}
return L, content
