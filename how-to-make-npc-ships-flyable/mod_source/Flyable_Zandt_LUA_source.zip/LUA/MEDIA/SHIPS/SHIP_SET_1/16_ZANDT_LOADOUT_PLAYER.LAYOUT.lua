local LAYOUT = {
    ["entries"] = {

        -------------------- ENTRY [1] --------------------
        [1] = {
            ["name"] = "",
            ["identifier_type"] = "6343081",  -- do not change
            ["identifier"] = "-2393750811671102669",  -- do not change
            ["identifier_hex"] = "A9 C9 60 00 33 7B 8A C5 51 B0 C7 DE",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.0,
                        [2] = 4.1336002349854,
                        [3] = 0.22230200469494,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                        [1] = -0.095845699310303,
                        [2] = 0.0,
                        [3] = 0.0,
                        [4] = 0.99539601802826,
                    },
                },
                [3] = {
                    ["$120"] = 0.89999997615814,
                },
                [4] = {
                    ["$121"] = 0.89999997615814,
                },
                [5] = {
                    ["$122"] = 0.89999997615814,
                },
                [6] = {
                    ["TYPE_STRING"] = "PILOT",
                },
                [7] = {
                    ["POSITIONING"] = "FREE",
                },
                [8] = {
                    ["DAT_OR_MDL"] = "MEDIA\\CHARACTERS\\PILOT\\PILOT_SEATED.MDL",
                },
            },   -- end properties
        },  -- end entry [1]

        -------------------- ENTRY [2] --------------------
        [2] = {
            ["name"] = "PIRATEFIGHTER_01",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-2287139635904750504",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A 58 5C 2E 72 9E 72 42 E0",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 8.6943998336792,
                        [2] = -2.5631999969482,
                        [3] = 20.005699157715,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                        [1] = 0.0,
                        [2] = 0.0,
                        [3] = 0.70710700750351,
                        [4] = -0.70710700750351,
                    },
                },
                [3] = {
                    ["$250000979"] = 1,
                },
                [4] = {
                    ["MDL_TYPE"] = 1290,
                },
                [5] = {
                    ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/WEAPON_LASERD_01.MDL",
                },
            },   -- end properties
        },  -- end entry [2]

        -------------------- ENTRY [3] --------------------
        [3] = {
            ["name"] = "PIRATEFIGHTER_01",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-4507873891225885649",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A 2F 24 39 65 94 D0 70 C1",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = -8.6943998336792,
                        [2] = -2.5631999969482,
                        [3] = 20.005699157715,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                        [1] = 0.0,
                        [2] = 0.0,
                        [3] = 0.70710700750351,
                        [4] = 0.70710700750351,
                    },
                },
                [3] = {
                    ["$250000979"] = 1,
                },
                [4] = {
                    ["MDL_TYPE"] = 1290,
                },
                [5] = {
                    ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/WEAPON_LASERD_01.MDL",
                },
            },   -- end properties
        },  -- end entry [3]

        -------------------- ENTRY [4] --------------------
        [4] = {
            ["name"] = "MAINSHIP",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "1203234108425838767",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A AF 20 5B EE 0B BF B2 10",
            ["properties"] = {
                [1] = {
                    ["$250000979"] = 1,
                },
                [2] = {
                    ["MDL_TYPE"] = 64546,
                },
                [3] = {
                    ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/PIRATE3_GUNSHIP01A_LOD0.MDL",
                },
            },   -- end properties
        },  -- end entry [4]

        -------------------- ENTRY [5] --------------------
        [5] = {
            ["name"] = "LeftTurret",
            ["identifier_type"] = "6343081",  -- do not change
            ["identifier"] = "-793291378712139794",  -- do not change
            ["identifier_hex"] = "A9 C9 60 00 EE A7 7B B0 B1 A9 FD F4",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 9.6476802825928,
                        [2] = 0.36230999231339,
                        [3] = 9.0979099273682,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                        [1] = 0.0,
                        [2] = 0.0,
                        [3] = -0.70710700750351,
                        [4] = 0.70710700750351,
                    },
                },
                [3] = {
                    ["TYPE_STRING"] = "CONTROLLED TURRET",
                },
                [4] = {
                    ["POSITIONING"] = "FREE",
                },
                [5] = {
                    ["HARDPOINT_NUMBER_1"] = 1,
                },
				[6] = {
                    ["HARDPOINT_NUMBER_2"] = 1,
                },

            },   -- end properties
        },  -- end entry [5]

        -------------------- ENTRY [6] --------------------
        [6] = {
            ["name"] = "PIRATEFIGHTER_01",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-8175368865230424936",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A 98 F4 26 00 55 41 8B 8E",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = -1.711599946022,
                        [2] = 2.1728000640869,
                        [3] = 8.7306995391846,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                        [1] = 0.0,
                        [2] = 0.0,
                        [3] = 1.0,
                        [4] = 1.1920899822826e-007,
                    },
                },
                [3] = {
                    ["$250000979"] = 1,
                },
                [4] = {
                    ["MDL_TYPE"] = 1290,
                },
                [5] = {
                    ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/WEAPON_LASERD_01.MDL",
                },
            },   -- end properties
        },  -- end entry [6]

        -------------------- ENTRY [7] --------------------
        [7] = {
            ["name"] = "PIRATEFIGHTER_01",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "3483807038165165365",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A 35 25 D7 0F 0B F8 58 30",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 4.4593000411987,
                        [2] = -2.739000082016,
                        [3] = 10.948300361633,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                        [1] = 0.0,
                        [2] = 0.0,
                        [3] = 4.3711398944879e-008,
                        [4] = -1.0,
                    },
                },
                [3] = {
                    ["$250000979"] = 1,
                },
                [4] = {
                    ["MDL_TYPE"] = 1659,
                },
                [5] = {
                    ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/WEAPON_MISSILELAUNCHERDF_01.MDL",
                },
            },   -- end properties
        },  -- end entry [7]

        -------------------- ENTRY [8] --------------------
        [8] = {
            ["name"] = "Boosters",
            ["identifier_type"] = "4270653419",  -- do not change
            ["identifier"] = "-1628197954410250815",  -- do not change
            ["identifier_hex"] = "EB FF 8C FE C1 FD 5B 47 96 7A 67 E9",
        },  -- end entry [8]

        -------------------- ENTRY [9] --------------------
        [9] = {
            ["name"] = "PIRATEFIGHTER_01",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-6858512815225180737",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A BF ED 09 B9 EE AA D1 A0",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = -4.4593000411987,
                        [2] = -2.739000082016,
                        [3] = 10.948300361633,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                        [1] = 0.0,
                        [2] = 0.0,
                        [3] = 4.3711398944879e-008,
                        [4] = -1.0,
                    },
                },
                [3] = {
                    ["$250000979"] = 1,
                },
                [4] = {
                    ["MDL_TYPE"] = 1659,
                },
                [5] = {
                    ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/WEAPON_MISSILELAUNCHERDF_01.MDL",
                },
            },   -- end properties
        },  -- end entry [9]

        -------------------- ENTRY [10] --------------------
        [10] = {
            ["name"] = "RightTurret",
            ["identifier_type"] = "6343081",  -- do not change
            ["identifier"] = "1779529482831330366",  -- do not change
            ["identifier_hex"] = "A9 C9 60 00 3E FC 7E E3 A2 28 B2 18",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = -9.6476802825928,
                        [2] = 0.36230999231339,
                        [3] = 9.0979099273682,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                        [1] = 0.0,
                        [2] = 0.0,
                        [3] = 0.70710700750351,
                        [4] = 0.70710700750351,
                    },
                },
                [3] = {
                    ["TYPE_STRING"] = "CONTROLLED TURRET",
                },
                [4] = {
                    ["POSITIONING"] = "FREE",
                },
                [5] = {
                    ["HARDPOINT_NUMBER_1"] = 1,
                },
				[6] = {
                    ["HARDPOINT_NUMBER_2"] = 2,
                },
            },   -- end properties
        },  -- end entry [10]

        -------------------- ENTRY [11] --------------------
        [11] = {
            ["name"] = "BotTurret",
            ["identifier_type"] = "6343081",  -- do not change
            ["identifier"] = "1669663321759628850",  -- do not change
            ["identifier_hex"] = "A9 C9 60 00 32 3E FB E3 F1 D5 2B 17",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 6.6226898525201e-006,
                        [2] = -4.148099899292,
                        [3] = -0.66519302129745,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                        [1] = 0.0,
                        [2] = 0.0,
                        [3] = -1.0,
                        [4] = 0.0,
                    },
                },
                [3] = {
                    ["TYPE_STRING"] = "CONTROLLED TURRET",
                },
                [4] = {
                    ["POSITIONING"] = "FREE",
                },
                [5] = {
                    ["HARDPOINT_NUMBER_1"] = 1,
                },
				[6] = {
                    ["HARDPOINT_NUMBER_2"] = 0,
                },
            },   -- end properties
        },  -- end entry [11]

        -------------------- ENTRY [12] --------------------
        [12] = {
            ["name"] = "PIRATEFIGHTER_01",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-3473659554339852575",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A E1 6E EE 20 0A 15 CB CF",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 2.6315999031067,
                        [2] = -2.1393001079559,
                        [3] = 10.423600196838,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                        [1] = 0.0,
                        [2] = 0.0,
                        [3] = -1.3113400143538e-007,
                        [4] = 1.0,
                    },
                },
                [3] = {
                    ["$250000979"] = 1,
                },
                [4] = {
                    ["MDL_TYPE"] = 1290,
                },
                [5] = {
                    ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/WEAPON_LASERD_01.MDL",
                },
            },   -- end properties
        },  -- end entry [12]

        -------------------- ENTRY [13] --------------------
        [13] = {
            ["name"] = "GlowsLeft",
            ["identifier_type"] = "4270653419",  -- do not change
            ["identifier"] = "1932151775147686321",  -- do not change
            ["identifier_hex"] = "EB FF 8C FE B1 79 D1 71 CD 61 D0 1A",
            ["entries"] = {

                -------------------- ENTRY [13] [1] --------------------
                [1] = {
                    ["name"] = "EngineFull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-8436258744687623046",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 7A 84 9C 71 5E 63 EC 8A",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -5.9422202110291,
                                [2] = 4.5139198303223,
                                [3] = -17.962400436401,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.69999998807907,
                        },
                        [3] = {
                            ["$121"] = 0.69999998807907,
                        },
                        [4] = {
                            ["$122"] = 0.69999998807907,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [1]

                -------------------- ENTRY [13] [2] --------------------
                [2] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "3119924129726919898",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A DA F4 8A 46 77 32 4C 2B",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -6.7336101531982,
                                [2] = -4.9659900665283,
                                [3] = -14.57409954071,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.25,
                        },
                        [3] = {
                            ["$121"] = 0.25,
                        },
                        [4] = {
                            ["$122"] = 0.25,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [2]

                -------------------- ENTRY [13] [3] --------------------
                [3] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "8234665246765522770",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 52 9F B6 AD 69 68 47 72",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -5.9422202110291,
                                [2] = 4.5139198303223,
                                [3] = -17.962400436401,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.69999998807907,
                        },
                        [3] = {
                            ["$121"] = 0.69999998807907,
                        },
                        [4] = {
                            ["$122"] = 0.69999998807907,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [3]

                -------------------- ENTRY [13] [4] --------------------
                [4] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "8374557814086841462",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 76 34 9E 2B F6 67 38 74",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -6.302020072937,
                                [2] = 1.5030299425125,
                                [3] = -21.778999328613,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetiny",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "ENGINE EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [13] [4]

                -------------------- ENTRY [13] [5] --------------------
                [5] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "3786065612757454228",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 94 CD BA 88 9D CE 8A 34",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -4.6633200645447,
                                [2] = -4.2939801216125,
                                [3] = -14.799900054932,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetinybooster",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "BOOSTER EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [13] [5]

                -------------------- ENTRY [13] [6] --------------------
                [6] = {
                    ["name"] = "EngineFull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-155120809576863010",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 DE 6A E6 0F 72 E6 D8 FD",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -6.9092202186584,
                                [2] = -2.847179889679,
                                [3] = -16.367599487305,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [6]

                -------------------- ENTRY [13] [7] --------------------
                [7] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "9032928205437356919",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 77 4B B3 26 58 68 5B 7D",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -6.9092202186584,
                                [2] = -2.847179889679,
                                [3] = -16.367599487305,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetinybooster",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "BOOSTER EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [13] [7]

                -------------------- ENTRY [13] [8] --------------------
                [8] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "-7602641826995576786",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 2E E0 66 F3 89 FD 7D 96",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -2.4723300933838,
                                [2] = -2.4943699836731,
                                [3] = -20.941499710083,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [8]

                -------------------- ENTRY [13] [9] --------------------
                [9] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "-5842905849055784812",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 94 50 FA 5A 16 D4 E9 AE",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -2.4723300933838,
                                [2] = -2.4943699836731,
                                [3] = -20.941499710083,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetiny",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "ENGINE EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [13] [9]

                -------------------- ENTRY [13] [10] --------------------
                [10] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "-7400790639761857151",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 81 65 F5 CB 1F 1C 4B 99",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -4.6633200645447,
                                [2] = -4.2939801216125,
                                [3] = -14.799900054932,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetiny",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "ENGINE EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [13] [10]

                -------------------- ENTRY [13] [11] --------------------
                [11] = {
                    ["name"] = "EngineFull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-2010036571675808966",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 3A 2B B8 3F 63 EA 1A E4",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -8.4499101638794,
                                [2] = 3.9853100776672,
                                [3] = -19.02140045166,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.85000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.85000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.85000002384186,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [11]

                -------------------- ENTRY [13] [12] --------------------
                [12] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "5658263821744225594",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 3A 3D 82 94 F7 30 86 4E",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -6.9092202186584,
                                [2] = -2.847179889679,
                                [3] = -16.367599487305,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [12]

                -------------------- ENTRY [13] [13] --------------------
                [13] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "-4328876539680120088",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A E8 22 D8 F7 B8 BD EC C3",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -8.4499101638794,
                                [2] = 3.9853100776672,
                                [3] = -19.02140045166,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.85000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.85000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.85000002384186,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [13]

                -------------------- ENTRY [13] [14] --------------------
                [14] = {
                    ["name"] = "EngineSmall",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-5552657571093136574",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 42 3B 9C BB 5B FF F0 B2",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -6.7336101531982,
                                [2] = -4.9659900665283,
                                [3] = -14.57409954071,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.25,
                        },
                        [3] = {
                            ["$121"] = 0.25,
                        },
                        [4] = {
                            ["$122"] = 0.25,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                        [7] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [14]

                -------------------- ENTRY [13] [15] --------------------
                [15] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "2192305710754650390",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 16 59 97 B8 6D A2 6C 1E",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -9.0275096893311,
                                [2] = 1.6599099636078,
                                [3] = -18.90419960022,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.25,
                        },
                        [3] = {
                            ["$121"] = 0.25,
                        },
                        [4] = {
                            ["$122"] = 0.25,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [15]

                -------------------- ENTRY [13] [16] --------------------
                [16] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "-5116524561353476892",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 E4 F4 F6 1B 05 74 FE B8",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -5.9422202110291,
                                [2] = 4.5139198303223,
                                [3] = -17.962400436401,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetinybooster",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "BOOSTER EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [13] [16]

                -------------------- ENTRY [13] [17] --------------------
                [17] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "-1649124979015256626",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 CE 75 92 AB 91 21 1D E9",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -6.302020072937,
                                [2] = 1.5030299425125,
                                [3] = -21.778999328613,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetinybooster",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "BOOSTER EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [13] [17]

                -------------------- ENTRY [13] [18] --------------------
                [18] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "-6297454344091023405",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A D3 C7 36 AF A3 F2 9A A8",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -9.9739103317261,
                                [2] = 2.2805099487305,
                                [3] = -18.752000808716,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.25,
                        },
                        [3] = {
                            ["$121"] = 0.25,
                        },
                        [4] = {
                            ["$122"] = 0.25,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [18]

                -------------------- ENTRY [13] [19] --------------------
                [19] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "-5290728735558041718",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 8A 7F 1C 1A 3F 8E 93 B6",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -2.4723300933838,
                                [2] = -2.4943699836731,
                                [3] = -20.941499710083,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetinybooster",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "BOOSTER EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [13] [19]

                -------------------- ENTRY [13] [20] --------------------
                [20] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "8365522887241239990",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 B6 0D 6A 56 BE 4E 18 74",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -8.4499101638794,
                                [2] = 3.9853100776672,
                                [3] = -19.02140045166,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetinybooster",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "BOOSTER EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [13] [20]

                -------------------- ENTRY [13] [21] --------------------
                [21] = {
                    ["name"] = "EngineFull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-83506826364834955",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 75 2B 34 DE FB 52 D7 FE",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -6.302020072937,
                                [2] = 1.5030299425125,
                                [3] = -21.778999328613,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [21]

                -------------------- ENTRY [13] [22] --------------------
                [22] = {
                    ["name"] = "EngineSmall",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "699218984875364017",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 B1 8E B4 4D F6 1F B4 09",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -9.0275096893311,
                                [2] = 1.6599099636078,
                                [3] = -18.90419960022,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.25,
                        },
                        [3] = {
                            ["$121"] = 0.25,
                        },
                        [4] = {
                            ["$122"] = 0.25,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                        [7] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [22]

                -------------------- ENTRY [13] [23] --------------------
                [23] = {
                    ["name"] = "EngineFull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "1682538894848779202",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 C2 63 3D DC 35 94 59 17",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -4.6633200645447,
                                [2] = -4.2939801216125,
                                [3] = -14.799900054932,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [23]

                -------------------- ENTRY [13] [24] --------------------
                [24] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "-3490593661210637410",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 9E 4B 4F 20 8F EB 8E CF",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -6.9092202186584,
                                [2] = -2.847179889679,
                                [3] = -16.367599487305,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetiny",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "ENGINE EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [13] [24]

                -------------------- ENTRY [13] [25] --------------------
                [25] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "-7578699929316959598",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 92 DA C8 65 91 0C D3 96",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -6.302020072937,
                                [2] = 1.5030299425125,
                                [3] = -21.778999328613,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [25]

                -------------------- ENTRY [13] [26] --------------------
                [26] = {
                    ["name"] = "EngineFull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-345104110532881675",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 F5 12 29 D1 A3 F1 35 FB",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -2.4723300933838,
                                [2] = -2.4943699836731,
                                [3] = -20.941499710083,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [26]

                -------------------- ENTRY [13] [27] --------------------
                [27] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "9057508493282074302",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 BE 5E 29 64 FC BB B2 7D",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -8.4499101638794,
                                [2] = 3.9853100776672,
                                [3] = -19.02140045166,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetiny",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "ENGINE EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [13] [27]

                -------------------- ENTRY [13] [28] --------------------
                [28] = {
                    ["name"] = "EngineSmall",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-5475746285149400532",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 2C 52 81 F1 C3 3D 02 B4",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -9.9739103317261,
                                [2] = 2.2805099487305,
                                [3] = -18.752000808716,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.25,
                        },
                        [3] = {
                            ["$121"] = 0.25,
                        },
                        [4] = {
                            ["$122"] = 0.25,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                        [7] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [28]

                -------------------- ENTRY [13] [29] --------------------
                [29] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "3922869779866697793",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 41 C0 11 D1 47 D5 70 36",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -5.9422202110291,
                                [2] = 4.5139198303223,
                                [3] = -17.962400436401,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetiny",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "ENGINE EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [13] [29]

                -------------------- ENTRY [13] [30] --------------------
                [30] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "3294695606282970718",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 5E 66 89 A7 32 1C B9 2D",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -4.6633200645447,
                                [2] = -4.2939801216125,
                                [3] = -14.799900054932,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [13] [30]
            },   -- end entries for [13]
        },  -- end entry [13]

        -------------------- ENTRY [14] --------------------
        [14] = {
            ["name"] = "PIRATEFIGHTER_01",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "6432735796403550323",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A 73 B8 92 EE 1F AB 45 59",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = -2.6315999031067,
                        [2] = -2.1393001079559,
                        [3] = 10.423600196838,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                        [1] = 0.0,
                        [2] = 0.0,
                        [3] = -1.3113400143538e-007,
                        [4] = 1.0,
                    },
                },
                [3] = {
                    ["$250000979"] = 1,
                },
                [4] = {
                    ["MDL_TYPE"] = 1290,
                },
                [5] = {
                    ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/WEAPON_LASERD_01.MDL",
                },
            },   -- end properties
        },  -- end entry [14]

        -------------------- ENTRY [15] --------------------
        [15] = {
            ["name"] = "Jets",
            ["identifier_type"] = "4270653419",  -- do not change
            ["identifier"] = "-4768429258877576332",  -- do not change
            ["identifier_hex"] = "EB FF 8C FE 74 DB 05 70 DA 22 D3 BD",
            ["entries"] = {

                -------------------- ENTRY [15] [1] --------------------
                [1] = {
                    ["name"] = "left",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "-6126590316269732521",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 57 FD 64 42 91 FA F9 AA",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -7.9806299209595,
                                [2] = -1.0064899921417,
                                [3] = 11.891900062561,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.60715597867966,
                                [2] = 0.32591599225998,
                                [3] = -0.64844101667404,
                                [4] = 0.32351899147034,
                            },
                        },
                        [3] = {
                            ["FX_STRING"] = "maneuveringthrusterfighter",
                        },
                        [4] = {
                            ["TYPE_STRING"] = "MANEUVERING LEFT",
                        },
                    },   -- end properties
                },  -- end entry [15] [1]

                -------------------- ENTRY [15] [2] --------------------
                [2] = {
                    ["name"] = "right",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "-5899931510458299666",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 EE CA FF E7 8C 3B 1F AE",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 8.1891202926636,
                                [2] = -1.0228799581528,
                                [3] = 11.8922996521,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.64844101667404,
                                [2] = 0.32351899147034,
                                [3] = 0.60715597867966,
                                [4] = -0.32591599225998,
                            },
                        },
                        [3] = {
                            ["FX_STRING"] = "maneuveringthrusterfighter",
                        },
                        [4] = {
                            ["TYPE_STRING"] = "MANEUVERING RIGHT",
                        },
                    },   -- end properties
                },  -- end entry [15] [2]

                -------------------- ENTRY [15] [3] --------------------
                [3] = {
                    ["name"] = "frontdown",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "8917720160000046733",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 8D 76 24 C7 3C 1B C2 7B",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -4.4644899368286,
                                [2] = 2.9302699565887,
                                [3] = 9.0524101257324,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.83476799726486,
                                [2] = 0.0,
                                [3] = 0.0,
                                [4] = -0.5506010055542,
                            },
                        },
                        [3] = {
                            ["FX_STRING"] = "maneuveringthrusterfighter",
                        },
                        [4] = {
                            ["TYPE_STRING"] = "MANEUVERING DOWN",
                        },
                    },   -- end properties
                },  -- end entry [15] [3]

                -------------------- ENTRY [15] [4] --------------------
                [4] = {
                    ["name"] = "frontdown",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "1244691547934550739",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 D3 EA 91 41 5E 08 46 11",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 4.4645099639893,
                                [2] = 2.9379200935364,
                                [3] = 9.0063104629517,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.83476799726486,
                                [2] = 0.0,
                                [3] = 0.0,
                                [4] = -0.5506010055542,
                            },
                        },
                        [3] = {
                            ["FX_STRING"] = "maneuveringthrusterfighter",
                        },
                        [4] = {
                            ["TYPE_STRING"] = "MANEUVERING DOWN",
                        },
                    },   -- end properties
                },  -- end entry [15] [4]

                -------------------- ENTRY [15] [5] --------------------
                [5] = {
                    ["name"] = "up",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "-5646743263028664740",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 5C A6 58 85 EB BC A2 B1",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -0.50770002603531,
                                [2] = -0.82129001617432,
                                [3] = 15.119199752808,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.92884701490402,
                                [2] = 0.0,
                                [3] = 0.0,
                                [4] = -0.37046399712563,
                            },
                        },
                        [3] = {
                            ["FX_STRING"] = "maneuveringthrusterfighter",
                        },
                        [4] = {
                            ["TYPE_STRING"] = "MANEUVERING UP",
                        },
                    },   -- end properties
                },  -- end entry [15] [5]

                -------------------- ENTRY [15] [6] --------------------
                [6] = {
                    ["name"] = "frontup",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "3117524749278907070",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 BE 0A 42 FB 3D AC 43 2B",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -5.4267997741699,
                                [2] = -2.2441899776459,
                                [3] = 12.419199943542,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.88701099157333,
                                [2] = 0.0,
                                [3] = 0.0,
                                [4] = 0.46174898743629,
                            },
                        },
                        [3] = {
                            ["FX_STRING"] = "maneuveringthrusterfighter",
                        },
                        [4] = {
                            ["TYPE_STRING"] = "MANEUVERING UP",
                        },
                    },   -- end properties
                },  -- end entry [15] [6]

                -------------------- ENTRY [15] [7] --------------------
                [7] = {
                    ["name"] = "up",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "2966168495475933227",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 2B 40 CC FC 87 F2 29 29",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.45590001344681,
                                [2] = -0.82129001617432,
                                [3] = 15.119199752808,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.92884701490402,
                                [2] = 0.0,
                                [3] = 0.0,
                                [4] = -0.37046399712563,
                            },
                        },
                        [3] = {
                            ["FX_STRING"] = "maneuveringthrusterfighter",
                        },
                        [4] = {
                            ["TYPE_STRING"] = "MANEUVERING UP",
                        },
                    },   -- end properties
                },  -- end entry [15] [7]

                -------------------- ENTRY [15] [8] --------------------
                [8] = {
                    ["name"] = "frontup",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "7791425423696033951",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 9F 78 59 61 24 B4 20 6C",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 5.4267997741699,
                                [2] = -2.2441899776459,
                                [3] = 12.419199943542,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.88701099157333,
                                [2] = 0.0,
                                [3] = 0.0,
                                [4] = 0.46174898743629,
                            },
                        },
                        [3] = {
                            ["FX_STRING"] = "maneuveringthrusterfighter",
                        },
                        [4] = {
                            ["TYPE_STRING"] = "MANEUVERING UP",
                        },
                    },   -- end properties
                },  -- end entry [15] [8]
            },   -- end entries for [15]
        },  -- end entry [15]

        -------------------- ENTRY [16] --------------------
        [16] = {
            ["name"] = "PIRATEFIGHTER_01",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "7634326129640522482",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A F2 C2 B4 A0 2A 93 F2 69",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 1.711599946022,
                        [2] = 2.1728000640869,
                        [3] = 8.7306995391846,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                        [1] = 0.0,
                        [2] = 0.0,
                        [3] = 1.0,
                        [4] = 1.1920899822826e-007,
                    },
                },
                [3] = {
                    ["$250000979"] = 1,
                },
                [4] = {
                    ["MDL_TYPE"] = 1290,
                },
                [5] = {
                    ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/WEAPON_LASERD_01.MDL",
                },
            },   -- end properties
        },  -- end entry [16]

        -------------------- ENTRY [17] --------------------
        [17] = {
            ["name"] = "Hardpoints",
            ["identifier_type"] = "4270653419",  -- do not change
            ["identifier"] = "-89170053832803087",  -- do not change
            ["identifier_hex"] = "EB FF 8C FE F1 7C B1 F8 4E 34 C3 FE",
            ["entries"] = {

                -------------------- ENTRY [17] [1] --------------------
                [1] = {
                    ["name"] = "bk0",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-8168541603271822725",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 7B B2 FB CB B0 82 A3 8E",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 1.711599946022,
                                [2] = 2.1728000640869,
                                [3] = 8.7306995391846,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = 1.0,
                                [4] = 1.1920899822826e-007,
                            },
                        },
                        [3] = {
                            ["TYPE_STRING"] = "HARDPOINT",
                        },
                        [4] = {
                            ["HARDPOINT_NUMBER_1"] = 0,
                        },
						[5] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [17] [1]

                -------------------- ENTRY [17] [2] --------------------
                [2] = {
                    ["name"] = "bk0",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "3748836047752548125",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 1D 4F 78 F3 85 8A 06 34",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 2.6315999031067,
                                [2] = -2.1393001079559,
                                [3] = 10.423600196838,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = -1.3113400143538e-007,
                                [4] = 1.0,
                            },
                        },
                        [3] = {
                            ["TYPE_STRING"] = "HARDPOINT",
                        },
                        [4] = {
                            ["HARDPOINT_NUMBER_1"] = 2,
                        },
						[5] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [17] [2]

                -------------------- ENTRY [17] [3] --------------------
                [3] = {
                    ["name"] = "bk0",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "775562612666169527",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 B7 78 0A 4D 16 5A C3 0A",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -2.6315999031067,
                                [2] = -2.1393001079559,
                                [3] = 10.423600196838,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = -1.3113400143538e-007,
                                [4] = 1.0,
                            },
                        },
                        [3] = {
                            ["TYPE_STRING"] = "HARDPOINT",
                        },
                        [4] = {
                            ["HARDPOINT_NUMBER_1"] = 3,
                        },
						[5] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [17] [3]

                -------------------- ENTRY [17] [4] --------------------
                [4] = {
                    ["name"] = "bk1",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-5981599746144511206",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 1A 5B 7D 06 B9 16 FD AC",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 8.6943998336792,
                                [2] = -2.5631999969482,
                                [3] = 20.005699157715,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = 0.70710700750351,
                                [4] = -0.70710700750351,
                            },
                        },
                        [3] = {
                            ["TYPE_STRING"] = "HARDPOINT",
                        },
                        [4] = {
                            ["HARDPOINT_NUMBER_1"] = 4,
                        },
                        [5] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [17] [4]

                -------------------- ENTRY [17] [5] --------------------
                [5] = {
                    ["name"] = "bk1",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "7307087637285975973",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 A5 37 14 D3 7D FD 67 65",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -8.6943998336792,
                                [2] = -2.5631999969482,
                                [3] = 20.005699157715,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = 0.70710700750351,
                                [4] = 0.70710700750351,
                            },
                        },
                        [3] = {
                            ["TYPE_STRING"] = "HARDPOINT",
                        },
                        [4] = {
                            ["HARDPOINT_NUMBER_1"] = 5,
                        },
                        [5] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [17] [5]

                -------------------- ENTRY [17] [6] --------------------
                [6] = {
                    ["name"] = "bk0",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-4597022212740520962",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 FE 63 05 51 A7 18 34 C0",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -1.711599946022,
                                [2] = 2.1728000640869,
                                [3] = 8.7306995391846,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = 1.0,
                                [4] = 1.1920899822826e-007,
                            },
                        },
                        [3] = {
                            ["TYPE_STRING"] = "HARDPOINT",
                        },
                        [4] = {
                            ["HARDPOINT_NUMBER_1"] = 1,
                        },
						[5] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [17] [6]

                -------------------- ENTRY [17] [7] --------------------
                [7] = {
                    ["name"] = "ECM",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "6670957351020206049",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 E1 17 57 D3 5D 00 94 5C",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.0,
                                [2] = -0.19941000640392,
                                [3] = -22.98390007019,
                            },
                        },
                        [2] = {
                            ["TYPE_STRING"] = "ECM HARDPOINT",
                        },
                    },   -- end properties
                },  -- end entry [17] [7]

                -------------------- ENTRY [17] [8] --------------------
                [8] = {
                    ["name"] = "missile",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "7190126941160629877",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 75 66 D8 A9 5B 76 C8 63",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 4.4593000411987,
                                [2] = -2.739000082016,
                                [3] = 10.948300361633,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = 4.3711398944879e-008,
                                [4] = -1.0,
                            },
                        },
                        [3] = {
                            ["TYPE_STRING"] = "MISSILE HARDPOINT",
                        },
                        [4] = {
                            ["HARDPOINT_NUMBER_1"] = 8,
                        },
                        [5] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [17] [8]

                -------------------- ENTRY [17] [9] --------------------
                [9] = {
                    ["name"] = "missile",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "1844693204721324041",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 09 D0 FD 32 B2 AA 99 19",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -4.4593000411987,
                                [2] = -2.739000082016,
                                [3] = 10.948300361633,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = 4.3711398944879e-008,
                                [4] = -1.0,
                            },
                        },
                        [3] = {
                            ["TYPE_STRING"] = "MISSILE HARDPOINT",
                        },
                        [4] = {
                            ["HARDPOINT_NUMBER_1"] = 9,
                        },
                        [5] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [17] [9]
            },   -- end entries for [17]
        },  -- end entry [17]

        -------------------- ENTRY [18] --------------------
        [18] = {
            ["name"] = "PilotModel",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "1862320521084371149",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A CD 80 27 9D A5 4A D8 19",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.0,
                        [2] = 4.1336002349854,
                        [3] = 0.22230200469494,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                        [1] = -0.095845699310303,
                        [2] = 0.0,
                        [3] = 0.0,
                        [4] = 0.99539601802826,
                    },
                },
                [3] = {
                    ["$120"] = 0.89999997615814,
                },
                [4] = {
                    ["$121"] = 0.89999997615814,
                },
                [5] = {
                    ["$122"] = 0.89999997615814,
                },
                [6] = {
                    ["$250000979"] = 1,
                },
                [7] = {
                    ["MDL_TYPE"] = 14485,
                },
                [8] = {
                    ["MDL_1"] = "MEDIA/CHARACTERS/PILOT/PILOT_SEATED.MDL",
                },
            },   -- end properties
        },  -- end entry [18]

        -------------------- ENTRY [19] --------------------
        [19] = {
            ["name"] = "Chunks",
            ["identifier_type"] = "4270653419",  -- do not change
            ["identifier"] = "-5403780264237917538",  -- do not change
            ["identifier_hex"] = "EB FF 8C FE 9E 1A D5 E9 7A EA 01 B5",
            ["entries"] = {

                -------------------- ENTRY [19] [1] --------------------
                [1] = {
                    ["name"] = "debrishull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "8645930695029533083",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 9B A9 E1 B5 28 84 FC 77",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 1.7599999904633,
                                [2] = 1.4299999475479,
                                [3] = -1.0099999904633,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.060823999345303,
                                [2] = -0.095474600791931,
                                [3] = 0.81882798671722,
                                [4] = 0.56276601552963,
                            },
                        },
                        [3] = {
                            ["$120"] = 3.0,
                        },
                        [4] = {
                            ["$121"] = 3.0,
                        },
                        [5] = {
                            ["$122"] = 3.0,
                        },
                        [6] = {
                            ["TYPE_STRING"] = "DEATH CHUNK",
                        },
                        [7] = {
                            ["HARDPOINT_NUMBER_1"] = 100,
                        },
                        [8] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\SHIP_SET_1\\DEBRIS_HULL.DAT",
                        },
                    },   -- end properties
                },  -- end entry [19] [1]

                -------------------- ENTRY [19] [2] --------------------
                [2] = {
                    ["name"] = "debris_fin",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "-2868486655385584674",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A DE 3B CB B6 95 16 31 D8",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -12.369899749756,
                                [2] = 0.08049999922514,
                                [3] = -7.9200000762939,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = 0.89940500259399,
                                [4] = -0.437117010355,
                            },
                        },
                        [3] = {
                            ["$120"] = 5.0,
                        },
                        [4] = {
                            ["$121"] = 5.0,
                        },
                        [5] = {
                            ["$122"] = 5.0,
                        },
                        [6] = {
                            ["$250000979"] = 1,
                        },
                        [7] = {
                            ["MDL_TYPE"] = 190,
                        },
                        [8] = {
                            ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/DEBRIS_FIN_01.MDL",
                        },
                    },   -- end properties
                },  -- end entry [19] [2]

                -------------------- ENTRY [19] [3] --------------------
                [3] = {
                    ["name"] = "debris_fin",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "4754540197589688742",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A A6 21 A6 7B 1E 85 FB 41",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 5.0981001853943,
                                [2] = 6.4040999412537,
                                [3] = -8.326000213623,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = -0.8427619934082,
                                [4] = -0.53828597068787,
                            },
                        },
                        [3] = {
                            ["$120"] = 5.0,
                        },
                        [4] = {
                            ["$121"] = 5.0,
                        },
                        [5] = {
                            ["$122"] = 5.0,
                        },
                        [6] = {
                            ["$250000979"] = 1,
                        },
                        [7] = {
                            ["MDL_TYPE"] = 190,
                        },
                        [8] = {
                            ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/DEBRIS_FIN_01.MDL",
                        },
                    },   -- end properties
                },  -- end entry [19] [3]

                -------------------- ENTRY [19] [4] --------------------
                [4] = {
                    ["name"] = "debris_strut",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "362237777316039669",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A F5 4B 26 D9 56 ED 06 05",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -2.039999961853,
                                [2] = 8.3819003293684e-008,
                                [3] = -3.0099999904633,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.57589799165726,
                                [2] = 0.40224999189377,
                                [3] = 0.38844799995422,
                                [4] = 0.59636002779007,
                            },
                        },
                        [3] = {
                            ["$120"] = 0.80000001192093,
                        },
                        [4] = {
                            ["$121"] = 0.80000001192093,
                        },
                        [5] = {
                            ["$122"] = 0.80000001192093,
                        },
                        [6] = {
                            ["$250000979"] = 1,
                        },
                        [7] = {
                            ["MDL_TYPE"] = 254,
                        },
                        [8] = {
                            ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/DEBRIS_STRUT_01.MDL",
                        },
                    },   -- end properties
                },  -- end entry [19] [4]

                -------------------- ENTRY [19] [5] --------------------
                [5] = {
                    ["name"] = "debrisstrut",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "895506953422522229",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 75 47 A4 5C D4 7A 6D 0C",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 1.5599999427795,
                                [2] = 8.3819003293684e-008,
                                [3] = -3.0099999904633,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.32906699180603,
                                [2] = 0.62062698602676,
                                [3] = -0.54457497596741,
                                [4] = 0.4582299888134,
                            },
                        },
                        [3] = {
                            ["$120"] = 2.0,
                        },
                        [4] = {
                            ["$121"] = 2.0,
                        },
                        [5] = {
                            ["$122"] = 2.0,
                        },
                        [6] = {
                            ["TYPE_STRING"] = "DEATH CHUNK",
                        },
                        [7] = {
                            ["HARDPOINT_NUMBER_1"] = 100,
                        },
                        [8] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\SHIP_SET_1\\DEBRIS_STRUT.DAT",
                        },
                    },   -- end properties
                },  -- end entry [19] [5]

                -------------------- ENTRY [19] [6] --------------------
                [6] = {
                    ["name"] = "debrisfin",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "6315019002477812307",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 53 1A 88 08 53 74 A3 57",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -12.369899749756,
                                [2] = 0.08049999922514,
                                [3] = -7.9200000762939,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = 0.89940500259399,
                                [4] = -0.437117010355,
                            },
                        },
                        [3] = {
                            ["$120"] = 10.0,
                        },
                        [4] = {
                            ["$121"] = 10.0,
                        },
                        [5] = {
                            ["$122"] = 10.0,
                        },
                        [6] = {
                            ["TYPE_STRING"] = "DEATH CHUNK",
                        },
                        [7] = {
                            ["HARDPOINT_NUMBER_1"] = 70,
                        },
                        [8] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\SHIP_SET_1\\DEBRIS_FIN.DAT",
                        },
                    },   -- end properties
                },  -- end entry [19] [6]

                -------------------- ENTRY [19] [7] --------------------
                [7] = {
                    ["name"] = "debrishull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-3971063807137162416",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 50 DB 2D CB 81 F2 E3 C8",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -0.15999999642372,
                                [2] = 1.4299999475479,
                                [3] = 6.2199997901917,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.093849703669548,
                                [2] = -0.063302397727966,
                                [3] = 0.52651298046112,
                                [4] = 0.84259700775146,
                            },
                        },
                        [3] = {
                            ["$120"] = 3.0,
                        },
                        [4] = {
                            ["$121"] = 3.0,
                        },
                        [5] = {
                            ["$122"] = 3.0,
                        },
                        [6] = {
                            ["TYPE_STRING"] = "DEATH CHUNK",
                        },
                        [7] = {
                            ["HARDPOINT_NUMBER_1"] = 100,
                        },
                        [8] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\SHIP_SET_1\\DEBRIS_HULL.DAT",
                        },
                    },   -- end properties
                },  -- end entry [19] [7]

                -------------------- ENTRY [19] [8] --------------------
                [8] = {
                    ["name"] = "debris_engine",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "6843925747658621890",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A C2 83 57 F2 34 82 FA 5E",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -3.8527998924255,
                                [2] = -0.28139999508858,
                                [3] = -11.585599899292,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.58668899536133,
                                [2] = 0.048106901347637,
                                [3] = -0.03758529946208,
                                [4] = 0.80750799179077,
                            },
                        },
                        [3] = {
                            ["$250000979"] = 1,
                        },
                        [4] = {
                            ["MDL_TYPE"] = 1132,
                        },
                        [5] = {
                            ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/DEBRIS_ENGINESMALL_01.MDL",
                        },
                    },   -- end properties
                },  -- end entry [19] [8]

                -------------------- ENTRY [19] [9] --------------------
                [9] = {
                    ["name"] = "debrishull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-1353003323995758534",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 3A 60 4F 35 A5 2A 39 ED",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.27259999513626,
                                [2] = 2.9216001033783,
                                [3] = -1.0299999713898,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.087975397706032,
                                [2] = -0.071241103112698,
                                [3] = 0.59794598817825,
                                [4] = 0.79350197315216,
                            },
                        },
                        [3] = {
                            ["$120"] = 3.0,
                        },
                        [4] = {
                            ["$121"] = 3.0,
                        },
                        [5] = {
                            ["$122"] = 3.0,
                        },
                        [6] = {
                            ["TYPE_STRING"] = "DEATH CHUNK",
                        },
                        [7] = {
                            ["HARDPOINT_NUMBER_1"] = 100,
                        },
                        [8] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\SHIP_SET_1\\DEBRIS_HULL.DAT",
                        },
                    },   -- end properties
                },  -- end entry [19] [9]

                -------------------- ENTRY [19] [10] --------------------
                [10] = {
                    ["name"] = "debrisstrut",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "3564147132486876227",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 43 7C 1B EF EE 64 76 31",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -2.039999961853,
                                [2] = 8.3819003293684e-008,
                                [3] = -3.0099999904633,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.57589799165726,
                                [2] = 0.40224999189377,
                                [3] = 0.38844799995422,
                                [4] = 0.59636002779007,
                            },
                        },
                        [3] = {
                            ["$120"] = 2.0,
                        },
                        [4] = {
                            ["$121"] = 2.0,
                        },
                        [5] = {
                            ["$122"] = 2.0,
                        },
                        [6] = {
                            ["TYPE_STRING"] = "DEATH CHUNK",
                        },
                        [7] = {
                            ["HARDPOINT_NUMBER_1"] = 100,
                        },
                        [8] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\SHIP_SET_1\\DEBRIS_STRUT.DAT",
                        },
                    },   -- end properties
                },  -- end entry [19] [10]

                -------------------- ENTRY [19] [11] --------------------
                [11] = {
                    ["name"] = "debris_hull",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "7794545447351581167",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A EF 79 07 7F C9 C9 2B 6C",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.27259999513626,
                                [2] = 2.9216001033783,
                                [3] = -1.0299999713898,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.087975397706032,
                                [2] = -0.071241103112698,
                                [3] = 0.59794598817825,
                                [4] = 0.79350197315216,
                            },
                        },
                        [3] = {
                            ["$120"] = 1.5,
                        },
                        [4] = {
                            ["$121"] = 1.5,
                        },
                        [5] = {
                            ["$122"] = 1.5,
                        },
                        [6] = {
                            ["$250000979"] = 1,
                        },
                        [7] = {
                            ["MDL_TYPE"] = 359,
                        },
                        [8] = {
                            ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/DEBRIS_HULL05.MDL",
                        },
                    },   -- end properties
                },  -- end entry [19] [11]

                -------------------- ENTRY [19] [12] --------------------
                [12] = {
                    ["name"] = "debrisengine",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "6402685376934663295",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 7F 54 C7 6C 6D E8 DA 58",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -3.8527998924255,
                                [2] = -0.28139999508858,
                                [3] = -11.585599899292,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.58668899536133,
                                [2] = 0.048106901347637,
                                [3] = -0.03758529946208,
                                [4] = 0.80750799179077,
                            },
                        },
                        [3] = {
                            ["$120"] = 2.0,
                        },
                        [4] = {
                            ["$121"] = 2.0,
                        },
                        [5] = {
                            ["$122"] = 2.0,
                        },
                        [6] = {
                            ["TYPE_STRING"] = "DEATH CHUNK",
                        },
                        [7] = {
                            ["HARDPOINT_NUMBER_1"] = 100,
                        },
                        [8] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\SHIP_SET_1\\DEBRIS_ENGINE_MED.DAT",
                        },
                    },   -- end properties
                },  -- end entry [19] [12]

                -------------------- ENTRY [19] [13] --------------------
                [13] = {
                    ["name"] = "debris_wing_05",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "3889408984970201542",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A C6 89 5C 67 DD F4 F9 35",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -10.295399665833,
                                [2] = 5.0840997695923,
                                [3] = 9.4200000762939,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = -0.99984800815582,
                                [4] = -0.017452400177717,
                            },
                        },
                        [3] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [5] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [6] = {
                            ["$250000979"] = 1,
                        },
                        [7] = {
                            ["MDL_TYPE"] = 1910,
                        },
                        [8] = {
                            ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/DEBRIS_WING_05.MDL",
                        },
                    },   -- end properties
                },  -- end entry [19] [13]

                -------------------- ENTRY [19] [14] --------------------
                [14] = {
                    ["name"] = "debriswing",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "7398800942493986953",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 89 F0 2D B5 41 D2 AD 66",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -10.295399665833,
                                [2] = 5.0840997695923,
                                [3] = 9.4200000762939,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = -0.99984800815582,
                                [4] = -0.017452400177717,
                            },
                        },
                        [3] = {
                            ["$120"] = 2.0,
                        },
                        [4] = {
                            ["$121"] = 2.0,
                        },
                        [5] = {
                            ["$122"] = 2.0,
                        },
                        [6] = {
                            ["TYPE_STRING"] = "DEATH CHUNK",
                        },
                        [7] = {
                            ["HARDPOINT_NUMBER_1"] = 100,
                        },
                        [8] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\SHIP_SET_1\\DEBRIS_WING.DAT",
                        },
                    },   -- end properties
                },  -- end entry [19] [14]

                -------------------- ENTRY [19] [15] --------------------
                [15] = {
                    ["name"] = "debris_strut",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "-4722519164829693862",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 5A 08 5A 2F D7 3D 76 BE",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 1.5599999427795,
                                [2] = 8.3819003293684e-008,
                                [3] = -3.0099999904633,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.32906699180603,
                                [2] = 0.62062698602676,
                                [3] = -0.54457497596741,
                                [4] = 0.4582299888134,
                            },
                        },
                        [3] = {
                            ["$120"] = 0.80000001192093,
                        },
                        [4] = {
                            ["$121"] = 0.80000001192093,
                        },
                        [5] = {
                            ["$122"] = 0.80000001192093,
                        },
                        [6] = {
                            ["$250000979"] = 1,
                        },
                        [7] = {
                            ["MDL_TYPE"] = 254,
                        },
                        [8] = {
                            ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/DEBRIS_STRUT_01.MDL",
                        },
                    },   -- end properties
                },  -- end entry [19] [15]

                -------------------- ENTRY [19] [16] --------------------
                [16] = {
                    ["name"] = "debris_engine",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "-2362629906801578920",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 58 AC 60 15 9E 40 36 DF",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 4.0672001838684,
                                [2] = -0.28139999508858,
                                [3] = -11.585599899292,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.58668899536133,
                                [2] = 0.048106901347637,
                                [3] = -0.03758529946208,
                                [4] = 0.80750799179077,
                            },
                        },
                        [3] = {
                            ["$250000979"] = 1,
                        },
                        [4] = {
                            ["MDL_TYPE"] = 1132,
                        },
                        [5] = {
                            ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/DEBRIS_ENGINESMALL_01.MDL",
                        },
                    },   -- end properties
                },  -- end entry [19] [16]

                -------------------- ENTRY [19] [17] --------------------
                [17] = {
                    ["name"] = "debris_wing_05",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "-8416138141820808594",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 6E 92 27 5C F3 DE 33 8B",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 9.0300998687744,
                                [2] = 4.6105999946594,
                                [3] = 9.460000038147,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 1910,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/SHIP_SET_1/DEBRIS_WING_05.MDL",
                        },
                    },   -- end properties
                },  -- end entry [19] [17]

                -------------------- ENTRY [19] [18] --------------------
                [18] = {
                    ["name"] = "debrisengine",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-534171459494898967",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 E9 92 A7 43 E3 3D 96 F8",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 4.0672001838684,
                                [2] = -0.28139999508858,
                                [3] = -11.585599899292,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.58668899536133,
                                [2] = 0.048106901347637,
                                [3] = -0.03758529946208,
                                [4] = 0.80750799179077,
                            },
                        },
                        [3] = {
                            ["$120"] = 2.0,
                        },
                        [4] = {
                            ["$121"] = 2.0,
                        },
                        [5] = {
                            ["$122"] = 2.0,
                        },
                        [6] = {
                            ["TYPE_STRING"] = "DEATH CHUNK",
                        },
                        [7] = {
                            ["HARDPOINT_NUMBER_1"] = 100,
                        },
                        [8] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\SHIP_SET_1\\DEBRIS_ENGINE_MED.DAT",
                        },
                    },   -- end properties
                },  -- end entry [19] [18]

                -------------------- ENTRY [19] [19] --------------------
                [19] = {
                    ["name"] = "debrishull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-4075716610125253936",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 D0 32 53 50 56 25 70 C7",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.44999998807907,
                                [2] = 1.4299999475479,
                                [3] = 0.17000000178814,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = -0.053145699203014,
                                [2] = -0.09995249658823,
                                [3] = 0.86045801639557,
                                [4] = 0.49678599834442,
                            },
                        },
                        [3] = {
                            ["$120"] = 3.0,
                        },
                        [4] = {
                            ["$121"] = 3.0,
                        },
                        [5] = {
                            ["$122"] = 3.0,
                        },
                        [6] = {
                            ["TYPE_STRING"] = "DEATH CHUNK",
                        },
                        [7] = {
                            ["HARDPOINT_NUMBER_1"] = 100,
                        },
                        [8] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\SHIP_SET_1\\DEBRIS_HULL.DAT",
                        },
                    },   -- end properties
                },  -- end entry [19] [19]

                -------------------- ENTRY [19] [20] --------------------
                [20] = {
                    ["name"] = "debriswing",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "2149954255721757910",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 D6 7C A2 2F 01 2C D6 1D",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 9.0300998687744,
                                [2] = 4.6105999946594,
                                [3] = 9.460000038147,
                            },
                        },
                        [2] = {
                            ["$120"] = 2.0,
                        },
                        [3] = {
                            ["$121"] = 2.0,
                        },
                        [4] = {
                            ["$122"] = 2.0,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "DEATH CHUNK",
                        },
                        [6] = {
                            ["HARDPOINT_NUMBER_1"] = 100,
                        },
                        [7] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\SHIP_SET_1\\DEBRIS_WING.DAT",
                        },
                    },   -- end properties
                },  -- end entry [19] [20]

                -------------------- ENTRY [19] [21] --------------------
                [21] = {
                    ["name"] = "debrisfin",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "3922563275108859939",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 23 40 DB 1D 84 BE 6F 36",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 5.0981001853943,
                                [2] = 6.4040999412537,
                                [3] = -8.326000213623,
                            },
                        },
                        [2] = {
                            ["ROTATIONS"] = {  -- X, Y, Z, W (Quaternion)
                                [1] = 0.0,
                                [2] = 0.0,
                                [3] = -0.8427619934082,
                                [4] = -0.53828597068787,
                            },
                        },
                        [3] = {
                            ["$120"] = 10.0,
                        },
                        [4] = {
                            ["$121"] = 10.0,
                        },
                        [5] = {
                            ["$122"] = 10.0,
                        },
                        [6] = {
                            ["TYPE_STRING"] = "DEATH CHUNK",
                        },
                        [7] = {
                            ["HARDPOINT_NUMBER_1"] = 70,
                        },
                        [8] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\SHIP_SET_1\\DEBRIS_FIN.DAT",
                        },
                    },   -- end properties
                },  -- end entry [19] [21]
            },   -- end entries for [19]
        },  -- end entry [19]

        -------------------- ENTRY [20] --------------------
        [20] = {
            ["name"] = "",
            ["identifier_type"] = "4270653419",  -- do not change
            ["identifier"] = "208622943926116712",  -- do not change
            ["identifier_hex"] = "EB FF 8C FE 68 61 B6 50 76 2D E5 02",
        },  -- end entry [20]

        -------------------- ENTRY [21] --------------------
        [21] = {
            ["name"] = "Glows",
            ["identifier_type"] = "4270653419",  -- do not change
            ["identifier"] = "2562385001054391826",  -- do not change
            ["identifier_hex"] = "EB FF 8C FE 12 CE A2 15 95 6B 8F 23",
            ["entries"] = {

                -------------------- ENTRY [21] [1] --------------------
                [1] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "2794895780763716502",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 96 CB A8 94 E7 76 C9 26",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 6.302020072937,
                                [2] = 1.5030299425125,
                                [3] = -21.778999328613,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetiny",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "ENGINE EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [21] [1]

                -------------------- ENTRY [21] [2] --------------------
                [2] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "-3403311731209580056",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A E8 51 55 11 03 02 C5 D0",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 6.7336101531982,
                                [2] = -4.9659900665283,
                                [3] = -14.57409954071,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.25,
                        },
                        [3] = {
                            ["$121"] = 0.25,
                        },
                        [4] = {
                            ["$122"] = 0.25,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [2]

                -------------------- ENTRY [21] [3] --------------------
                [3] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "-5094091746869301442",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 3E 2F 9B BE 8B 26 4E B9",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 9.9739103317261,
                                [2] = 2.2805099487305,
                                [3] = -18.752000808716,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.25,
                        },
                        [3] = {
                            ["$121"] = 0.25,
                        },
                        [4] = {
                            ["$122"] = 0.25,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [3]

                -------------------- ENTRY [21] [4] --------------------
                [4] = {
                    ["name"] = "EngineSmall",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "1559511084078496195",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 C3 79 C8 7D 11 7F A4 15",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 6.7336101531982,
                                [2] = -4.9659900665283,
                                [3] = -14.57409954071,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.25,
                        },
                        [3] = {
                            ["$121"] = 0.25,
                        },
                        [4] = {
                            ["$122"] = 0.25,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                        [7] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [4]

                -------------------- ENTRY [21] [5] --------------------
                [5] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "8465204400788425795",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 43 4C 11 4C 8D 72 7A 75",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 6.302020072937,
                                [2] = 1.5030299425125,
                                [3] = -21.778999328613,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetinybooster",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "BOOSTER EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [21] [5]

                -------------------- ENTRY [21] [6] --------------------
                [6] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "5475581417637359025",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 B1 2D 01 D9 49 2C FD 4B",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 4.6633200645447,
                                [2] = -4.2939801216125,
                                [3] = -14.799900054932,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetinybooster",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "BOOSTER EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [21] [6]

                -------------------- ENTRY [21] [7] --------------------
                [7] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "-6796411231716285196",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A F4 64 13 62 FE 4B AE A1",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 2.4723300933838,
                                [2] = -2.4943699836731,
                                [3] = -20.941499710083,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [7]

                -------------------- ENTRY [21] [8] --------------------
                [8] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "5655383400573254077",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 BD 39 CF 43 3D F5 7B 4E",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 5.9422202110291,
                                [2] = 4.5139198303223,
                                [3] = -17.962400436401,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetinybooster",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "BOOSTER EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [21] [8]

                -------------------- ENTRY [21] [9] --------------------
                [9] = {
                    ["name"] = "EngineFull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "842847942401394472",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 28 07 81 EE BC 65 B2 0B",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 2.4723300933838,
                                [2] = -2.4943699836731,
                                [3] = -20.941499710083,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [9]

                -------------------- ENTRY [21] [10] --------------------
                [10] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "6671489800797477019",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 9B D8 2C 73 A0 E4 95 5C",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 4.6633200645447,
                                [2] = -4.2939801216125,
                                [3] = -14.799900054932,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [10]

                -------------------- ENTRY [21] [11] --------------------
                [11] = {
                    ["name"] = "EngineFull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "1187483128340030907",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 BB 25 7A 19 9D C9 7A 10",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 6.302020072937,
                                [2] = 1.5030299425125,
                                [3] = -21.778999328613,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [11]

                -------------------- ENTRY [21] [12] --------------------
                [12] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "8575308939212831498",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 0A 3B 03 D9 0B 9E 01 77",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 4.6633200645447,
                                [2] = -4.2939801216125,
                                [3] = -14.799900054932,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetiny",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "ENGINE EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [21] [12]

                -------------------- ENTRY [21] [13] --------------------
                [13] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "2763166925308615705",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 19 DC 20 BE AD BD 58 26",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 8.4499101638794,
                                [2] = 3.9853100776672,
                                [3] = -19.02140045166,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetiny",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "ENGINE EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [21] [13]

                -------------------- ENTRY [21] [14] --------------------
                [14] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "8158423194312062554",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 5A 36 47 88 AB 8A 38 71",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 5.9422202110291,
                                [2] = 4.5139198303223,
                                [3] = -17.962400436401,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.69999998807907,
                        },
                        [3] = {
                            ["$121"] = 0.69999998807907,
                        },
                        [4] = {
                            ["$122"] = 0.69999998807907,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [14]

                -------------------- ENTRY [21] [15] --------------------
                [15] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "620025768854359438",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 8E 0D 27 D8 26 C6 9A 08",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 6.9092202186584,
                                [2] = -2.847179889679,
                                [3] = -16.367599487305,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetinybooster",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "BOOSTER EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [21] [15]

                -------------------- ENTRY [21] [16] --------------------
                [16] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "7282993955614014635",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 AB BC B0 69 6A 64 12 65",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 2.4723300933838,
                                [2] = -2.4943699836731,
                                [3] = -20.941499710083,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetiny",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "ENGINE EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [21] [16]

                -------------------- ENTRY [21] [17] --------------------
                [17] = {
                    ["name"] = "EngineFull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-6982183086609940824",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 A8 BE DF D5 79 4D 1A 9F",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 6.9092202186584,
                                [2] = -2.847179889679,
                                [3] = -16.367599487305,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [17]

                -------------------- ENTRY [21] [18] --------------------
                [18] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "-2767468558536060007",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 99 53 65 39 02 FA 97 D9",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 8.4499101638794,
                                [2] = 3.9853100776672,
                                [3] = -19.02140045166,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.85000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.85000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.85000002384186,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [18]

                -------------------- ENTRY [21] [19] --------------------
                [19] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "975764603023507223",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 17 BF 9D 93 BC 9C 8A 0D",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 5.9422202110291,
                                [2] = 4.5139198303223,
                                [3] = -17.962400436401,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetiny",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "ENGINE EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [21] [19]

                -------------------- ENTRY [21] [20] --------------------
                [20] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "2111558383699741602",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A A2 CB EB 96 29 C3 4D 1D",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 9.0275096893311,
                                [2] = 1.6599099636078,
                                [3] = -18.90419960022,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.25,
                        },
                        [3] = {
                            ["$121"] = 0.25,
                        },
                        [4] = {
                            ["$122"] = 0.25,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [20]

                -------------------- ENTRY [21] [21] --------------------
                [21] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "1056574481290877283",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 63 D9 15 8C E4 B4 A9 0E",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 8.4499101638794,
                                [2] = 3.9853100776672,
                                [3] = -19.02140045166,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetinybooster",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "BOOSTER EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [21] [21]

                -------------------- ENTRY [21] [22] --------------------
                [22] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "-2505601257764521232",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 F0 7A 2C 6A EE 50 3A DD",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 6.9092202186584,
                                [2] = -2.847179889679,
                                [3] = -16.367599487305,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetiny",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "ENGINE EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [21] [22]

                -------------------- ENTRY [21] [23] --------------------
                [23] = {
                    ["name"] = "EngineFull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "4552157035620126786",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 42 D0 EE 9D B4 82 2C 3F",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 8.4499101638794,
                                [2] = 3.9853100776672,
                                [3] = -19.02140045166,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.85000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.85000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.85000002384186,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [23]

                -------------------- ENTRY [21] [24] --------------------
                [24] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "7374440246091310435",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 63 E5 9D 15 55 46 57 66",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 6.302020072937,
                                [2] = 1.5030299425125,
                                [3] = -21.778999328613,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [24]

                -------------------- ENTRY [21] [25] --------------------
                [25] = {
                    ["name"] = "EngineFull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "5931371024123979635",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 73 67 F4 4B 85 76 50 52",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 4.6633200645447,
                                [2] = -4.2939801216125,
                                [3] = -14.799900054932,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [25]

                -------------------- ENTRY [21] [26] --------------------
                [26] = {
                    ["name"] = "EngineFull",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-99913395335155935",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 21 AF BE DA 4B 09 9D FE",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 5.9422202110291,
                                [2] = 4.5139198303223,
                                [3] = -17.962400436401,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.69999998807907,
                        },
                        [3] = {
                            ["$121"] = 0.69999998807907,
                        },
                        [4] = {
                            ["$122"] = 0.69999998807907,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [26]

                -------------------- ENTRY [21] [27] --------------------
                [27] = {
                    ["name"] = "EngineSmall",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "5978201900728719582",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 DE 18 80 70 F4 D6 F6 52",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 9.0275096893311,
                                [2] = 1.6599099636078,
                                [3] = -18.90419960022,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.25,
                        },
                        [3] = {
                            ["$121"] = 0.25,
                        },
                        [4] = {
                            ["$122"] = 0.25,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                        [7] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [27]

                -------------------- ENTRY [21] [28] --------------------
                [28] = {
                    ["name"] = "engine1_clone_clone_clone",
                    ["identifier_type"] = "1247812863",  -- do not change
                    ["identifier"] = "-8493231342797432197",  -- do not change
                    ["identifier_hex"] = "FF 1C 60 4A 7B 5A 58 C1 17 FB 21 8A",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 6.9092202186584,
                                [2] = -2.847179889679,
                                [3] = -16.367599487305,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.60000002384186,
                        },
                        [3] = {
                            ["$121"] = 0.60000002384186,
                        },
                        [4] = {
                            ["$122"] = 0.60000002384186,
                        },
                        [5] = {
                            ["$250000979"] = 1,
                        },
                        [6] = {
                            ["MDL_TYPE"] = 654,
                        },
                        [7] = {
                            ["MDL_1"] = "MEDIA/SHIPS/ENGINES/BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [28]

                -------------------- ENTRY [21] [29] --------------------
                [29] = {
                    ["name"] = "EngineSmall",
                    ["identifier_type"] = "6343081",  -- do not change
                    ["identifier"] = "-5159621842224425187",  -- do not change
                    ["identifier_hex"] = "A9 C9 60 00 1D D7 DD 76 45 57 65 B8",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 9.9739103317261,
                                [2] = 2.2805099487305,
                                [3] = -18.752000808716,
                            },
                        },
                        [2] = {
                            ["$120"] = 0.25,
                        },
                        [3] = {
                            ["$121"] = 0.25,
                        },
                        [4] = {
                            ["$122"] = 0.25,
                        },
                        [5] = {
                            ["TYPE_STRING"] = "ENGINEMESH",
                        },
                        [6] = {
                            ["HARDPOINT_NUMBER_2"] = 1,
                        },
                        [7] = {
                            ["DAT_OR_MDL"] = "MEDIA\\SHIPS\\ENGINES\\BLUE_FIGHTER_3.MDL",
                        },
                    },   -- end properties
                },  -- end entry [21] [29]

                -------------------- ENTRY [21] [30] --------------------
                [30] = {
                    ["name"] = "Engine_clone_clone_clone_clone_clone_clone_clone",
                    ["identifier_type"] = "3379918034",  -- do not change
                    ["identifier"] = "-4531550716513926588",  -- do not change
                    ["identifier_hex"] = "D2 74 75 C9 44 42 85 EC A1 B2 1C C1",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 2.4723300933838,
                                [2] = -2.4943699836731,
                                [3] = -20.941499710083,
                            },
                        },
                        [2] = {
                            ["FX_STRING"] = "paleblueenginetinybooster",
                        },
                        [3] = {
                            ["TYPE_STRING"] = "BOOSTER EXHAUST",
                        },
                    },   -- end properties
                },  -- end entry [21] [30]
            },   -- end entries for [21]
        },  -- end entry [21]
    }, -- end main entries


    -- -----------------------------------------------------------
    -- Additonal data that is added to the end of the .layout file
    -- Currently it's unknown what it does, so don't change it
    ["additional_data"] = "FF FF FF FF FF FF FF FF 00 00 00 00 00 00 07 00 00 00 FF FF FF FF 00 00 00 00 00 00 00 00 00 00 07 00 C1 FD 5B 47 96 7A 67 E9 00 01 00 00 00 01 04 04 00 00 FF FF FF FF 00 00 00 00 00 00 00 00 00 00 00 00 B1 79 D1 71 CD 61 D0 1A 00 01 00 00 00 01 54 06 00 00 FF FF FF FF 00 00 00 00 00 00 00 00 00 00 00 00 74 DB 05 70 DA 22 D3 BD 00 01 00 00 00 01 AE 18 00 00 FF FF FF FF 00 00 00 00 00 00 00 00 00 00 00 00 F1 7C B1 F8 4E 34 C3 FE 00 01 00 00 00 01 61 1D 00 00 FF FF FF FF 00 00 00 00 00 00 00 00 00 00 00 00 9E 1A D5 E9 7A EA 01 B5 00 01 00 00 00 01 AB 21 00 00 FF FF FF FF 00 00 00 00 00 00 00 00 00 00 00 00 68 61 B6 50 76 2D E5 02 00 01 00 00 00 01 20 30 00 00 FF FF FF FF 00 00 00 00 00 00 00 00 00 00 00 00 12 CE A2 15 95 6B 8F 23 00 01 00 00 00 01 39 30 00 00 FF FF FF FF 00 00 00 00 00 00 00 00 00 00 00 00"
}

return LAYOUT