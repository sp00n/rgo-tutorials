local LAYOUT = {
    ["entries"] = {

        -------------------- ENTRY [1] --------------------
        [1] = {
            ["name"] = "CINECAM",
            ["identifier_type"] = "6343081",  -- do not change
            ["identifier"] = "-4762196946245041567",  -- do not change
            ["identifier_hex"] = "A9 C9 60 00 61 42 9D CC 1B 47 E9 BD",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 0,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.72058999538422,
                        [2] = 7.67354100942612,
                        [3] = 8.1996803283691,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.09081169962883,
                        [2] = 0.58786100149155,
                        [3] = -0.066640801727772,
                        [4] = 0.80108100175858,
                    },
                },
                [4] = {
                    ["TYPE_STRING"] = "CAMERA POSITION",
                },
                [5] = {
                    ["HARDPOINT_NUMBER_1"] = 1,
                },
            },   -- end properties
        },  -- end entry [1]

        -------------------- ENTRY [2] --------------------
        [2] = {
            ["name"] = "CINE_JUNO",
            ["identifier_type"] = "235985428",  -- do not change
            ["identifier"] = "2515801222360202875",  -- do not change
            ["identifier_hex"] = "14 DA 10 0E 7B FE 45 E8 E1 EB E9 22",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.0,
                        [2] = 6.53169998526573,
                        [3] = 8.2524003982544,
                    },
                },
                [2] = {
                    ["SEQUENCE_1"] = "bind",
                },
                [3] = {
                    ["BODY_STANCE"] = "COCKPIT_NEUTRAL",
                },
                [4] = {
                    ["$238082482"] = 1,
                },
                [5] = {
                    ["$2378094963"] = 3,
                },
                [6] = {
                    ["MDL_TYPE"] = 69317,
                },
                [7] = {
                    ["MDL_1"] = "MEDIA/CHARACTERS/JUNO/JUNO_CINEMATIC.MDL",
                },
                [8] = {
                    ["$2327760332"] = 1.4012984643248e-045,
                },
                [9] = {
                    ["$1267027621"] = 4.0,
                },
                [10] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [2]

        -------------------- ENTRY [3] --------------------
        [3] = {
            ["name"] = "flair",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-9192571435259049908",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A 4C 48 FB E4 FB 6C 6D 80",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.6496000289917,
                        [2] = 7.33120000362396,
                        [3] = 8.6826000213623,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.19344800710678,
                        [2] = -0.43511599302292,
                        [3] = 0.079753801226616,
                        [4] = 0.87572300434113,
                    },
                },
                [4] = {
                    ["$120"] = 0.60000002384186,
                },
                [5] = {
                    ["$121"] = 0.60000002384186,
                },
                [6] = {
                    ["$122"] = 0.60000002384186,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999001,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 130,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/SHIPS/COCKPIT_SET_1/FLAIR_BURT.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [3]

        -------------------- ENTRY [4] --------------------
        [4] = {
            ["name"] = "JunoFill1",
            ["identifier_type"] = "49615221",  -- do not change
            ["identifier"] = "-9217159960179852552",  -- do not change
            ["identifier_hex"] = "75 11 F5 02 F8 BA 86 CF D9 11 16 80",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.25490000844002,
                        [2] = 7.85740000009537,
                        [3] = 7.770800113678,
                    },
                },
                [2] = {
                    ["$540225266"] = 0.30000001192093,
                },
                [3] = {
                    ["RGBA_COLOR_VALUE_1"] = "FFFBF2CF",
                },
                [4] = {
                    ["$2395588028"] = 1.6000000238419,
                },
            },   -- end properties
        },  -- end entry [4]

        -------------------- ENTRY [5] --------------------
        [5] = {
            ["name"] = "InteriorSpot",
            ["identifier_type"] = "785719791",  -- do not change
            ["identifier"] = "-270692783157432178",  -- do not change
            ["identifier_hex"] = "EF 21 D5 2E 8E B0 A3 10 59 4E 3E FC",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.03999999910593,
                        [2] = 9.3199999332428,
                        [3] = 8.5923004150391,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.83867102861404,
                        [2] = 0.0,
                        [3] = 0.0,
                        [4] = 0.5446389913559,
                    },
                },
                [3] = {
                    ["$238425541"] = 60.0,
                },
                [4] = {
                    ["$1050384889"] = 5.0,
                },
                [5] = {
                    ["$2395588028"] = 1.2000000476837,
                },
            },   -- end properties
        },  -- end entry [5]

        -------------------- ENTRY [6] --------------------
        [6] = {
            ["name"] = "GLASS_PARTICLES",
            ["identifier_type"] = "6343081",  -- do not change
            ["identifier"] = "188821678862302170",  -- do not change
            ["identifier_hex"] = "A9 C9 60 00 DA FB 7A 06 51 D4 9E 02",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 0,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.3260999917984,
                        [2] = 8.2978899478912,
                        [3] = 8.8980798721313,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.0,
                        [2] = 0.99983298778534,
                        [3] = -0.01828289963305,
                        [4] = -0.0,
                    },
                },
            },   -- end properties
        },  -- end entry [6]

        -------------------- ENTRY [7] --------------------
        [7] = {
            ["name"] = "",
            ["identifier_type"] = "41091149",  -- do not change
            ["identifier"] = "5376399512111896019",  -- do not change
            ["identifier_hex"] = "4D 00 73 02 D3 55 03 F2 DE CE 9C 4A",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = -0.35499998927116,
                        [2] = 7.15500000119209,
                        [3] = 8.703200340271,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.45901599526405,
                        [2] = -0.067469201982021,
                        [3] = 0.36768499016762,
                        [4] = -0.80595302581787,
                    },
                },
                [3] = {
                    ["$120"] = 0.30000001192093,
                },
                [4] = {
                    ["$121"] = 0.25,
                },
                [5] = {
                    ["$122"] = 0.30000001192093,
                },
                [6] = {
                    ["DDS_1"] = "media/textures/damage/shipdamage2_d.dds",
                },
                [7] = {
                    ["DDS_2"] = "media/textures/damage/shipdamage2_n.dds",
                },
                [8] = {
                    ["DDS_5"] = "media/textures/damage/shipdamage2_i.dds",
                },
                [9] = {
                    ["$58406023"] = 180.0,
                },
                [10] = {
                    ["$752445854"] = 3,
                },
                [11] = {
                    ["HARDPOINT_NUMBER_1"] = 1,
                },
                [12] = {
                    ["HARDPOINT_NUMBER_2"] = 48,
                },
            },   -- end properties
        },  -- end entry [7]

        -------------------- ENTRY [8] --------------------
        [8] = {
            ["name"] = "flair_hulaboy",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-1571095109506789914",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A E6 8D 7E 69 52 59 32 EA",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.66619998216629,
                        [2] = 7.73070001602173,
                        [3] = 8.851900100708,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = -0.029465200379491,
                        [2] = 0.94569998979568,
                        [3] = 0.089580997824669,
                        [4] = -0.31106200814247,
                    },
                },
                [4] = {
                    ["$120"] = 0.5,
                },
                [5] = {
                    ["$121"] = 0.5,
                },
                [6] = {
                    ["$122"] = 0.5,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999005,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 17760,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/OBJECTS/DASHFLAIR/HULABOY.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [8]

        -------------------- ENTRY [9] --------------------
        [9] = {
            ["name"] = "flair_steed",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-2142899245407736898",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A BE EB 04 68 7D E4 42 E2",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.65570002794266,
                        [2] = 7.73070001602173,
                        [3] = 8.8510999679565,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.029841100797057,
                        [2] = 0.94438499212265,
                        [3] = 0.089456498622894,
                        [4] = 0.31503000855446,
                    },
                },
                [4] = {
                    ["$120"] = 0.40000000596046,
                },
                [5] = {
                    ["$121"] = 0.40000000596046,
                },
                [6] = {
                    ["$122"] = 0.40000000596046,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999002,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 10568,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/OBJECTS/DASHFLAIR/BUCKSHOT.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [9]

        -------------------- ENTRY [10] --------------------
        [10] = {
            ["name"] = "cockpitfixed",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "2324909783609657968",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A 70 4A E2 5A 21 BD 43 20",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["$250000979"] = 1,
                },
                [3] = {
                    ["MDL_TYPE"] = 41248,
                },
                [4] = {
                    ["MDL_1"] = "MEDIA/SHIPS/COCKPIT_SET_1/COCKPIT_MEDIUMFIGHTERB_LOW.MDL",
                },
                [5] = {
                    ["$249687282"] = 10,
                },
				-- new, moves the cockpit graphics
                [6] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0,
                        [2] = 7,
                        [3] = 0,
                    },
                },
            },   -- end properties
        },  -- end entry [10]

        -------------------- ENTRY [11] --------------------
        [11] = {
            ["name"] = "GLASS_PARTICLES",
            ["identifier_type"] = "6343081",  -- do not change
            ["identifier"] = "5196740032689860533",  -- do not change
            ["identifier_hex"] = "A9 C9 60 00 B5 EF 87 B6 86 87 1E 48",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 0,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = -0.24920000135899,
                        [2] = 8.1773899793625,
                        [3] = 8.7319803237915,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.0,
                        [2] = 0.99983298778534,
                        [3] = -0.01828289963305,
                        [4] = -0.0,
                    },
                },
            },   -- end properties
        },  -- end entry [11]

        -------------------- ENTRY [12] --------------------
        [12] = {
            ["name"] = "flair_forged",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-6696004624287092293",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A BB B1 FE 6A 45 03 13 A3",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.66939997673035,
                        [2] = 7.73070001602173,
                        [3] = 8.8569002151489,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = -0.029465200379491,
                        [2] = 0.94569998979568,
                        [3] = 0.089580997824669,
                        [4] = -0.31106200814247,
                    },
                },
                [4] = {
                    ["$120"] = 0.5,
                },
                [5] = {
                    ["$121"] = 0.5,
                },
                [6] = {
                    ["$122"] = 0.5,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999004,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 11268,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/OBJECTS/DASHFLAIR/FORGED.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [12]

        -------------------- ENTRY [13] --------------------
        [13] = {
            ["name"] = "postcard1",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-2286868623082387270",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A BA 08 30 89 1A 69 43 E0",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.62680000066757,
                        [2] = 7.4108000099659,
                        [3] = 8.7089004516602,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.037792101502419,
                        [2] = -0.94464099407196,
                        [3] = -0.09389790147543,
                        [4] = 0.31210398674011,
                    },
                },
                [4] = {
                    ["$120"] = 2.5,
                },
                [5] = {
                    ["$121"] = 2.5,
                },
                [6] = {
                    ["$122"] = 2.5,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999101,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 14,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/OBJECTS/DASHFLAIR/POSTCARD_BELGRADE.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [13]

        -------------------- ENTRY [14] --------------------
        [14] = {
            ["name"] = "JunoFill1",
            ["identifier_type"] = "49615221",  -- do not change
            ["identifier"] = "2499991502761568423",  -- do not change
            ["identifier_hex"] = "75 11 F5 02 A7 28 99 B7 06 C1 B1 22",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = -0.32980000972748,
                        [2] = 8.0235999822617,
                        [3] = 7.5910000801086,
                    },
                },
                [2] = {
                    ["$540225266"] = 0.80000001192093,
                },
                [3] = {
                    ["RGBA_COLOR_VALUE_1"] = "FFA8DBFF",
                },
                [4] = {
                    ["$2395588028"] = 1.7999999523163,
                },
            },   -- end properties
        },  -- end entry [14]

        -------------------- ENTRY [15] --------------------
        [15] = {
            ["name"] = "postcard6",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "8110903519237950655",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A BF CC A4 FF C6 B7 8F 70",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.62680000066757,
                        [2] = 7.4108000099659,
                        [3] = 8.7089004516602,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.037792101502419,
                        [2] = -0.94464099407196,
                        [3] = -0.09389790147543,
                        [4] = 0.31210398674011,
                    },
                },
                [4] = {
                    ["$120"] = 2.5,
                },
                [5] = {
                    ["$121"] = 2.5,
                },
                [6] = {
                    ["$122"] = 2.5,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999106,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 14,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/OBJECTS/DASHFLAIR/POSTCARD_FLAGSTAFF.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [15]

        -------------------- ENTRY [16] --------------------
        [16] = {
            ["name"] = "",
            ["identifier_type"] = "6343081",  -- do not change
            ["identifier"] = "-4452173507106181477",  -- do not change
            ["identifier_hex"] = "A9 C9 60 00 9B EE 87 AE C8 B3 36 C2",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 0,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.0,
                        [2] = 7.94999998807907,
                        [3] = 6.75,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.0,
                        [2] = 1.0,
                        [3] = -0.0,
                        [4] = -8.7422797889758e-008,
                    },
                },
                [4] = {
                    ["TYPE_STRING"] = "COCKPIT CAMERA",
                },
            },   -- end properties
        },  -- end entry [16]

        -------------------- ENTRY [17] --------------------
        [17] = {
            ["name"] = "cockpitfixed",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-5580387237615540947",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A 2D 65 CD A0 5F 7B 8E B2",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["$250000979"] = 1,
                },
                [3] = {
                    ["MDL_TYPE"] = 264,
                },
                [4] = {
                    ["MDL_1"] = "MEDIA/SHIPS/COCKPIT_SET_1/COCKPIT_MEDIUMFIGHTERB_MFDOVERLAY.MDL",
                },
                [5] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [17]

        -------------------- ENTRY [18] --------------------
        [18] = {
            ["name"] = "",
            ["identifier_type"] = "785719791",  -- do not change
            ["identifier"] = "-8970751857228383815",  -- do not change
            ["identifier_hex"] = "EF 21 D5 2E B9 F9 B9 05 B7 7C 81 83",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 6.4400000572205,
                        [2] = 10.9700000286102,
                        [3] = 0.34999999403954,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.0,
                        [2] = -0.086093299090862,
                        [3] = 0.0,
                        [4] = -0.99628698825836,
                    },
                },
                [3] = {
                    ["$477501129"] = 125.0,
                },
                [4] = {
                    ["$238425541"] = 30.0,
                },
                [5] = {
                    ["$1050384889"] = 20.0,
                },
                [6] = {
                    ["RGBA_COLOR_VALUE_1"] = "FFC9EDFF",
                },
                [7] = {
                    ["$2395588028"] = 2.0,
                },
                [8] = {
                    ["$3640551892"] = 0.5,
                },
            },   -- end properties
        },  -- end entry [18]

        -------------------- ENTRY [19] --------------------
        [19] = {
            ["name"] = "",
            ["identifier_type"] = "41091149",  -- do not change
            ["identifier"] = "-7689532815390121143",  -- do not change
            ["identifier_hex"] = "4D 00 73 02 49 63 F6 31 A5 4A 49 95",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.10199999809265,
                        [2] = 7.15399999916553,
                        [3] = 8.6275997161865,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.478619992733,
                        [2] = 0.59948402643204,
                        [3] = -0.43560999631882,
                        [4] = -0.47094199061394,
                    },
                },
                [3] = {
                    ["$120"] = 0.5,
                },
                [4] = {
                    ["$121"] = 0.25,
                },
                [5] = {
                    ["$122"] = 0.5,
                },
                [6] = {
                    ["DDS_1"] = "media/textures/damage/shipdamage1_d.dds",
                },
                [7] = {
                    ["DDS_2"] = "media/textures/damage/shipdamage1_n.dds",
                },
                [8] = {
                    ["DDS_5"] = "media/textures/damage/shipdamage1_i.dds",
                },
                [9] = {
                    ["$58406023"] = 180.0,
                },
                [10] = {
                    ["$752445854"] = 3,
                },
                [11] = {
                    ["HARDPOINT_NUMBER_1"] = 1,
                },
                [12] = {
                    ["HARDPOINT_NUMBER_2"] = 25,
                },
            },   -- end properties
        },  -- end entry [19]

        -------------------- ENTRY [20] --------------------
        [20] = {
            ["name"] = "GlassDistortion",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "5837813504364057921",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A 41 15 99 C0 73 14 04 51",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.0,
                        [2] = 7.29440000653267,
                        [3] = -0.033399999141693,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.017452400177717,
                        [2] = 0.0,
                        [3] = 0.0,
                        [4] = 0.99984800815582,
                    },
                },
                [4] = {
                    ["$250000979"] = 1,
                },
                [5] = {
                    ["MDL_TYPE"] = 632,
                },
                [6] = {
                    ["MDL_1"] = "MEDIA/SHIPS/COCKPIT_SET_1/COCKPIT_MEDIUMFIGHTER_DISTORTION.MDL",
                },
                [7] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [20]

        -------------------- ENTRY [21] --------------------
        [21] = {
            ["name"] = "GLASS_PARTICLES",
            ["identifier_type"] = "6343081",  -- do not change
            ["identifier"] = "7321331103554375831",  -- do not change
            ["identifier_hex"] = "A9 C9 60 00 97 90 60 3E D9 97 9A 65",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 0,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.47540000081062,
                        [2] = 7.96588999032974,
                        [3] = 8.8985795974731,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.0,
                        [2] = 0.99983298778534,
                        [3] = -0.01828289963305,
                        [4] = -0.0,
                    },
                },
            },   -- end properties
        },  -- end entry [21]

        -------------------- ENTRY [22] --------------------
        [22] = {
            ["name"] = "postcard7",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-215746376771349546",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A D6 53 F7 3A D0 83 01 FD",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.62680000066757,
                        [2] = 7.4108000099659,
                        [3] = 8.7089004516602,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.037792101502419,
                        [2] = -0.94464099407196,
                        [3] = -0.09389790147543,
                        [4] = 0.31210398674011,
                    },
                },
                [4] = {
                    ["$120"] = 2.5,
                },
                [5] = {
                    ["$121"] = 2.5,
                },
                [6] = {
                    ["$122"] = 2.5,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999107,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 14,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/OBJECTS/DASHFLAIR/POSTCARD_DENVER.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [22]

        -------------------- ENTRY [23] --------------------
        [23] = {
            ["name"] = "flair_dusk",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "484503341869762016",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A E0 05 A3 F0 38 4D B9 06",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.66619998216629,
                        [2] = 7.73070001602173,
                        [3] = 8.851900100708,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = -0.029465200379491,
                        [2] = 0.94569998979568,
                        [3] = 0.089580997824669,
                        [4] = -0.31106200814247,
                    },
                },
                [4] = {
                    ["$120"] = 0.5,
                },
                [5] = {
                    ["$121"] = 0.5,
                },
                [6] = {
                    ["$122"] = 0.5,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999007,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 6628,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/OBJECTS/DASHFLAIR/DUSKGUY.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [23]

        -------------------- ENTRY [24] --------------------
        [24] = {
            ["name"] = "CrackedGlassDistortion",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-3646611298280321288",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A F8 4E 13 44 58 A2 64 CD",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.0,
                        [2] = 7.29440000653267,
                        [3] = -0.033399999141693,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.017452400177717,
                        [2] = 0.0,
                        [3] = 0.0,
                        [4] = 0.99984800815582,
                    },
                },
                [4] = {
                    ["HARDPOINT_NUMBER_1"] = 3,
                },
                [5] = {
                    ["HARDPOINT_NUMBER_2"] = 75,
                },
                [6] = {
                    ["$250000979"] = 1,
                },
                [7] = {
                    ["MDL_TYPE"] = 482,
                },
                [8] = {
                    ["MDL_1"] = "MEDIA/SHIPS/COCKPIT_SET_1/COCKPIT_MEDIUMFIGHTER_CRACKEDGLASS_DISTORTION.MDL",
                },
                [9] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [24]

        -------------------- ENTRY [25] --------------------
        [25] = {
            ["name"] = "postcard3",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "7217104938204614605",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A CD 4F 67 14 B4 4E 28 64",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.62680000066757,
                        [2] = 7.4108000099659,
                        [3] = 8.7089004516602,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.037792101502419,
                        [2] = -0.94464099407196,
                        [3] = -0.09389790147543,
                        [4] = 0.31210398674011,
                    },
                },
                [4] = {
                    ["$120"] = 2.5,
                },
                [5] = {
                    ["$121"] = 2.5,
                },
                [6] = {
                    ["$122"] = 2.5,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999103,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 14,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/OBJECTS/DASHFLAIR/POSTCARD_OZARK.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [25]

        -------------------- ENTRY [26] --------------------
        [26] = {
            ["name"] = "postcard2",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "5262335809309796218",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A 7A 67 BA 9A 89 92 07 49",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.62680000066757,
                        [2] = 7.4108000099659,
                        [3] = 8.7089004516602,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.037792101502419,
                        [2] = -0.94464099407196,
                        [3] = -0.09389790147543,
                        [4] = 0.31210398674011,
                    },
                },
                [4] = {
                    ["$120"] = 2.5,
                },
                [5] = {
                    ["$121"] = 2.5,
                },
                [6] = {
                    ["$122"] = 2.5,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999102,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 14,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/OBJECTS/DASHFLAIR/POSTCARD_BACKFIRE.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [26]

        -------------------- ENTRY [27] --------------------
        [27] = {
            ["name"] = "CrackedGlass",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "7956358621653180068",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A A4 1E 41 05 03 AA 6A 6E",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.0,
                        [2] = 7.29440000653267,
                        [3] = -0.033399999141693,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.017452400177717,
                        [2] = 0.0,
                        [3] = 0.0,
                        [4] = 0.99984800815582,
                    },
                },
                [4] = {
                    ["HARDPOINT_NUMBER_1"] = 2,
                },
                [5] = {
                    ["HARDPOINT_NUMBER_2"] = 75,
                },
                [6] = {
                    ["$250000979"] = 1,
                },
                [7] = {
                    ["MDL_TYPE"] = 482,
                },
                [8] = {
                    ["MDL_1"] = "MEDIA/SHIPS/COCKPIT_SET_1/COCKPIT_MEDIUMFIGHTER_CRACKEDGLASS.MDL",
                },
                [9] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [27]

        -------------------- ENTRY [28] --------------------
        [28] = {
            ["name"] = "",
            ["identifier_type"] = "4198111779",  -- do not change
            ["identifier"] = "-4259232005747388685",  -- do not change
            ["identifier_hex"] = "23 1A 3A FA F3 CE 73 A1 0E 2B E4 C4",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.51794499158859,
                        [2] = 8.3774700164795,
                        [3] = 9.1020002365112,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = -0.040327601134777,
                        [2] = 0.95954900979996,
                        [3] = -0.18901200592518,
                        [4] = -0.20472900569439,
                    },
                },
                [3] = {
                    ["RGBA_COLOR_VALUE_1"] = "FFFFF2D1",
                },
                [4] = {
                    ["RGBA_COLOR_VALUE_2"] = "FF140036",
                },
                [5] = {
                    ["$2395588028"] = 1.0,
                },
                [6] = {
                    ["$3893202746"] = 0.40000000596046,
                },
                [7] = {
                    ["$3669148396"] = 0.050000000745058,
                },
                [8] = {
                    ["$871132703"] = 2.0,
                },
                [9] = {
                    ["$3213889982"] = 3.0,
                },
                [10] = {
                    ["$3723540474"] = 10.0,
                },
                [11] = {
                    ["$1919643935"] = 0.30000001192093,
                },
                [12] = {
                    ["$2198895280"] = 0.15000000596046,
                },
                [13] = {
                    ["$3852786932"] = 10.0,
                },
                [14] = {
                    ["CASCADE_OR_SPOTLIGHT"] = "CASCADE",
                },
                [15] = {
                    ["$2795048891"] = 100.0,
                },
                [16] = {
                    ["$1484221856"] = 0.15000000596046,
                },
                [17] = {
                    ["$3104706929"] = 100.0,
                },
                [18] = {
                    ["$1048752776"] = 0.25,
                },
                [19] = {
                    ["$82767127"] = 30.0,
                },
                [20] = {
                    ["$1732583820"] = 2.0,
                },
                [21] = {
                    ["$2239913900"] = 0.019999999552965,
                },
                [22] = {
                    ["$117487961"] = 5000.0,
                },
                [23] = {
                    ["$2608642991"] = 110.0,
                },
                [24] = {
                    ["$2801365900"] = 0.0020000000949949,
                },
                [25] = {
                    ["DDS_3"] = "media/sharedtextures/pbr_bar_top_dark.dds",
                },
                [26] = {
                    ["DDS_4"] = "media/sharedtextures/pbr_interior_specular.dds",
                },
            },   -- end properties
        },  -- end entry [28]

        -------------------- ENTRY [29] --------------------
        [29] = {
            ["name"] = "postcard4",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-5678650162511049789",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A C3 8B D0 93 C3 61 31 B1",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.62680000066757,
                        [2] = 7.4108000099659,
                        [3] = 8.7089004516602,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.037792101502419,
                        [2] = -0.94464099407196,
                        [3] = -0.09389790147543,
                        [4] = 0.31210398674011,
                    },
                },
                [4] = {
                    ["$120"] = 2.5,
                },
                [5] = {
                    ["$121"] = 2.5,
                },
                [6] = {
                    ["$122"] = 2.5,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999104,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 14,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/OBJECTS/DASHFLAIR/POSTCARD_JOPLIN.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [29]

        -------------------- ENTRY [30] --------------------
        [30] = {
            ["name"] = "GAME_PILOT",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "8483996583321730031",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A EF FB 84 40 F1 35 BD 75",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.0,
                        [2] = 6.66999998688698,
                        [3] = 7.6956000328064,
                    },
                },
                [3] = {
                    ["$250000979"] = 1,
                },
                [4] = {
                    ["SEQUENCE_1"] = "aok_cockpit_firstperson1",
                },
                [5] = {
                    ["MDL_TYPE"] = 16061,
                },
                [6] = {
                    ["MDL_1"] = "MEDIA/CHARACTERS/JUNO/COCKPITBODY.MDL",
                },
                [7] = {
                    ["$2327760332"] = 1.4012984643248e-045,
                },
                [8] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [30]

        -------------------- ENTRY [31] --------------------
        [31] = {
            ["name"] = "",
            ["identifier_type"] = "785719791",  -- do not change
            ["identifier"] = "-8151351942144912366",  -- do not change
            ["identifier_hex"] = "EF 21 D5 2E 12 14 43 A9 98 94 E0 8E",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = -6.4299998283386,
                        [2] = 10.9700000286102,
                        [3] = 0.99000000953674,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.0,
                        [2] = 0.056819401681423,
                        [3] = 0.0,
                        [4] = -0.99838399887085,
                    },
                },
                [3] = {
                    ["$477501129"] = 125.0,
                },
                [4] = {
                    ["$238425541"] = 30.0,
                },
                [5] = {
                    ["$1050384889"] = 20.0,
                },
                [6] = {
                    ["RGBA_COLOR_VALUE_1"] = "FFC9EDFF",
                },
                [7] = {
                    ["$2395588028"] = 2.0,
                },
                [8] = {
                    ["$3640551892"] = 0.5,
                },
            },   -- end properties
        },  -- end entry [31]

        -------------------- ENTRY [32] --------------------
        [32] = {
            ["name"] = "flair_astroneer",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "6201685501530289152",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A 00 34 67 0F 1B D0 10 56",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.66619998216629,
                        [2] = 7.73070001602173,
                        [3] = 8.851900100708,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = -0.029465200379491,
                        [2] = 0.94569998979568,
                        [3] = 0.089580997824669,
                        [4] = -0.31106200814247,
                    },
                },
                [4] = {
                    ["$120"] = 0.5,
                },
                [5] = {
                    ["$121"] = 0.5,
                },
                [6] = {
                    ["$122"] = 0.5,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999006,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 14911,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/OBJECTS/DASHFLAIR/ASTRONEER.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [32]

        -------------------- ENTRY [33] --------------------
        [33] = {
            ["name"] = "MFDCAM",
            ["identifier_type"] = "6343081",  -- do not change
            ["identifier"] = "1142638766848853574",  -- do not change
            ["identifier_hex"] = "A9 C9 60 00 46 C6 9D 8C E7 77 DB 0F",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 0,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.23337200284004,
                        [2] = 7.70478397607803,
                        [3] = 8.1923904418945,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.0064519899897277,
                        [2] = 0.97805297374725,
                        [3] = 0.20599199831486,
                        [4] = -0.030634200200438,
                    },
                },
                [4] = {
                    ["TYPE_STRING"] = "CAMERA POSITION",
                },
                [5] = {
                    ["$37302"] = 45.0,
                },
                [6] = {
                    ["$871132703"] = 0.60000002384186,
                },
                [7] = {
                    ["$3213889982"] = 0.050000000745058,
                },
                [8] = {
                    ["$3723540474"] = 24.0,
                },
                [9] = {
                    ["$3852786932"] = 0.0,
                },
                [10] = {
                    ["HARDPOINT_NUMBER_1"] = 3,
                },
            },   -- end properties
        },  -- end entry [33]

        -------------------- ENTRY [34] --------------------
        [34] = {
            ["name"] = "",
            ["identifier_type"] = "4270653419",  -- do not change
            ["identifier"] = "-3386690846714614155",  -- do not change
            ["identifier_hex"] = "EB FF 8C FE 75 2E 82 4D 9E 0E 00 D1",
        },  -- end entry [34]

        -------------------- ENTRY [35] --------------------
        [35] = {
            ["name"] = "",
            ["identifier_type"] = "3570725029",  -- do not change
            ["identifier"] = "4287592443634406803",  -- do not change
            ["identifier_hex"] = "A5 F0 D4 D4 93 55 7A 60 9C 96 80 3B",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = -1.1845999956131,
                        [2] = 6.39579999446869,
                        [3] = 7.3475999832153,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = -0.024446500465274,
                        [2] = 0.87751799821854,
                        [3] = -0.43401798605919,
                        [4] = 0.2024679929018,
                    },
                },
            },   -- end properties
        },  -- end entry [35]

        -------------------- ENTRY [36] --------------------
        [36] = {
            ["name"] = "TALKCAM",
            ["identifier_type"] = "6343081",  -- do not change
            ["identifier"] = "-8021976458914679724",  -- do not change
            ["identifier_hex"] = "A9 C9 60 00 54 34 D8 B1 E9 36 AC 90",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 0,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.35510298609734,
                        [2] = 7.91328901052475,
                        [3] = 8.1771802902222,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = -0.023185199126601,
                        [2] = 0.30134901404381,
                        [3] = 0.0073298299685121,
                        [4] = 0.95320397615433,
                    },
                },
                [4] = {
                    ["TYPE_STRING"] = "CAMERA POSITION",
                },
                [5] = {
                    ["$37302"] = 30.0,
                },
                [6] = {
                    ["$871132703"] = 0.10000000149012,
                },
                [7] = {
                    ["$3213889982"] = 0.0099999997764826,
                },
                [8] = {
                    ["$3723540474"] = 32.0,
                },
                [9] = {
                    ["$1919643935"] = 0.0,
                },
                [10] = {
                    ["$2198895280"] = 0.0,
                },
                [11] = {
                    ["$3852786932"] = 0.0,
                },
                [12] = {
                    ["HARDPOINT_NUMBER_1"] = 2,
                },
            },   -- end properties
        },  -- end entry [36]

        -------------------- ENTRY [37] --------------------
        [37] = {
            ["name"] = "postcard5",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-9155501468722124125",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A A3 2A 40 10 EC 1F F1 80",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.62680000066757,
                        [2] = 7.4108000099659,
                        [3] = 8.7089004516602,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.037792101502419,
                        [2] = -0.94464099407196,
                        [3] = -0.09389790147543,
                        [4] = 0.31210398674011,
                    },
                },
                [4] = {
                    ["$120"] = 2.5,
                },
                [5] = {
                    ["$121"] = 2.5,
                },
                [6] = {
                    ["$122"] = 2.5,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999105,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 14,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/OBJECTS/DASHFLAIR/POSTCARD_JEFFERSON.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [37]

        -------------------- ENTRY [38] --------------------
        [38] = {
            ["name"] = "",
            ["identifier_type"] = "41091149",  -- do not change
            ["identifier"] = "1707711105483215826",  -- do not change
            ["identifier_hex"] = "4D 00 73 02 D2 13 51 DD 33 02 B3 17",
            ["properties"] = {
                [1] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.47139999270439,
                        [2] = 7.35400000214577,
                        [3] = 8.4682998657227,
                    },
                },
                [2] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.45198100805283,
                        [2] = -0.87274098396301,
                        [3] = -0.093189902603626,
                        [4] = -0.15922600030899,
                    },
                },
                [3] = {
                    ["$120"] = 0.5,
                },
                [4] = {
                    ["$121"] = 0.25,
                },
                [5] = {
                    ["$122"] = 0.5,
                },
                [6] = {
                    ["DDS_1"] = "media/textures/damage/shipdamage2_d.dds",
                },
                [7] = {
                    ["DDS_2"] = "media/textures/damage/shipdamage2_n.dds",
                },
                [8] = {
                    ["DDS_5"] = "media/textures/damage/shipdamage2_i.dds",
                },
                [9] = {
                    ["$58406023"] = 180.0,
                },
                [10] = {
                    ["$752445854"] = 3,
                },
                [11] = {
                    ["HARDPOINT_NUMBER_1"] = 1,
                },
                [12] = {
                    ["HARDPOINT_NUMBER_2"] = 65,
                },
            },   -- end properties
        },  -- end entry [38]

        -------------------- ENTRY [39] --------------------
        [39] = {
            ["name"] = "CINE_COCKPIT_FOAM_CUP",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "6773043389898803433",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A E9 C8 39 F7 13 AF FE 5D",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = -0.066200003027916,
                        [2] = 7.60659998655319,
                        [3] = 7.6175999641418,
                    },
                },
                [3] = {
                    ["$250000979"] = 1,
                },
                [4] = {
                    ["MDL_TYPE"] = 476,
                },
                [5] = {
                    ["MDL_1"] = "MEDIA/SCENES/STATION_INTERIORS_1/PBR_PROPS/DINERSTYROCUP.MDL",
                },
                [6] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [39]

        -------------------- ENTRY [40] --------------------
        [40] = {
            ["name"] = "Lights",
            ["identifier_type"] = "4270653419",  -- do not change
            ["identifier"] = "-4484165178426960465",  -- do not change
            ["identifier_hex"] = "EB FF 8C FE AF 55 AF 41 87 0B C5 C1",
            ["entries"] = {

                -------------------- ENTRY [40] [1] --------------------
                [1] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "8844532721224478453",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 F5 6E E7 4C A6 17 BE 7A",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.8299999833107,
                                [2] = 7.54000002145767,
                                [3] = 8.6000003814697,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.20000000298023,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FFA8FFA3",
                        },
                        [4] = {
                            ["$2395588028"] = 3.0,
                        },
                        [5] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [1]

                -------------------- ENTRY [40] [2] --------------------
                [2] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "-7489941890315795607",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 69 C3 68 BF 88 61 0E 98",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -0.079999998211861,
                                [2] = 8.5599999427795,
                                [3] = 8.4399995803833,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.10000000149012,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FFA8FFA3",
                        },
                        [4] = {
                            ["$2395588028"] = 1.25,
                        },
                        [5] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [2]

                -------------------- ENTRY [40] [3] --------------------
                [3] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "8992733300739332707",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 63 DA 64 9E 4A 9B CC 7C",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.95999997854233,
                                [2] = 7.5799999833107,
                                [3] = 8.4059000015259,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.10000000149012,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FF6BFF33",
                        },
                        [4] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [3]

                -------------------- ENTRY [40] [4] --------------------
                [4] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "-168599354926146799",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 11 5B 44 AC C7 03 A9 FD",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.6700000166893,
                                [2] = 7.6700000166893,
                                [3] = 8.7859001159668,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.10000000149012,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FF6BFF33",
                        },
                        [4] = {
                            ["$2395588028"] = 2.0,
                        },
                        [5] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [4]

                -------------------- ENTRY [40] [5] --------------------
                [5] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "2478616084314827275",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 0B AA 27 48 32 D0 65 22",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -0.43999999761581,
                                [2] = 7.43000000715256,
                                [3] = 8.7399997711182,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.125,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FF6BFF33",
                        },
                        [4] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [5]

                -------------------- ENTRY [40] [6] --------------------
                [6] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "401342499519736294",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 E6 29 24 7D E0 DA 91 05",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.62999999523163,
                                [2] = 7.46000000834465,
                                [3] = 8.460000038147,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.30000001192093,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FFA8FFA3",
                        },
                        [4] = {
                            ["$2395588028"] = 1.5,
                        },
                        [5] = {
                            ["$3640551892"] = 0.0,
                        },
                        [6] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [6]

                -------------------- ENTRY [40] [7] --------------------
                [7] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "-5797902501694530653",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 A3 1B 26 B0 64 B6 89 AF",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.28000000119209,
                                [2] = 7.40000000596046,
                                [3] = 8.7299995422363,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.40000000596046,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FFA8FFA3",
                        },
                        [4] = {
                            ["$2395588028"] = 2.0,
                        },
                        [5] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [7]

                -------------------- ENTRY [40] [8] --------------------
                [8] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "7487948400658758914",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 02 3D B8 C5 65 89 EA 67",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.94999998807907,
                                [2] = 7.43000000715256,
                                [3] = 7.9499998092651,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.15000000596046,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FFA8FFA3",
                        },
                        [4] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [8]

                -------------------- ENTRY [40] [9] --------------------
                [9] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "6538066050220651885",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 6D 75 71 B9 6E E0 BB 5A",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.93999999761581,
                                [2] = 7.70999997854233,
                                [3] = 8.4559001922607,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.10000000149012,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FF6BFF33",
                        },
                        [4] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [9]

                -------------------- ENTRY [40] [10] --------------------
                [10] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "-2890451448233796849",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 0F DB 82 DB B8 0D E3 D7",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -0.17000000178814,
                                [2] = 7.28000000119209,
                                [3] = 8.7700004577637,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.25,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FFA8FFA3",
                        },
                        [4] = {
                            ["$2395588028"] = 3.0,
                        },
                        [5] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [10]

                -------------------- ENTRY [40] [11] --------------------
                [11] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "-3311446269903346516",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 AC 64 9E 8D 29 61 0B D2",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.95999997854233,
                                [2] = 7.49000000953674,
                                [3] = 8.4059000015259,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.10000000149012,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FF6BFF33",
                        },
                        [4] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [11]

                -------------------- ENTRY [40] [12] --------------------
                [12] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "1705504480445168596",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 D4 7B C5 EF 49 2B AB 17",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -0.43999999761581,
                                [2] = 7.33000001311302,
                                [3] = 8.7200002670288,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.125,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FF6BFF33",
                        },
                        [4] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [12]

                -------------------- ENTRY [40] [13] --------------------
                [13] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "7032756516923474418",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 F2 81 09 7F CA 5E 99 61",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.77999997138977,
                                [2] = 7.75999999046326,
                                [3] = 8.6358995437622,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.10000000149012,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FF6BFF33",
                        },
                        [4] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [13]

                -------------------- ENTRY [40] [14] --------------------
                [14] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "-6372551898560740862",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 02 C2 8B BD CF 25 90 A7",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -0.33000001311302,
                                [2] = 7.60000002384186,
                                [3] = 8.7700004577637,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.10000000149012,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FFA8FFA3",
                        },
                        [4] = {
                            ["$2395588028"] = 2.0,
                        },
                        [5] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [14]

                -------------------- ENTRY [40] [15] --------------------
                [15] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "-25364664893791282",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 CE A3 28 BF F8 E2 A5 FF",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -0.14000000059605,
                                [2] = 7.60000002384186,
                                [3] = 8.7700004577637,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.10000000149012,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FFA8FFA3",
                        },
                        [4] = {
                            ["$2395588028"] = 2.0,
                        },
                        [5] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [15]

                -------------------- ENTRY [40] [16] --------------------
                [16] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "5022145015812382761",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 29 E0 FE 8D 48 3E B2 45",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -0.62999999523163,
                                [2] = 7.18999999761581,
                                [3] = 8.8000001907349,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.15000000596046,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FFA8FFA3",
                        },
                        [4] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [16]

                -------------------- ENTRY [40] [17] --------------------
                [17] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "-3253842208281493388",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 74 80 35 4C C0 07 D8 D2",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = 0.89999997615814,
                                [2] = 7.76999998092651,
                                [3] = 8.525899887085,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.10000000149012,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FF6BFF33",
                        },
                        [4] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [17]

                -------------------- ENTRY [40] [18] --------------------
                [18] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "3157774370017466405",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 25 58 B9 15 0F AB D2 2B",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -0.54000002145767,
                                [2] = 7.36000001430511,
                                [3] = 8.7059001922607,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.10000000149012,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FF6BFF33",
                        },
                        [4] = {
                            ["$2395588028"] = 3.0,
                        },
                        [5] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [18]

                -------------------- ENTRY [40] [19] --------------------
                [19] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "7743159673380641172",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 94 99 FB AA B2 3A 75 6B",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -0.95999997854233,
                                [2] = 7.40999999642372,
                                [3] = 7.9200000762939,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.15000000596046,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FFA8FFA3",
                        },
                        [4] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [19]

                -------------------- ENTRY [40] [20] --------------------
                [20] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "-3137516819179789790",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 22 A2 F9 83 13 4D 75 D4",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -0.43999999761581,
                                [2] = 7.25999999046326,
                                [3] = 8.6559000015259,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.15000000596046,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FF6BFF33",
                        },
                        [4] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [20]

                -------------------- ENTRY [40] [21] --------------------
                [21] = {
                    ["name"] = "",
                    ["identifier_type"] = "49615221",  -- do not change
                    ["identifier"] = "4049662739672336292",  -- do not change
                    ["identifier_hex"] = "75 11 F5 02 A4 07 4E 42 CE 4A 33 38",
                    ["properties"] = {
                        [1] = {
                            ["COORDINATES"] = {  -- X, Y, Z
                                [1] = -0.56999999284744,
                                [2] = 7.27000001072884,
                                [3] = 8.5900001525879,
                            },
                        },
                        [2] = {
                            ["$540225266"] = 0.10000000149012,
                        },
                        [3] = {
                            ["RGBA_COLOR_VALUE_1"] = "FFA8FFA3",
                        },
                        [4] = {
                            ["$2395588028"] = 1.5,
                        },
                        [5] = {
                            ["$236264560"] = 1,
                        },
                    },   -- end properties
                },  -- end entry [40] [21]
            },   -- end entries for [40]
        },  -- end entry [40]

        -------------------- ENTRY [41] --------------------
        [41] = {
            ["name"] = "CINE_CHAIR",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "5063079314164016346",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A DA E4 5F 96 CF AB 43 46",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.0,
                        [2] = 7.22879999876022,
                        [3] = 1.7403999567032,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.017452400177717,
                        [2] = 0.0,
                        [3] = 0.0,
                        [4] = 0.99984800815582,
                    },
                },
                [4] = {
                    ["$120"] = 0.80000001192093,
                },
                [5] = {
                    ["$121"] = 0.80000001192093,
                },
                [6] = {
                    ["$122"] = 0.80000001192093,
                },
                [7] = {
                    ["$250000979"] = 1,
                },
                [8] = {
                    ["MDL_TYPE"] = 2634,
                },
                [9] = {
                    ["MDL_1"] = "MEDIA/SHIPS/COCKPIT_SET_1/COCKPIT_MEDIUMFIGHTER_CHAIR.MDL",
                },
                [10] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [41]

        -------------------- ENTRY [42] --------------------
        [42] = {
            ["name"] = "flair_falcon",
            ["identifier_type"] = "1247812863",  -- do not change
            ["identifier"] = "-3363409890988544377",  -- do not change
            ["identifier_hex"] = "FF 1C 60 4A 87 AE 97 35 86 C4 52 D1",
            ["properties"] = {
                [1] = {
                    ["$387285480"] = 1,
                },
                [2] = {
                    ["COORDINATES"] = {  -- X, Y, Z
                        [1] = 0.65570002794266,
                        [2] = 7.73070001602173,
                        [3] = 8.8510999679565,
                    },
                },
                [3] = {
                    ["ROTATIONS"] = {  -- X, Y, Z1, Z2
                        [1] = 0.055365201085806,
                        [2] = 0.80590498447418,
                        [3] = 0.076339103281498,
                        [4] = 0.58448600769043,
                    },
                },
                [4] = {
                    ["$120"] = 0.40000000596046,
                },
                [5] = {
                    ["$121"] = 0.40000000596046,
                },
                [6] = {
                    ["$122"] = 0.40000000596046,
                },
                [7] = {
                    ["HARDPOINT_NUMBER_2"] = 999003,
                },
                [8] = {
                    ["$250000979"] = 1,
                },
                [9] = {
                    ["MDL_TYPE"] = 10674,
                },
                [10] = {
                    ["MDL_1"] = "MEDIA/OBJECTS/DASHFLAIR/FALCON.MDL",
                },
                [11] = {
                    ["$249687282"] = 10,
                },
            },   -- end properties
        },  -- end entry [42]
    }, -- end main entries


    -- -----------------------------------------------------------
    -- Additonal data that is added to the end of the .layout file
    -- Currently it's unknown what it does, so don't change it
    ["additional_data"] = "FF FF FF FF FF FF FF FF 00 00 00 00 00 00 07 00 00 00 FF FF FF FF 00 00 00 00 00 00 00 00 00 00 02 00 75 2E 82 4D 9E 0E 00 D1 00 01 00 00 00 01 FF 16 00 00 FF FF FF FF 00 00 00 00 00 00 00 00 00 00 00 00 AF 55 AF 41 87 0B C5 C1 00 01 00 00 00 01 A2 1A 00 00 FF FF FF FF 00 00 00 00 00 00 00 00 00 00 00 00"
}

return LAYOUT